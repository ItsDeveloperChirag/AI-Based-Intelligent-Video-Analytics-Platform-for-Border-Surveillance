import cv2
import threading

from config import CAMERA_URL
from ai.tracker import Tracker


# =========================================================
# GLOBALS
# =========================================================

latest_frame = None
latest_result = None

frame_lock = threading.Lock()
result_lock = threading.Lock()

running = True

# Zone
drawing = False
zone_created = False

start_x = 0
start_y = 0
end_x = 0
end_y = 0


# =========================================================
# MOUSE CALLBACK
# =========================================================

def mouse_callback(event, x, y, flags, param):

    global drawing
    global zone_created
    global start_x, start_y
    global end_x, end_y

    # Start drawing
    if event == cv2.EVENT_LBUTTONDOWN:

        drawing = True
        zone_created = False

        start_x = x
        start_y = y

        end_x = x
        end_y = y

    # While dragging
    elif event == cv2.EVENT_MOUSEMOVE:

        if drawing:

            end_x = x
            end_y = y

    # Finish drawing
    elif event == cv2.EVENT_LBUTTONUP:

        drawing = False
        zone_created = True

        end_x = x
        end_y = y

        print()
        print("=" * 50)
        print("✅ RESTRICTED ZONE CREATED")
        print(
            f"Zone: ({start_x},{start_y}) "
            f"→ ({end_x},{end_y})"
        )
        print("=" * 50)


# =========================================================
# CHECK POINT INSIDE ZONE
# =========================================================

def point_inside_zone(x, y):

    if not zone_created:
        return False

    x1 = min(start_x, end_x)
    x2 = max(start_x, end_x)

    y1 = min(start_y, end_y)
    y2 = max(start_y, end_y)

    return (
        x1 <= x <= x2
        and
        y1 <= y <= y2
    )


# =========================================================
# CAMERA THREAD
# =========================================================

def camera_thread():

    global latest_frame
    global running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(
        cv2.CAP_PROP_BUFFERSIZE,
        1
    )

    if not cap.isOpened():

        print("❌ Camera failed")

        running = False

        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            continue

        frame = cv2.resize(
            frame,
            (640, 480)
        )

        with frame_lock:

            latest_frame = frame

    cap.release()


# =========================================================
# TRACKING THREAD
# =========================================================

def tracking_thread():

    global latest_result
    global running

    tracker = Tracker()

    print("🚀 Tracking started")

    while running:

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        result = tracker.track(frame)

        with result_lock:

            latest_result = result


# =========================================================
# START THREADS
# =========================================================

threading.Thread(
    target=camera_thread,
    daemon=True
).start()

threading.Thread(
    target=tracking_thread,
    daemon=True
).start()


# =========================================================
# WINDOW
# =========================================================

window_name = "IBVAP - DRAW RESTRICTED ZONE"

cv2.namedWindow(window_name)

cv2.setMouseCallback(
    window_name,
    mouse_callback
)


print("=" * 60)
print("IBVAP - USER DEFINED RESTRICTED ZONE")
print("=" * 60)
print()
print("1. Camera screen par mouse se rectangle draw karo")
print("2. Left mouse button press karo")
print("3. Drag karke zone banao")
print("4. Mouse release karo")
print("5. Zone ke andar walk karo")
print("6. Q = Exit")
print()
print("Example:")
print("┌─────────────────────────────┐")
print("│                             │")
print("│    ┌───────────────────┐    │")
print("│    │  RESTRICTED ZONE  │    │")
print("│    └───────────────────┘    │")
print("│                             │")
print("└─────────────────────────────┘")
print("=" * 60)


# =========================================================
# MAIN LOOP
# =========================================================

last_intrusion_ids = set()

while running:

    with frame_lock:

        if latest_frame is None:
            continue

        frame = latest_frame.copy()

    with result_lock:

        result = latest_result

    # -----------------------------------------------------
    # DRAW DETECTIONS
    # -----------------------------------------------------

    if result is not None:

        frame = result.plot()

        if result.boxes is not None:

            for box in result.boxes:

                if box.id is None:
                    continue

                track_id = int(box.id[0])

                class_id = int(box.cls[0])

                class_name = result.names[class_id]

                # Only person
                if class_name != "person":
                    continue

                x1, y1, x2, y2 = map(
                    int,
                    box.xyxy[0]
                )

                # Bottom-center point
                bottom_x = int(
                    (x1 + x2) / 2
                )

                bottom_y = int(y2)

                inside = point_inside_zone(
                    bottom_x,
                    bottom_y
                )

                # ------------------------------------------------
                # INTRUSION
                # ------------------------------------------------

                if inside:

                    if track_id not in last_intrusion_ids:

                        print(
                            f"🚨 INTRUSION DETECTED | "
                            f"Person ID: {track_id}"
                        )

                        last_intrusion_ids.add(
                            track_id
                        )

                    cv2.putText(
                        frame,
                        f"INTRUSION! ID {track_id}",
                        (x1, max(y1 - 10, 30)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 0, 255),
                        2
                    )

                else:

                    cv2.putText(
                        frame,
                        f"ID {track_id}",
                        (x1, max(y1 - 10, 30)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )


    # =====================================================
    # DRAW ZONE
    # =====================================================

    if drawing:

        cv2.rectangle(
            frame,
            (start_x, start_y),
            (end_x, end_y),
            (0, 0, 255),
            2
        )

    elif zone_created:

        cv2.rectangle(
            frame,
            (start_x, start_y),
            (end_x, end_y),
            (0, 0, 255),
            2
        )

        cv2.putText(
            frame,
            "RESTRICTED ZONE",
            (
                min(start_x, end_x),
                max(min(start_y, end_y) - 10, 20)
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 0, 255),
            2
        )


    # =====================================================
    # SHOW
    # =====================================================

    cv2.imshow(
        window_name,
        frame
    )

    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):

        running = False
        break


cv2.destroyAllWindows()

print("Test finished.")