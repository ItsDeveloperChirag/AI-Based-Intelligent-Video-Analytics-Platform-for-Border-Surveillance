import cv2
import threading
import time

from config import CAMERA_URL
from ai.tracker import Tracker
from ai.trajectory import TrajectoryTracker
from ai.border import BorderDetector
from ai.zone import RestrictedZone
from ai.incident import IncidentManager


# ============================================================
# GLOBAL STATE
# ============================================================

latest_frame = None
latest_result = None

running = True

frame_lock = threading.Lock()
result_lock = threading.Lock()
state_lock = threading.Lock()


# ============================================================
# DRAWING STATE
# ============================================================

# -------------------------
# Virtual Border
# -------------------------

border = BorderDetector()

border_drawing = False
border_start = None
border_end = None


# -------------------------
# Restricted Zone
# -------------------------

zone = RestrictedZone()

zone_points = []
zone_drawing = False


# Current drawing mode
# BORDER = mouse drag
# ZONE   = left-click polygon points

draw_mode = "border"


# ============================================================
# TRAJECTORY
# ============================================================

trajectory_tracker = TrajectoryTracker()


# ============================================================
# INCIDENT MANAGER
# ============================================================

incident_manager = IncidentManager()


# ============================================================
# EVENT CONTROL
# ============================================================

last_event_time = {}

EVENT_COOLDOWN = 3.0


# ============================================================
# CAMERA THREAD
# ============================================================

def camera_worker():

    global latest_frame
    global running

    print("📡 Starting camera...")
    print(f"Camera: {CAMERA_URL}")

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(
        cv2.CAP_PROP_BUFFERSIZE,
        1
    )

    if not cap.isOpened():

        print("❌ Could not open camera")

        running = False

        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:

            print("⚠️ Camera frame failed")

            time.sleep(0.1)

            continue

        # Keep only latest frame
        with frame_lock:

            latest_frame = frame

    cap.release()

    print("📴 Camera stopped")


# ============================================================
# EVENT COOLDOWN
# ============================================================

def can_generate_event(
    track_id,
    event_type
):

    key = f"{event_type}_{track_id}"

    current_time = time.time()

    if key not in last_event_time:

        last_event_time[key] = current_time

        return True

    if (
        current_time
        -
        last_event_time[key]
        >= EVENT_COOLDOWN
    ):

        last_event_time[key] = current_time

        return True

    return False


# ============================================================
# TRACKING THREAD
# ============================================================

def tracking_worker():

    global latest_result
    global running

    print("🤖 Starting YOLO tracking...")

    tracker = Tracker(
        model_path="yolo11n.pt",
        confidence=0.25,
        image_size=640
    )

    print("✅ Tracker ready")

    while running:

        # ------------------------------------------------
        # Get latest frame
        # ------------------------------------------------

        with frame_lock:

            frame = latest_frame

        if frame is None:

            time.sleep(0.01)

            continue

        try:

            # ------------------------------------------------
            # YOLO TRACKING
            # ------------------------------------------------

            result = tracker.track(frame)

            with result_lock:

                latest_result = result

            # ------------------------------------------------
            # GET TRACKS
            # ------------------------------------------------

            tracks = tracker.get_tracks(result)

            # ------------------------------------------------
            # PROCESS EACH OBJECT
            # ------------------------------------------------

            for track in tracks:

                track_id = track["track_id"]

                if track_id == -1:

                    continue

                # =================================================
                # OBJECT INFORMATION
                # =================================================

                object_type = track["class_name"]

                confidence = track["confidence"]

                x1, y1, x2, y2 = track["bbox"]

                # =================================================
                # CENTER OF BOUNDING BOX
                # =================================================

                center_x = int(
                    (x1 + x2) / 2
                )

                center_y = int(
                    (y1 + y2) / 2
                )

                center = (
                    center_x,
                    center_y
                )

                # =================================================
                # TRAJECTORY UPDATE
                # =================================================

                trajectory_tracker.update(
                    track_id,
                    center
                )

                # =================================================
                # VIRTUAL BORDER
                # =================================================

                with state_lock:

                    border_defined = border.is_defined()

                if border_defined:

                    border_event = (
                        border.check_crossing(
                            track_id,
                            center
                        )
                    )

                    if border_event["crossed"]:

                        # -----------------------------------------
                        # EVENT COOLDOWN
                        # -----------------------------------------

                        if can_generate_event(
                            track_id,
                            "VIRTUAL_BORDER_INTRUSION"
                        ):

                            incident_manager.create_event(

                                event_type="VIRTUAL_BORDER_INTRUSION",

                                track_id=track_id,

                                object_type=object_type,

                                confidence=confidence,

                                direction=border_event["direction"],
                                frame=frame
                            )

                # =================================================
                # RESTRICTED ZONE
                # =================================================

                with state_lock:

                    zone_defined = zone.is_defined()

                if zone_defined:

                    zone_event = (
                        zone.check_intrusion(
                            track_id,
                            center
                        )
                    )

                    if zone_event["intrusion"]:

                        # -----------------------------------------
                        # EVENT COOLDOWN
                        # -----------------------------------------

                        if can_generate_event(
                            track_id,
                            "RESTRICTED_ZONE_INTRUSION"
                        ):

                            incident_manager.create_event(

                                event_type="RESTRICTED_ZONE_INTRUSION",

                                track_id=track_id,

                                object_type=object_type,

                                confidence=confidence,

                                direction=None,
                                frame=frame
                            )

        except Exception as e:

            print(
                f"⚠️ Tracking error: {e}"
            )

        time.sleep(0.01)


# ============================================================
# MOUSE CALLBACK
# ============================================================

def mouse_callback(
    event,
    x,
    y,
    flags,
    param
):

    global border_start
    global border_end
    global border_drawing

    global zone_points
    global zone_drawing

    # ========================================================
    # LEFT BUTTON DOWN
    # ========================================================

    if event == cv2.EVENT_LBUTTONDOWN:

        with state_lock:

            # -----------------------------------------------
            # BORDER MODE
            # -----------------------------------------------

            if draw_mode == "border":

                border_start = (
                    x,
                    y
                )

                border_end = (
                    x,
                    y
                )

                border_drawing = True

            # -----------------------------------------------
            # ZONE MODE
            # -----------------------------------------------

            elif draw_mode == "zone":

                zone_points.append(
                    (x, y)
                )

                print(
                    f"📍 Zone point added: "
                    f"({x}, {y})"
                )

    # ========================================================
    # MOUSE MOVE
    # ========================================================

    elif event == cv2.EVENT_MOUSEMOVE:

        with state_lock:

            if (
                draw_mode == "border"
                and border_drawing
            ):

                border_end = (
                    x,
                    y
                )

    # ========================================================
    # LEFT BUTTON UP
    # ========================================================

    elif event == cv2.EVENT_LBUTTONUP:

        with state_lock:

            if (
                draw_mode == "border"
                and border_drawing
            ):

                border_end = (
                    x,
                    y
                )

                border_drawing = False

                # Set actual BorderDetector
                border.set_border(
                    border_start,
                    border_end
                )

                print(
                    "\n✅ Virtual Border created"
                )

                print(
                    f"   Start: "
                    f"{border_start}"
                )

                print(
                    f"   End  : "
                    f"{border_end}"
                )

                print()


# ============================================================
# DRAW BORDER
# ============================================================

def draw_border(frame):

    with state_lock:

        current_start = border_start
        current_end = border_end
        current_drawing = border_drawing

    # During drawing
    if current_drawing:

        if (
            current_start is not None
            and current_end is not None
        ):

            cv2.line(
                frame,
                current_start,
                current_end,
                (0, 0, 255),
                3
            )

    # Actual saved border
    elif border.is_defined():

        border.draw(frame)

    return frame


# ============================================================
# DRAW ZONE
# ============================================================

def draw_zone(frame):

    with state_lock:

        points = zone_points.copy()

    # Draw points
    for point in points:

        cv2.circle(
            frame,
            point,
            5,
            (0, 255, 255),
            -1
        )

    # Draw lines
    if len(points) >= 2:

        for i in range(
            len(points) - 1
        ):

            cv2.line(
                frame,
                points[i],
                points[i + 1],
                (0, 255, 255),
                2
            )

    # Draw completed zone
    if zone.is_defined():

        zone.draw(frame)

    return frame


# ============================================================
# MAIN
# ============================================================

def main():

    global running

    global draw_mode

    global border_start
    global border_end
    global border_drawing

    global zone_points
    global zone_drawing

    # ========================================================
    # START THREADS
    # ========================================================

    camera_thread = threading.Thread(
        target=camera_worker,
        daemon=True
    )

    tracking_thread = threading.Thread(
        target=tracking_worker,
        daemon=True
    )

    camera_thread.start()

    time.sleep(1)

    tracking_thread.start()

    # ========================================================
    # WINDOW
    # ========================================================

    window_name = (
        "IBVAP - Security Boundary Test"
    )

    cv2.namedWindow(
        window_name
    )

    cv2.setMouseCallback(
        window_name,
        mouse_callback
    )

    # ========================================================
    # INSTRUCTIONS
    # ========================================================

    print()

    print("=" * 60)

    print(
        "       IBVAP SECURITY BOUNDARY TEST"
    )

    print("=" * 60)

    print()

    print("VIRTUAL BORDER")

    print(
        "  Mouse Drag = Draw Border"
    )

    print(
        "  R = Redraw Border"
    )

    print()

    print("RESTRICTED ZONE")

    print(
        "  Z = Start / Redraw Zone"
    )

    print(
        "  Left Click = Add Point"
    )

    print(
        "  ENTER = Finish Zone"
    )

    print(
        "  BACKSPACE = Remove Last Point"
    )

    print()

    print("OTHER")

    print(
        "  C = Clear Everything"
    )

    print(
        "  Q = Quit"
    )

    print("=" * 60)

    print()

    # ========================================================
    # DISPLAY LOOP
    # ========================================================

    while running:

        with frame_lock:

            if latest_frame is None:

                continue

            display_frame = (
                latest_frame.copy()
            )

        # ----------------------------------------------------
        # YOLO RESULT
        # ----------------------------------------------------

        with result_lock:

            result = latest_result

        if result is not None:

            try:

                display_frame = (
                    result.plot()
                )

            except Exception:

                pass

        # ----------------------------------------------------
        # DRAW BORDER
        # ----------------------------------------------------

        display_frame = draw_border(
            display_frame
        )

        # ----------------------------------------------------
        # DRAW ZONE
        # ----------------------------------------------------

        display_frame = draw_zone(
            display_frame
        )

        # ----------------------------------------------------
        # UI
        # ----------------------------------------------------

        cv2.putText(
            display_frame,
            f"MODE: {draw_mode.upper()}",
            (20, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        cv2.putText(
            display_frame,
            "R: Border | Z: Zone | C: Clear | Q: Quit",
            (20, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2
        )

        # ----------------------------------------------------
        # SHOW
        # ----------------------------------------------------

        cv2.imshow(
            window_name,
            display_frame
        )

        key = (
            cv2.waitKey(1)
            & 0xFF
        )

        # ====================================================
        # Q = QUIT
        # ====================================================

        if key == ord("q"):

            running = False

            break

        # ====================================================
        # R = REDRAW BORDER
        # ====================================================

        elif key == ord("r"):

            with state_lock:

                border.clear()

                border_start = None
                border_end = None
                border_drawing = False

                draw_mode = "border"

            print(
                "\n🔄 Virtual Border cleared."
            )

            print(
                "   Drag mouse to draw a new border."
            )

        # ====================================================
        # Z = REDRAW ZONE
        # ====================================================

        elif key == ord("z"):

            with state_lock:

                zone.clear()

                zone_points = []

                zone_drawing = True

                draw_mode = "zone"

            print(
                "\n🟡 Restricted Zone drawing started."
            )

            print(
                "   Left Click = Add points"
            )

            print(
                "   ENTER = Finish"
            )

        # ====================================================
        # ENTER = FINISH ZONE
        # ====================================================

        elif key == 13:

            with state_lock:

                if draw_mode == "zone":

                    if len(zone_points) >= 3:

                        zone.set_polygon(
                            zone_points
                        )

                        zone_drawing = False

                        draw_mode = "border"

                        print(
                            "\n✅ Restricted Zone created."
                        )

                        print(
                            f"   Points: "
                            f"{len(zone_points)}"
                        )

                    else:

                        print(
                            "\n⚠️ Restricted Zone "
                            "needs at least 3 points."
                        )

        # ====================================================
        # BACKSPACE = REMOVE LAST POINT
        # ====================================================

        elif key == 8:

            with state_lock:

                if (
                    draw_mode == "zone"
                    and len(zone_points) > 0
                ):

                    removed = (
                        zone_points.pop()
                    )

                    print(
                        f"↩️ Removed point: "
                        f"{removed}"
                    )

        # ====================================================
        # C = CLEAR EVERYTHING
        # ====================================================

        elif key == ord("c"):

            with state_lock:

                border.clear()

                zone.clear()

                border_start = None
                border_end = None

                zone_points = []

                border_drawing = False
                zone_drawing = False

                draw_mode = "border"

            last_event_time.clear()

            print(
                "\n🧹 Border + Restricted Zone cleared."
            )

    # ========================================================
    # CLEANUP
    # ========================================================

    running = False

    cv2.destroyAllWindows()

    print(
        "✅ Test stopped."
    )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    main()