import cv2
import time
import threading

from ultralytics import YOLO

from ai.anpr_pipeline import ANPRPipeline
from ai.anpr_worker import ANPRWorker


# ============================================================
# CONFIG
# ============================================================

RTSP_URL = (
    "rtsp://192.168.1.8:554/live/ch00_1"
)

YOLO_MODEL = "yolo11n.pt"

CONFIDENCE = 0.35

IMAGE_SIZE = 640


# Vehicle class IDs from COCO
VEHICLE_CLASSES = {
    2: "car",
    3: "motorcycle",
    5: "bus",
    7: "truck"
}


# ============================================================
# THREADED CAMERA
# ============================================================

class CameraStream:

    def __init__(self, url):

        self.url = url

        self.cap = None

        self.frame = None

        self.running = False

        self.lock = threading.Lock()

        self.thread = None


    # ========================================================
    # START CAMERA
    # ========================================================

    def start(self):

        print()
        print("=" * 60)
        print("OPENING CAMERA")
        print("=" * 60)

        self.cap = cv2.VideoCapture(
            self.url,
            cv2.CAP_FFMPEG
        )

        self.cap.set(
            cv2.CAP_PROP_BUFFERSIZE,
            1
        )

        if not self.cap.isOpened():

            print(
                "ERROR: Camera could not be opened"
            )

            return False

        print(
            "Camera opened successfully"
        )

        self.running = True

        self.thread = threading.Thread(
            target=self._update,
            daemon=True
        )

        self.thread.start()

        return True


    # ========================================================
    # CAMERA THREAD
    # ========================================================

    def _update(self):

        while self.running:

            try:

                ret, frame = self.cap.read()

                if not ret:

                    time.sleep(0.01)

                    continue

                # Keep ONLY latest frame
                with self.lock:

                    self.frame = frame

            except Exception as e:

                print(
                    "Camera error:",
                    e
                )

                time.sleep(0.1)


    # ========================================================
    # GET LATEST FRAME
    # ========================================================

    def read(self):

        with self.lock:

            if self.frame is None:

                return None

            return self.frame.copy()


    # ========================================================
    # STOP CAMERA
    # ========================================================

    def stop(self):

        print(
            "Stopping camera..."
        )

        self.running = False

        if self.thread is not None:

            self.thread.join(
                timeout=2
            )

        if self.cap is not None:

            self.cap.release()


# ============================================================
# MAIN
# ============================================================

def main():

    print()
    print("=" * 60)
    print("       ANPR LIVE TEST")
    print("=" * 60)
    print()


    # ========================================================
    # CAMERA
    # ========================================================

    camera = CameraStream(
        RTSP_URL
    )

    if not camera.start():

        return


    # ========================================================
    # VEHICLE MODEL
    # ========================================================

    print()
    print(
        "Loading vehicle detection model..."
    )

    vehicle_model = YOLO(
        YOLO_MODEL
    )

    print(
        "Vehicle model loaded"
    )


    # ========================================================
    # ANPR PIPELINE
    # ========================================================

    print()
    print(
        "Loading ANPR pipeline..."
    )

    anpr = ANPRPipeline(

        plate_model=(
            "models/"
            "license-plate-finetune-v1n.pt"
        ),

        confidence=0.35,

        image_size=640,

        ocr_cooldown=3.0
    )

    print(
        "ANPR pipeline loaded"
    )


    # ========================================================
    # ANPR BACKGROUND WORKER
    # ========================================================

    anpr_worker = ANPRWorker(

        anpr_pipeline=anpr,

        interval=0.5
    )

    anpr_worker.start()


    # ========================================================
    # WINDOW
    # ========================================================

    window_name = "ANPR LIVE"

    cv2.namedWindow(
        window_name,
        cv2.WINDOW_NORMAL
    )

    cv2.resizeWindow(
        window_name,
        1100,
        700
    )


    # ========================================================
    # VARIABLES
    # ========================================================

    frame_count = 0

    fps_time = time.time()

    fps = 0

    last_anpr_submit = 0

    ANPR_SUBMIT_INTERVAL = 1.0


    # ========================================================
    # MAIN LOOP
    # ========================================================

    try:

        while True:

            # ------------------------------------------------
            # GET LATEST CAMERA FRAME
            # ------------------------------------------------

            frame = camera.read()

            if frame is None:

                time.sleep(
                    0.01
                )

                continue


            frame_count += 1


            # ------------------------------------------------
            # CREATE DISPLAY FRAME
            # ------------------------------------------------

            display_frame = frame.copy()


            # =================================================
            # VEHICLE DETECTION + TRACKING
            # =================================================

            results = vehicle_model.track(

                source=frame,

                persist=True,

                tracker="bytetrack.yaml",

                classes=list(
                    VEHICLE_CLASSES.keys()
                ),

                conf=CONFIDENCE,

                imgsz=IMAGE_SIZE,

                verbose=False
            )


            vehicles = []


            result = results[0]


            # =================================================
            # READ DETECTIONS
            # =================================================

            if result.boxes is not None:

                for box in result.boxes:

                    # No tracker ID
                    if box.id is None:

                        continue


                    track_id = int(
                        box.id[0]
                    )


                    class_id = int(
                        box.cls[0]
                    )


                    confidence = float(
                        box.conf[0]
                    )


                    if class_id not in VEHICLE_CLASSES:

                        continue


                    x1, y1, x2, y2 = map(
                        int,
                        box.xyxy[0]
                    )


                    vehicle_type = (
                        VEHICLE_CLASSES[
                            class_id
                        ]
                    )


                    # ------------------------------------------------
                    # SAVE VEHICLE
                    # ------------------------------------------------

                    vehicles.append({

                        "track_id":
                            track_id,

                        "class_id":
                            class_id,

                        "class_name":
                            vehicle_type,

                        "confidence":
                            confidence,

                        "bbox": [
                            x1,
                            y1,
                            x2,
                            y2
                        ]

                    })


                    # =================================================
                    # DRAW VEHICLE BOX
                    # =================================================

                    cv2.rectangle(

                        display_frame,

                        (x1, y1),

                        (x2, y2),

                        (255, 0, 0),

                        2
                    )


                    # =================================================
                    # VEHICLE LABEL
                    # =================================================

                    label = (

                        f"{vehicle_type} "
                        f"ID:{track_id}"
                    )


                    cv2.putText(

                        display_frame,

                        label,

                        (
                            x1,
                            max(
                                25,
                                y1 - 10
                            )
                        ),

                        cv2.FONT_HERSHEY_SIMPLEX,

                        0.60,

                        (255, 0, 0),

                        2
                    )


            # =================================================
            # SEND ANPR JOB
            # =================================================

            current_time = time.time()


            if (
                current_time
                - last_anpr_submit
                >= ANPR_SUBMIT_INTERVAL
            ):

                last_anpr_submit = (
                    current_time
                )


                # IMPORTANT:
                # This does NOT wait for OCR.
                # It only submits a snapshot.

                anpr_worker.submit(

                    frame,

                    vehicles
                )


            # =================================================
            # GET LATEST ANPR RESULT
            # =================================================

            anpr_results = (
                anpr_worker.get_results()
            )


            # =================================================
            # DRAW ANPR RESULTS
            # =================================================

            display_frame = anpr.draw(

                display_frame,

                anpr_results
            )


            # =================================================
            # FPS
            # =================================================

            current_time = time.time()

            elapsed = (
                current_time
                - fps_time
            )


            if elapsed >= 1.0:

                fps = frame_count / elapsed

                frame_count = 0

                fps_time = current_time


            # =================================================
            # STATUS
            # =================================================

            cv2.putText(

                display_frame,

                "ANPR LIVE",

                (20, 35),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.80,

                (0, 255, 0),

                2
            )


            cv2.putText(

                display_frame,

                f"FPS: {fps:.1f}",

                (20, 65),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.60,

                (255, 255, 255),

                2
            )


            cv2.putText(

                display_frame,

                f"Vehicles: {len(vehicles)}",

                (20, 95),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.60,

                (255, 255, 255),

                2
            )


            # =================================================
            # DISPLAY
            # =================================================

            cv2.imshow(

                window_name,

                display_frame
            )


            # =================================================
            # KEYBOARD
            # =================================================

            key = (
                cv2.waitKey(1)
                & 0xFF
            )


            if key == ord("q"):

                break


    except KeyboardInterrupt:

        print(
            "\nKeyboard interrupt"
        )


    finally:

        print()
        print(
            "=" * 60
        )
        print(
            "SHUTTING DOWN"
        )
        print(
            "=" * 60
        )

        anpr_worker.stop()

        camera.stop()

        cv2.destroyAllWindows()


# ============================================================
# START
# ============================================================

if __name__ == "__main__":

    main()