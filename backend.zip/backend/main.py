from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel
from pathlib import Path
from urllib.parse import quote
from typing import List
import uvicorn
import cv2
import time
import threading

from database import get_connection, initialize_database
from ai.ai_pipeline import AIPipeline


# ============================================================
# IBVAP - INTELLIGENT BORDER VIDEO ANALYTICS PLATFORM
# MAIN FASTAPI SERVER
# ============================================================

app = FastAPI(
    title="IBVAP API",
    description="Intelligent Border Video Analytics Platform API",
    version="2.0.0"
)


# ============================================================
# BASE DIRECTORY
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

EVIDENCE_DIR = BASE_DIR / "evidence"

EVIDENCE_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# AI PIPELINE
# ============================================================

ai_pipeline = None

pipeline_lock = threading.Lock()


def get_ai_pipeline():

    global ai_pipeline

    with pipeline_lock:

        if ai_pipeline is None:

            print()
            print("=" * 70)
            print("INITIALIZING IBVAP AI PIPELINE")
            print("=" * 70)

            ai_pipeline = AIPipeline(
                model_path=str(
                    BASE_DIR / "yolo11n.pt"
                )
            )

            print("AI Pipeline object created")

    return ai_pipeline


# ============================================================
# SERVE EVIDENCE IMAGES
# ============================================================

app.mount(
    "/evidence",
    StaticFiles(
        directory=str(EVIDENCE_DIR)
    ),
    name="evidence"
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(
    CORSMiddleware,

    allow_origins=["*"],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


# ============================================================
# REQUEST MODELS
# ============================================================

class BorderRequest(BaseModel):

    points: List[List[int]]


class ZoneRequest(BaseModel):

    points: List[List[int]]


# ============================================================
# EVIDENCE URL
# ============================================================

def get_evidence_url(evidence_path):

    if not evidence_path:

        return None

    try:

        filename = Path(
            evidence_path
        ).name

        return (
            "/evidence/"
            + quote(filename)
        )

    except Exception:

        return None


# ============================================================
# INCIDENT JSON CONVERSION
# ============================================================

def prepare_incident(incident):

    if incident.get("timestamp"):

        try:

            incident["timestamp"] = (
                incident["timestamp"].isoformat()
            )

        except Exception:

            pass


    if incident.get("evidence_timestamp"):

        try:

            incident["evidence_timestamp"] = (
                incident["evidence_timestamp"].isoformat()
            )

        except Exception:

            pass


    if incident.get("confidence") is not None:

        try:

            incident["confidence"] = float(
                incident["confidence"]
            )

        except Exception:

            pass


    incident["evidence_url"] = (
        get_evidence_url(
            incident.get("evidence_path")
        )
    )

    return incident


# ============================================================
# STARTUP
# ============================================================

@app.on_event("startup")
def startup():

    global ai_pipeline

    print()
    print("=" * 70)
    print("        IBVAP BACKEND STARTING")
    print("=" * 70)


    # --------------------------------------------------------
    # DATABASE
    # --------------------------------------------------------

    try:

        initialize_database()

        print("✅ Database initialized")

    except Exception as e:

        print("❌ Database initialization failed")

        print(e)


    # --------------------------------------------------------
    # AI PIPELINE
    # --------------------------------------------------------

    try:

        ai_pipeline = get_ai_pipeline()

        started = ai_pipeline.start()

        if started:

            print("✅ AI Pipeline started")

        else:

            print("❌ AI Pipeline failed to start")

    except Exception as e:

        print("❌ AI Pipeline startup error")

        print(e)


    print()
    print("=" * 70)
    print("🚀 IBVAP BACKEND READY")
    print("=" * 70)
    print()


# ============================================================
# SHUTDOWN
# ============================================================

@app.on_event("shutdown")
def shutdown():

    global ai_pipeline

    print()
    print("=" * 70)
    print("STOPPING IBVAP BACKEND")
    print("=" * 70)

    if ai_pipeline is not None:

        try:

            ai_pipeline.stop()

            print("✅ AI Pipeline stopped")

        except Exception as e:

            print("❌ AI Pipeline shutdown error")

            print(e)

    print("Backend stopped")


# ============================================================
# ROOT
# ============================================================

@app.get("/")
def root():

    return {

        "project": "IBVAP",

        "name": (
            "Intelligent Border Video "
            "Analytics Platform"
        ),

        "status": "running",

        "version": "2.0.0",

        "message": (
            "IBVAP backend API is running successfully"
        )

    }


# ============================================================
# API INFORMATION
# ============================================================

@app.get("/api")
def api_information():

    return {

        "name": "IBVAP API",

        "version": "2.0.0",

        "status": "running",

        "endpoints": [

            "/",

            "/api",

            "/api/health",

            "/api/pipeline/status",

            "/api/frame",

            "/api/stream",

            "/api/detections",

            "/api/anpr",

            "/api/border",

            "/api/border/clear",

            "/api/zone",

            "/api/zone/clear",

            "/api/incidents",

            "/api/incidents/{id}",

            "/api/incidents/recent/{limit}",

            "/api/incidents/stats/summary"

        ],

        "evidence_endpoint":
            "/evidence/{filename}"

    }


# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/api/health")
def health():

    connection = None

    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor()

        cursor.execute(
            "SELECT 1"
        )

        cursor.fetchone()


        pipeline_running = False
        camera_running = False

        if ai_pipeline is not None:

            try:
                pipeline_running = bool(
                    ai_pipeline.is_running()
                )
            except Exception:
                pipeline_running = bool(
                    getattr(
                        ai_pipeline,
                        "running",
                        False
                    )
                )

            camera = getattr(
                ai_pipeline,
                "camera",
                None
            )

            if camera is not None:

                camera_running = bool(
                    getattr(
                        camera,
                        "running",
                        False
                    )
                )


        return {

            "status": "online",

            "api": "running",

            "database": "connected",

            "ai_pipeline": (
                "running"
                if pipeline_running
                else "stopped"
            ),

            "camera": (
                "running"
                if camera_running
                else "stopped"
            )

        }


    except Exception as e:

        return {

            "status": "online",

            "api": "running",

            "database": "disconnected",

            "ai_pipeline": "unknown",

            "camera": "unknown",

            "error": str(e)

        }


    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()


# ============================================================
# AI PIPELINE STATUS
# ============================================================
'''
@app.get("/api/pipeline/status")
def pipeline_status():

    if ai_pipeline is None:

        return {

            "running": False,

            "camera": False,

            "message": "AI pipeline not initialized"

        }


    camera = getattr(
        ai_pipeline,
        "camera",
        None
    )


    camera_running = False

    if camera is not None:

        camera_running = bool(
            getattr(
                camera,
                "running",
                False
            )
        )


    ai_running = bool(
        getattr(
            ai_pipeline,
            "ai_running",
            False
        )
    )


    return {

        "running": ai_running,

        "camera": camera_running,

        "camera_url": getattr(
            ai_pipeline,
            "camera_url",
            None
        ),

        "frame_count": getattr(
            ai_pipeline,
            "frame_count",
            0
        )

    }
'''
@app.get("/api/pipeline/status")
def pipeline_status():

    if ai_pipeline is None:

        return {
            "running": False,
            "camera": False,
            "message": "AI pipeline not initialized"
        }

    camera = getattr(
        ai_pipeline,
        "camera",
        None
    )

    camera_running = False

    if camera is not None:

        camera_running = bool(
            getattr(
                camera,
                "running",
                False
            )
        )

    # --------------------------------------------------------
    # CHECK AI PIPELINE RUNNING STATE
    # --------------------------------------------------------

    ai_running = False

    # Current pipeline may use different running attributes
    for attr_name in [
        "ai_running",
        "running",
        "is_running"
    ]:

        if hasattr(ai_pipeline, attr_name):

            value = getattr(
                ai_pipeline,
                attr_name
            )

            if isinstance(value, bool):

                ai_running = value
                break


    return {

        "running": ai_running,

        "camera": camera_running,

        "camera_url": getattr(
            ai_pipeline,
            "camera_url",
            None
        ),

        "frame_count": getattr(
            ai_pipeline,
            "frame_count",
            0
        )

    }
# ============================================================
# GET CURRENT DETECTIONS
# ============================================================

@app.get("/api/detections")
def get_detections():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )


    try:

        frame, detections = (
            ai_pipeline.read()
        )


        return {

            "success": True,

            "count": len(detections),

            "detections": detections

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# GET CURRENT ANPR RESULTS
# ============================================================

@app.get("/api/anpr")
def get_anpr():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )


    try:

        worker = getattr(
            ai_pipeline,
            "anpr_worker",
            None
        )


        if worker is None:

            return {

                "success": True,

                "count": 0,

                "results": []

            }


        results = worker.get_results()


        return {

            "success": True,

            "count": len(results),

            "results": results

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# GET CURRENT FRAME
# ============================================================

@app.get("/api/frame")
def get_frame():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )


    try:

        frame, detections = (
            ai_pipeline.read()
        )


        if frame is None:

            raise HTTPException(
                status_code=503,
                detail="No camera frame available"
            )


        success, encoded = cv2.imencode(
            ".jpg",
            frame,
            [
                cv2.IMWRITE_JPEG_QUALITY,
                80
            ]
        )


        if not success:

            raise HTTPException(
                status_code=500,
                detail="Failed to encode frame"
            )


        return Response(
            content=encoded.tobytes(),
            media_type="image/jpeg"
        )


    except HTTPException:

        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# LIVE MJPEG STREAM
# ============================================================

def generate_video_stream():

    while True:

        try:

            if ai_pipeline is None:

                time.sleep(0.1)

                continue


            frame, detections = (
                ai_pipeline.read()
            )


            if frame is None:

                time.sleep(0.03)

                continue


            success, encoded = cv2.imencode(
                ".jpg",
                frame,
                [
                    cv2.IMWRITE_JPEG_QUALITY,
                    80
                ]
            )


            if not success:

                time.sleep(0.03)

                continue


            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + encoded.tobytes()
                + b"\r\n"
            )


            time.sleep(0.03)


        except GeneratorExit:

            break

        except Exception as e:

            print(
                "Video stream error:",
                e
            )

            time.sleep(0.1)


@app.get("/api/stream")
def video_stream():

    return StreamingResponse(
        generate_video_stream(),
        media_type=(
            "multipart/x-mixed-replace; "
            "boundary=frame"
        )
    )


# ============================================================
# GET VIRTUAL BORDER
# ============================================================

@app.get("/api/border")
def get_border():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )

    try:

        border = ai_pipeline.border

        if (
            border.start_point is None
            or border.end_point is None
        ):

            return {
                "success": True,
                "defined": False,
                "start_point": None,
                "end_point": None
            }

        return {
            "success": True,
            "defined": True,
            "start_point": [
                int(border.start_point[0]),
                int(border.start_point[1])
            ],
            "end_point": [
                int(border.end_point[0]),
                int(border.end_point[1])
            ]
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# SET VIRTUAL BORDER
# ============================================================

@app.post("/api/border")
def set_border(request: BorderRequest):

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )

    points = request.points

    if len(points) != 2:

        raise HTTPException(
            status_code=400,
            detail="Virtual border requires exactly 2 points"
        )

    try:

        start_point = (
            int(points[0][0]),
            int(points[0][1])
        )

        end_point = (
            int(points[1][0]),
            int(points[1][1])
        )

        ai_pipeline.set_border(
            start_point,
            end_point
        )

        return {
            "success": True,
            "message": "Virtual border updated",
            "start_point": list(start_point),
            "end_point": list(end_point)
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# CLEAR VIRTUAL BORDER
# ============================================================

@app.delete("/api/border/clear")
def clear_border():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )


    try:

        ai_pipeline.clear_border()


        return {

            "success": True,

            "message": "Virtual border cleared"

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# SET RESTRICTED ZONE
# ============================================================

# ============================================================
# GET RESTRICTED ZONE
# ============================================================

@app.get("/api/zone")
def get_zone():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )

    try:

        points = ai_pipeline.zone.points

        if not points:

            return {
                "success": True,
                "defined": False,
                "points": []
            }

        return {
            "success": True,
                "defined": len(points) >= 4,
            "points": [
                [
                    int(point[0]),
                    int(point[1])
                ]
                for point in points
            ]
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# SET RESTRICTED ZONE
# ============================================================

@app.post("/api/zone")
def set_zone(request: ZoneRequest):

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )

    points = request.points

    if len(points) != 4:

        raise HTTPException(
            status_code=400,
            detail=(
                "Restricted zone requires "
                "exactly 4 points"
            )
        )

    try:

        converted_points = [

            (
                int(point[0]),
                int(point[1])
            )

            for point in points
        ]

        ai_pipeline.set_zone(
            converted_points
        )

        return {
            "success": True,
            "message": "Restricted zone updated",
            "points": converted_points
        }

    except HTTPException:

        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# CLEAR RESTRICTED ZONE
# ============================================================

@app.delete("/api/zone/clear")
def clear_zone():

    if ai_pipeline is None:

        raise HTTPException(
            status_code=503,
            detail="AI pipeline is not initialized"
        )


    try:

        ai_pipeline.clear_zone()


        return {

            "success": True,

            "message": "Restricted zone cleared"

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


# ============================================================
# GET ALL INCIDENTS
# ============================================================

@app.get("/api/incidents")
def get_incidents():

    connection = None

    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )


        query = """
        SELECT

            id,

            incident_id,

            timestamp,

            track_id,

            event_type,

            threat_score,

            threat_level,

            behavior,

            direction,

            zone_intrusion,

            border_crossed,

            loitering,

            reasons,

            status,

            evidence_path,

            evidence_timestamp,

            object_type,

            confidence

        FROM incidents

        ORDER BY timestamp DESC
        """


        cursor.execute(query)

        incidents = cursor.fetchall()


        for incident in incidents:

            prepare_incident(
                incident
            )


        return {

            "success": True,

            "count": len(incidents),

            "incidents": incidents

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()


# ============================================================
# GET SINGLE INCIDENT
# ============================================================

@app.get("/api/incidents/{incident_id}")
def get_incident(
    incident_id: int
):

    connection = None

    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )


        query = """
        SELECT

            id,

            incident_id,

            timestamp,

            track_id,

            event_type,

            threat_score,

            threat_level,

            behavior,

            direction,

            zone_intrusion,

            border_crossed,

            loitering,

            reasons,

            status,

            evidence_path,

            evidence_timestamp,

            object_type,

            confidence

        FROM incidents

        WHERE id = %s
        """


        cursor.execute(
            query,
            (incident_id,)
        )


        incident = cursor.fetchone()


        if not incident:

            raise HTTPException(
                status_code=404,
                detail="Incident not found"
            )


        prepare_incident(
            incident
        )


        return {

            "success": True,

            "incident": incident

        }


    except HTTPException:

        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()


# ============================================================
# INCIDENT STATISTICS
# ============================================================

@app.get("/api/incidents/stats/summary")
def incident_statistics():

    connection = None

    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )


        # ----------------------------------------------------
        # TOTAL
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total
            FROM incidents
            """
        )

        total = cursor.fetchone()["total"]


        # ----------------------------------------------------
        # BORDER
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total
            FROM incidents
            WHERE event_type =
            'VIRTUAL_BORDER_INTRUSION'
            """
        )

        border = cursor.fetchone()["total"]


        # ----------------------------------------------------
        # ZONE
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total
            FROM incidents
            WHERE event_type =
            'RESTRICTED_ZONE_INTRUSION'
            """
        )

        zone = cursor.fetchone()["total"]


        # ----------------------------------------------------
        # LOITERING
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT COUNT(*) AS total
            FROM incidents
            WHERE loitering = 1
            """
        )

        loitering = cursor.fetchone()["total"]


        # ----------------------------------------------------
        # OBJECTS
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT

                object_type,

                COUNT(*) AS count

            FROM incidents

            WHERE object_type IS NOT NULL

            GROUP BY object_type

            ORDER BY count DESC
            """
        )

        objects = cursor.fetchall()


        # ----------------------------------------------------
        # EVENT TYPES
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT

                event_type,

                COUNT(*) AS count

            FROM incidents

            WHERE event_type IS NOT NULL

            GROUP BY event_type

            ORDER BY count DESC
            """
        )

        event_types = cursor.fetchall()


        # ----------------------------------------------------
        # THREAT LEVELS
        # ----------------------------------------------------

        cursor.execute(
            """
            SELECT

                threat_level,

                COUNT(*) AS count

            FROM incidents

            WHERE threat_level IS NOT NULL

            GROUP BY threat_level

            ORDER BY count DESC
            """
        )

        threat_levels = cursor.fetchall()


        return {

            "success": True,

            "statistics": {

                "total_incidents":
                    total,

                "virtual_border_intrusions":
                    border,

                "restricted_zone_intrusions":
                    zone,

                "loitering_events":
                    loitering,

                "objects":
                    objects,

                "event_types":
                    event_types,

                "threat_levels":
                    threat_levels

            }

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
        log_level="info"
    )


# ============================================================
# RECENT INCIDENTS
# ============================================================

@app.get("/api/incidents/recent/{limit}")
def get_recent_incidents(
    limit: int = 10
):

    connection = None

    cursor = None


    try:

        if limit < 1:

            limit = 1


        if limit > 100:

            limit = 100


        connection = get_connection()

        cursor = connection.cursor(
            dictionary=True
        )


        query = f"""
        SELECT

            id,

            incident_id,

            timestamp,

            track_id,

            event_type,

            threat_score,

            threat_level,

            behavior,

            direction,

            zone_intrusion,

            border_crossed,

            loitering,

            reasons,

            status,

            evidence_path,

            evidence_timestamp,

            object_type,

            confidence

        FROM incidents

        ORDER BY timestamp DESC

        LIMIT {limit}
        """


        cursor.execute(query)

        incidents = cursor.fetchall()


        for incident in incidents:

            prepare_incident(
                incident
            )


        return {

            "success": True,

            "count": len(incidents),

            "incidents": incidents

        }


    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


    finally:

        if cursor:

            cursor.close()

        if connection:

            connection.close()


# ============================================================
# SERVER
# ============================================================

# Run:
#
# uvicorn main:app --reload
#
# ============================================================