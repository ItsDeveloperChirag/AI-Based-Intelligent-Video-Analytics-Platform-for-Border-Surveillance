import cv2
import threading
import time

from config import CAMERA_URL

from ai.tracker import Tracker
from ai.face_detector import FaceDetector
from ai.face_tracker import FaceTracker


# =========================================================
# Global Camera State
# =========================================================

latest_frame = None
running = True

frame_lock = threading.Lock()


# =========================================================
# Camera Worker
# =========================================================

def camera_worker():

    global latest_frame
    global running

    print("=" * 65)
    print("        IBVAP FACE + HUMAN TRACKING TEST")
    print("=" * 65)

    print("\n📡 Camera:")
    print(CAMERA_URL)

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(
        cv2.CAP_PROP_BUFFERSIZE,
        1
    )

    if not cap.isOpened():

        print("\n❌ Camera connection failed")

        running = False

        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:

            print("⚠️ Failed to read frame")

            time.sleep(0.1)

            continue

        with frame_lock:

            latest_frame = frame.copy()

    cap.release()

    print("📡 Camera stopped")


# =========================================================
# Main
# =========================================================

def main():

    global running

    # -----------------------------------------------------
    # Start Camera
    # -----------------------------------------------------

    camera_thread = threading.Thread(
        target=camera_worker,
        daemon=True
    )

    camera_thread.start()

    time.sleep(2)

    if not running:
        return

    # -----------------------------------------------------
    # Human Tracker
    # -----------------------------------------------------

    print("\nLoading human/object tracker...")

    tracker = Tracker(
        model_path="yolo11n.pt",
        confidence=0.35,
        image_size=640
    )

    print("✅ Tracker loaded")

    # -----------------------------------------------------
    # Face Detector
    # -----------------------------------------------------

    print("\nLoading face detector...")

    face_detector = FaceDetector(
        model_path=(
            "models/"
            "face_detection_yunet_2023mar.onnx"
        ),
        confidence=0.6
    )

    print("✅ Face detector loaded")

    # -----------------------------------------------------
    # Face Tracker
    # -----------------------------------------------------

    face_tracker = FaceTracker(
        face_detector=face_detector,

        # Ignore extremely small faces
        min_face_width=15,
        min_face_height=15
    )

    print("✅ Face-person association loaded")

    print("\n")
    print("=" * 65)
    print("        FACE + PERSON TRACKING STARTED")
    print("=" * 65)
    print("Press Q to quit\n")

    # -----------------------------------------------------
    # Main Processing Loop
    # -----------------------------------------------------

    while running:

        # -----------------------------------------------
        # Get latest frame
        # -----------------------------------------------

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        # -----------------------------------------------
        # Human/Object Tracking
        # -----------------------------------------------

        result = tracker.track(frame)

        tracks = tracker.get_tracks(result)

        # -----------------------------------------------
        # Keep persons only
        # -----------------------------------------------

        person_tracks = [
            track
            for track in tracks
            if track.get("class_name") == "person"
        ]

        # -----------------------------------------------
        # Face Detection inside each person
        # -----------------------------------------------

        face_results = face_tracker.process(
            frame,
            person_tracks
        )

        # -----------------------------------------------
        # Draw Person Tracking
        # -----------------------------------------------

        output = frame.copy()

        for person in person_tracks:

            x1, y1, x2, y2 = (
                person["bbox"]
            )

            person_id = (
                person["track_id"]
            )

            confidence = (
                person["confidence"]
            )

            cv2.rectangle(
                output,
                (x1, y1),
                (x2, y2),
                (255, 0, 0),
                2
            )

            label = (
                f"PERSON ID:{person_id} "
                f"{confidence:.2f}"
            )

            cv2.putText(
                output,
                label,
                (
                    x1,
                    max(25, y1 - 8)
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 0, 0),
                2
            )

        # -----------------------------------------------
        # Draw Face Results
        # -----------------------------------------------

        output = face_tracker.draw(
            output,
            face_results
        )

        # -----------------------------------------------
        # Statistics
        # -----------------------------------------------

        person_count = len(
            person_tracks
        )

        face_count = len(
            face_results
        )

        # -----------------------------------------------
        # Information Panel
        # -----------------------------------------------

        cv2.rectangle(
            output,
            (10, 10),
            (390, 70),
            (0, 0, 0),
            -1
        )

        cv2.putText(
            output,
            f"Persons: {person_count}",
            (20, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )

        cv2.putText(
            output,
            f"Faces: {face_count}",
            (210, 38),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )

        # -----------------------------------------------
        # Terminal Information
        # -----------------------------------------------

        if face_results:

            print("\n--------------------------------")

            for face in face_results:

                print(
                    f"Person ID: "
                    f"{face['person_id']} | "
                    f"FACE DETECTED | "
                    f"Confidence: "
                    f"{face['face_confidence']:.2f} | "
                    f"Size: "
                    f"{face['face_width']}x"
                    f"{face['face_height']}"
                )

        # -----------------------------------------------
        # Show Window
        # -----------------------------------------------

        cv2.imshow(
            "IBVAP - Face + Human Tracking",
            output
        )

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):

            running = False

            break

    cv2.destroyAllWindows()

    print("\n")
    print("=" * 65)
    print("        FACE + HUMAN TRACKING FINISHED")
    print("=" * 65)


# =========================================================
# Entry Point
# =========================================================

if __name__ == "__main__":
    main()