import os
import mysql.connector
from dotenv import load_dotenv


# ============================================================
# LOAD ENVIRONMENT VARIABLES
# ============================================================

load_dotenv()


# ============================================================
# DATABASE CONFIGURATION
# ============================================================

DB_CONFIG = {
    "host": os.getenv("DB_HOST"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME")
}


# ============================================================
# GET DATABASE CONNECTION
# ============================================================

def get_connection():

    return mysql.connector.connect(
        **DB_CONFIG
    )


# ============================================================
# CREATE INCIDENT TABLE
# ============================================================

def initialize_database():

    connection = None
    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor()

        query = """
        CREATE TABLE IF NOT EXISTS incidents (

            id INT AUTO_INCREMENT PRIMARY KEY,

            event_id VARCHAR(100) UNIQUE NOT NULL,

            event_type VARCHAR(100) NOT NULL,

            track_id INT,

            object_type VARCHAR(50),

            confidence FLOAT,

            direction VARCHAR(50),

            timestamp DATETIME NOT NULL,

            evidence_path VARCHAR(500),

            status VARCHAR(30) DEFAULT 'NEW'

        )
        """

        cursor.execute(query)

        connection.commit()

        print("✅ Incident table ready")

    except mysql.connector.Error as e:

        print("❌ Database error:")
        print(e)

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()


# ============================================================
# SAVE INCIDENT
# ============================================================

# ============================================================
# SAVE INCIDENT
# ============================================================

def save_incident(event):

    connection = None
    cursor = None

    try:

        connection = get_connection()

        cursor = connection.cursor()

        query = """
        INSERT INTO incidents
        (
            incident_id,
            timestamp,
            track_id,
            event_type,
            direction,
            evidence_path,
            status,
            object_type,
            confidence
        )
        VALUES
        (
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s
        )
        """

        values = (
            event["event_id"],
            event["timestamp"],
            event["track_id"],
            event["event_type"],
            event.get("direction"),
            event.get("evidence_path"),
            event.get("status", "OPEN"),
            event.get("object_type"),
            event.get("confidence")
        )

        cursor.execute(
            query,
            values
        )

        connection.commit()

        print("✅ Incident saved to database")

        return True

    except mysql.connector.Error as e:

        print("❌ Failed to save incident:")
        print(e)

        return False

    finally:

        if cursor:
            cursor.close()

        if connection:
            connection.close()