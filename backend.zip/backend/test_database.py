from database import initialize_database


print("===================================")
print("   IBVAP DATABASE TEST")
print("===================================")

initialize_database()

print("===================================")
print("   TEST FINISHED")
print("===================================")