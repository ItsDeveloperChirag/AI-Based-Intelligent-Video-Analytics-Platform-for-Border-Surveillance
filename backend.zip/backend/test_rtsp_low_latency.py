import cv2
import time
from config import CAMERA_URL


print("=" * 60)
print("IBVAP - RTSP LOW LATENCY TEST")
print("=" * 60)

print("\nCamera URL:")
print(CAMERA_URL)

# ---------------------------------------------------------
# Open RTSP
# ---------------------------------------------------------

cap = cv2.VideoCapture(CAMERA_URL, cv2.CAP_FFMPEG)

# Try minimum OpenCV buffer
cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

# Reduce decoding buffer where supported
cap.set(cv2.CAP_PROP_FPS, 15)

if not cap.isOpened():
    print("❌ RTSP camera connect nahi hua!")
    exit()

print("✅ RTSP connected")
print("Press Q to exit")


# ---------------------------------------------------------
# Variables
# ---------------------------------------------------------

frame_count = 0
start_time = time.time()


# ---------------------------------------------------------
# Main loop
# ---------------------------------------------------------

while True:

    ret, frame = cap.read()

    if not ret:
        print("❌ Frame read failed")
        break

    frame_count += 1

    # Resize only for display
    frame = cv2.resize(frame, (640, 480))

    elapsed = time.time() - start_time

    fps = frame_count / elapsed if elapsed > 0 else 0

    cv2.putText(
        frame,
        f"RTSP FPS: {fps:.1f}",
        (15, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        "RTSP LOW LATENCY TEST",
        (15, 60),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.imshow(
        "IBVAP - RTSP Test",
        frame
    )

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


cap.release()
cv2.destroyAllWindows()

print("\nRTSP test finished.")