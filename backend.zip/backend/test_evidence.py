import cv2

from ai.evidence import EvidenceManager


print("===================================")
print("   IBVAP EVIDENCE TEST")
print("===================================")


# Initialize evidence manager
evidence = EvidenceManager()


# Open camera
camera_url = "rtsp://192.168.1.8:554/live/ch00_1"

cap = cv2.VideoCapture(camera_url, cv2.CAP_FFMPEG)

cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)


if not cap.isOpened():
    print("❌ Camera could not be opened")
    exit()


print("✅ Camera connected")
print("Press SPACE to capture evidence")
print("Press Q to quit")


while True:

    ret, frame = cap.read()

    if not ret:
        print("❌ Failed to read frame")
        continue

    cv2.imshow("IBVAP Evidence Test", frame)

    key = cv2.waitKey(1) & 0xFF

    # SPACE = capture
    if key == 32:

        event_id = "TEST-EVIDENCE-001"

        saved_path = evidence.save_frame(
            frame,
            event_id
        )

        if saved_path:
            print()
            print("✅ Evidence test successful")
            print(f"Saved file: {saved_path}")
            print()

    # Q = quit
    elif key == ord("q"):
        break


cap.release()
cv2.destroyAllWindows()


print("===================================")
print("   TEST FINISHED")
print("===================================")