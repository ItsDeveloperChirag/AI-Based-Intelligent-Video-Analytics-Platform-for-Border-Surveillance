import cv2
from ai.plate_ocr import PlateOCR

IMAGE_PATH = "plate_test.jpg"

img = cv2.imread(IMAGE_PATH)

if img is None:
    print("❌ Image nahi mili:", IMAGE_PATH)
    exit()

print("Image size:", img.shape)

ocr = PlateOCR()

text, confidence = ocr.read(img)

print("\n==============================")
print("OCR RESULT")
print("==============================")
print("Plate Number:", text)
print("Confidence:", confidence)
print("==============================")

cv2.imshow("Plate Crop", img)
cv2.waitKey(0)
cv2.destroyAllWindows()