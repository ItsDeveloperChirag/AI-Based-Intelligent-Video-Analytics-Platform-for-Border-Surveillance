import cv2

print("Before importing Ultralytics:")
print(cv2.imshow)

from ultralytics import YOLO

print("\nAfter importing Ultralytics:")
print(cv2.imshow)

print("\nOpenCV version:", cv2.__version__)