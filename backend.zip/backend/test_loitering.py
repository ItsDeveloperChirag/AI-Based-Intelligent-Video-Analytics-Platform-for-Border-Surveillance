import time

from ai.loitering import LoiteringDetector


def main():

    print("=" * 60)
    print("        LOITERING DETECTOR TEST")
    print("=" * 60)

    detector = LoiteringDetector(
        loitering_time=5.0,
        movement_threshold=30.0
    )

    track_id = 1

    print("\nSimulating person standing in one area...\n")

    for i in range(8):

        # Person almost stationary
        center = (
            500 + (i % 2),
            300 + (i % 2)
        )

        result = detector.update(
            track_id,
            center
        )

        print(
            f"Track ID: {track_id} | "
            f"Time: {result['duration']:.1f}s | "
            f"Movement: {result['movement']:.1f}px | "
            f"Loitering: {result['loitering']}"
        )

        time.sleep(1)

    print("\n" + "=" * 60)

    final_status = detector.get_status(track_id)

    print("FINAL STATUS")
    print("=" * 60)

    print("Track ID :", final_status["track_id"])
    print("Duration :", final_status["duration"], "seconds")
    print("Movement :", final_status["movement"], "pixels")
    print("Loitering:", final_status["loitering"])

    print("=" * 60)


if __name__ == "__main__":
    main()