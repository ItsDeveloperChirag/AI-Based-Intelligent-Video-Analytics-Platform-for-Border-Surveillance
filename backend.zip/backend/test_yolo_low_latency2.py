import cv2
import time
import threading

from ultralytics import YOLO
from config import CAMERA_URL


# =========================================================
# SETTINGS
# =========================================================

MODEL_PATH = "yolo11n.pt"

CONFIDENCE = 0.35
IMG_SIZE = 640

# YOLO har 2nd frame par chalega
PROCESS_EVERY_N_FRAMES = 2


# =========================================================
# SHARED DATA
# =========================================================

latest_frame = None
latest_result = None

frame_lock = threading.Lock()
result_lock = threading.Lock()

running = True


# =========================================================
# CAMERA THREAD
# =========================================================

def camera_reader():

    global latest_frame
    global running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():
        print("❌ Camera connect nahi hua!")
        running = False
        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            continue

        # Resize before storing
        frame = cv2.resize(
            frame,
            (640, 480),
            interpolation=cv2.INTER_LINEAR
        )

        # IMPORTANT:
        # Only latest frame is stored.
        # Old frame gets replaced.
        with frame_lock:
            latest_frame = frame

    cap.release()


# =========================================================
# YOLO THREAD
# =========================================================

def yolo_processor():

    global latest_result
    global running

    print("Loading YOLO...")

    model = YOLO(MODEL_PATH)

    print("✅ YOLO loaded")

    last_processed_frame = None

    while running:

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        # Run YOLO
        results = model.predict(
            frame,
            conf=CONFIDENCE,
            imgsz=IMG_SIZE,
            verbose=False
        )

        result = results[0]

        # Store latest detection result
        with result_lock:
            latest_result = result


# =========================================================
# START THREADS
# =========================================================

print("=" * 60)
print("IBVAP - LOW LATENCY YOLO")
print("=" * 60)

camera_thread = threading.Thread(
    target=camera_reader,
    daemon=True
)

yolo_thread = threading.Thread(
    target=yolo_processor,
    daemon=True
)

camera_thread.start()
yolo_thread.start()


# =========================================================
# DISPLAY
# =========================================================

print("✅ Camera thread started")
print("✅ YOLO thread started")
print("Press Q to quit")

display_start = time.time()
display_frames = 0
fps = 0


while running:

    with frame_lock:

        if latest_frame is None:
            continue

        frame = latest_frame.copy()


    # -----------------------------------------------------
    # Get latest YOLO result
    # -----------------------------------------------------

    with result_lock:

        result = latest_result


    # -----------------------------------------------------
    # Draw latest detection
    # -----------------------------------------------------

    if result is not None:

        display_frame = result.plot()

    else:

        display_frame = frame


    # -----------------------------------------------------
    # FPS
    # -----------------------------------------------------

    display_frames += 1

    elapsed = time.time() - display_start

    if elapsed >= 1:

        fps = display_frames / elapsed

        display_frames = 0
        display_start = time.time()


    cv2.putText(
        display_frame,
        f"LIVE FPS: {fps:.1f}",
        (15, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        display_frame,
        "LOW LATENCY AI SURVEILLANCE",
        (15, 60),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.65,
        (0, 255, 0),
        2
    )


    # -----------------------------------------------------
    # Show
    # -----------------------------------------------------

    cv2.imshow(
        "IBVAP - AI Surveillance",
        display_frame
    )


    # -----------------------------------------------------
    # Exit
    # -----------------------------------------------------

    if cv2.waitKey(1) & 0xFF == ord("q"):

        running = False
        break


# =========================================================
# CLEANUP
# =========================================================

running = False

time.sleep(0.5)

cv2.destroyAllWindows()

print("\n" + "=" * 60)
print("IBVAP TEST FINISHED")
print("=" * 60)