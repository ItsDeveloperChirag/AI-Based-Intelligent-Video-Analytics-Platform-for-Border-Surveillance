import cv2
import sys
import time

from ultralytics import YOLO
from ai.camera import Camera


print("=" * 60)
print("IBVAP - YOLO CAMERA DETECTION TEST")
print("=" * 60)


# ---------------------------------------------------------
# Load YOLO model
# ---------------------------------------------------------

MODEL_PATH = "yolo11n.pt"

print("\nLoading YOLO model...")

try:
    model = YOLO(MODEL_PATH)
    print("✅ YOLO model loaded successfully")

except Exception as e:
    print("❌ Failed to load YOLO model")
    print("Error:", e)
    sys.exit(1)


# ---------------------------------------------------------
# Start camera
# ---------------------------------------------------------

print("\nStarting camera...")

try:
    camera = Camera()
    camera.start()
    print("✅ Camera started successfully")

except Exception as e:
    print("❌ Camera failed to start")
    print("Error:", e)
    sys.exit(1)


# ---------------------------------------------------------
# Detection settings
# ---------------------------------------------------------

CONFIDENCE = 0.35

# COCO classes
PERSON = 0
BICYCLE = 1
CAR = 2
MOTORCYCLE = 3
BUS = 5
TRUCK = 7

TARGET_CLASSES = {
    PERSON: "PERSON",
    BICYCLE: "BICYCLE",
    CAR: "CAR",
    MOTORCYCLE: "MOTORCYCLE",
    BUS: "BUS",
    TRUCK: "TRUCK"
}


# ---------------------------------------------------------
# FPS calculation
# ---------------------------------------------------------

frame_count = 0
start_time = time.time()

print("\nStarting YOLO detection...")
print("Press Q to exit.\n")


# ---------------------------------------------------------
# Main loop
# ---------------------------------------------------------

while True:

    frame = camera.read()

    if frame is None:
        print("❌ Empty frame received")
        continue

    frame_count += 1

    # -----------------------------------------------------
    # YOLO inference
    # -----------------------------------------------------

    results = model.predict(
        source=frame,
        conf=CONFIDENCE,
        imgsz=640,
        verbose=False
    )

    result = results[0]

    # -----------------------------------------------------
    # Draw detections
    # -----------------------------------------------------

    person_count = 0
    vehicle_count = 0

    if result.boxes is not None:

        for box in result.boxes:

            class_id = int(box.cls[0])
            confidence = float(box.conf[0])

            if class_id not in TARGET_CLASSES:
                continue

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            label_name = TARGET_CLASSES[class_id]

            # Count
            if class_id == PERSON:
                person_count += 1

            elif class_id in [
                CAR,
                MOTORCYCLE,
                BUS,
                TRUCK
            ]:
                vehicle_count += 1

            label = f"{label_name} {confidence:.2f}"

            # Draw bounding box
            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                (0, 255, 0),
                2
            )

            # Draw label
            cv2.putText(
                frame,
                label,
                (x1, max(y1 - 10, 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 0),
                2
            )


    # -----------------------------------------------------
    # FPS
    # -----------------------------------------------------

    elapsed = time.time() - start_time

    fps = (
        frame_count / elapsed
        if elapsed > 0
        else 0
    )


    # -----------------------------------------------------
    # Information panel
    # -----------------------------------------------------

    cv2.putText(
        frame,
        f"FPS: {fps:.1f}",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        f"PERSON: {person_count}",
        (20, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        f"VEHICLES: {vehicle_count}",
        (20, 105),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        "IBVAP - AI DETECTION",
        (20, 140),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )


    # -----------------------------------------------------
    # Display
    # -----------------------------------------------------

    cv2.imshow(
        "IBVAP - YOLO Detection",
        frame
    )


    # -----------------------------------------------------
    # Exit
    # -----------------------------------------------------

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# ---------------------------------------------------------
# Cleanup
# ---------------------------------------------------------

print("\nStopping...")

camera.stop()
cv2.destroyAllWindows()

print("\n" + "=" * 60)
print("YOLO CAMERA TEST COMPLETE")
print(f"Frames processed: {frame_count}")
print(f"Average FPS: {fps:.2f}")
print("=" * 60)