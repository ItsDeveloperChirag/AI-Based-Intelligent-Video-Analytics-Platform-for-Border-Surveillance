import cv2

RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"

print("Connecting to camera...")
print(RTSP_URL)

cap = cv2.VideoCapture(RTSP_URL)

if not cap.isOpened():
    print("❌ CAMERA CONNECTION FAILED")
    print("RTSP URL may be different.")
    exit()

print("✅ CAMERA CONNECTED!")

while True:
    ret, frame = cap.read()

    if not ret:
        print("❌ Failed to read frame")
        break

    cv2.imshow("V380 Camera Test", frame)

    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()