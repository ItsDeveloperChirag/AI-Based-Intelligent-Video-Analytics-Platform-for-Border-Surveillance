from ai.behavior import BehaviorAnalyzer


def print_result(title, result):

    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)

    print("Track ID :", result["track_id"])
    print("Object   :", result["object_type"])
    print("Behavior :", result["behavior"])
    print("Severity :", result["severity"])
    print("Movement :", result["movement"])
    print("Loitering:", result["loitering"])
    print("Border   :", result["border_crossed"])
    print("Zone     :", result["zone_intrusion"])
    print("Reasons  :")

    for reason in result["reasons"]:

        print("  -", reason)


def main():

    analyzer = BehaviorAnalyzer()

    # ======================================================
    # TEST 1 - NORMAL
    # ======================================================

    result = analyzer.analyze(
        track_id=1,
        object_type="person",
        movement=150
    )

    print_result(
        "TEST 1 - NORMAL",
        result
    )

    # ======================================================
    # TEST 2 - LOITERING
    # ======================================================

    result = analyzer.analyze(
        track_id=2,
        object_type="person",
        movement=10,
        loitering=True,
        loitering_duration=25
    )

    print_result(
        "TEST 2 - LOITERING",
        result
    )

    # ======================================================
    # TEST 3 - BORDER CROSSING
    # ======================================================

    result = analyzer.analyze(
        track_id=3,
        object_type="person",
        movement=120,
        border_crossed=True,
        direction="IN"
    )

    print_result(
        "TEST 3 - BORDER CROSSING",
        result
    )

    # ======================================================
    # TEST 4 - RESTRICTED ZONE
    # ======================================================

    result = analyzer.analyze(
        track_id=4,
        object_type="person",
        movement=100,
        zone_intrusion=True
    )

    print_result(
        "TEST 4 - RESTRICTED ZONE",
        result
    )

    # ======================================================
    # TEST 5 - MULTIPLE SIGNALS
    # ======================================================

    result = analyzer.analyze(
        track_id=5,
        object_type="person",
        movement=8,
        loitering=True,
        loitering_duration=40
    )

    print_result(
        "TEST 5 - MULTIPLE SUSPICIOUS SIGNALS",
        result
    )


if __name__ == "__main__":
    main()