import cv2
import sys

print("=" * 60)
print("IBVAP BACKEND CAMERA MODULE TEST")
print("=" * 60)

# ---------------------------------------------------------
# Import camera module from ai folder
# ---------------------------------------------------------

try:
    from ai.camera import Camera
    print("✅ ai.camera imported successfully")

except Exception as e:
    print("❌ Could not import ai.camera")
    print("Error:", e)
    sys.exit(1)


# ---------------------------------------------------------
# Create Camera object
# ---------------------------------------------------------

try:
    camera = Camera()
    print("✅ Camera object created")

except Exception as e:
    print("❌ Failed to create Camera object")
    print("Error:", e)
    sys.exit(1)


# ---------------------------------------------------------
# Start camera
# ---------------------------------------------------------

try:
    result = camera.start()

    print("Camera start result:", result)
    print("✅ Camera start command executed")

except Exception as e:
    print("❌ Camera start failed")
    print("Error:", e)
    sys.exit(1)


# ---------------------------------------------------------
# Read frames
# ---------------------------------------------------------

frame_count = 0

print()
print("Starting frame test...")
print("Press Q to stop.")
print()

while True:

    try:
        frame = camera.read()

    except Exception as e:
        print("❌ Error while reading frame:")
        print(e)
        break

    if frame is None:
        print("❌ Received empty frame")
        continue

    frame_count += 1

    height, width = frame.shape[:2]

    cv2.putText(
        frame,
        "IBVAP BACKEND CAMERA",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        f"Resolution: {width}x{height}",
        (20, 75),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        f"Frames: {frame_count}",
        (20, 110),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.imshow(
        "IBVAP - Backend Camera Test",
        frame
    )

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# ---------------------------------------------------------
# Stop camera
# ---------------------------------------------------------

print()
print("Stopping camera...")

try:
    camera.stop()
    print("✅ Camera stopped successfully")

except Exception as e:
    print("⚠️ Camera stop returned an error:")
    print(e)

cv2.destroyAllWindows()

print()
print("=" * 60)
print("TEST COMPLETE")
print(f"Frames received: {frame_count}")
print("=" * 60)