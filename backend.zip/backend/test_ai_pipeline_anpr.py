import cv2
import time

from ai.ai_pipeline import AIPipeline


RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"


def main():

    pipeline = AIPipeline(
        model_path="yolo11n.pt"
    )

    cap = cv2.VideoCapture(
        RTSP_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(
        cv2.CAP_PROP_BUFFERSIZE,
        1
    )

    if not cap.isOpened():

        print(
            "ERROR: Camera could not be opened"
        )

        return


    window_name = "AI PIPELINE + ANPR"

    cv2.namedWindow(
        window_name,
        cv2.WINDOW_NORMAL
    )

    cv2.resizeWindow(
        window_name,
        1100,
        700
    )


    try:

        while True:

            ret, frame = cap.read()

            if not ret:

                continue


            display_frame, objects = (
                pipeline.process_frame(
                    frame
                )
            )


            cv2.imshow(
                window_name,
                display_frame
            )


            key = (
                cv2.waitKey(1)
                & 0xFF
            )


            if key == ord("q"):

                break


    finally:

        pipeline.stop()

        cap.release()

        cv2.destroyAllWindows()


if __name__ == "__main__":

    main()