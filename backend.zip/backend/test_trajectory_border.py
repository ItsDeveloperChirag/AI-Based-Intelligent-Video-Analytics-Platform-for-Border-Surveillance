import cv2
import threading

from config import CAMERA_URL
from ai.tracker import Tracker
from ai.trajectory import TrajectoryTracker


# =========================================================
# GLOBALS
# =========================================================

latest_frame = None
latest_result = None

frame_lock = threading.Lock()
result_lock = threading.Lock()

running = True


# =========================================================
# BORDER STATE
# =========================================================

border_created = False
drawing_border = False

border_start = None
border_end = None


# =========================================================
# TRAJECTORY
# =========================================================

trajectory = TrajectoryTracker()


# =========================================================
# BORDER CROSSING
# =========================================================

previous_positions = {}

last_event = None


# =========================================================
# MOUSE CALLBACK
# =========================================================

def mouse_callback(event, x, y, flags, param):

    global drawing_border
    global border_created
    global border_start
    global border_end

    if event == cv2.EVENT_LBUTTONDOWN:

        drawing_border = True
        border_created = False

        border_start = (x, y)
        border_end = (x, y)

    elif event == cv2.EVENT_MOUSEMOVE:

        if drawing_border:

            border_end = (x, y)

    elif event == cv2.EVENT_LBUTTONUP:

        drawing_border = False
        border_created = True

        border_end = (x, y)

        print()
        print("=" * 60)
        print("✅ VIRTUAL BORDER CREATED")
        print(
            f"Start: {border_start} "
            f"End: {border_end}"
        )
        print("=" * 60)


# =========================================================
# POINT SIDE OF LINE
# =========================================================

def get_side(point):

    if not border_created:
        return 0

    px, py = point

    x1, y1 = border_start
    x2, y2 = border_end

    value = (
        (x2 - x1) * (py - y1)
        -
        (y2 - y1) * (px - x1)
    )

    if value > 0:
        return 1

    elif value < 0:
        return -1

    return 0


# =========================================================
# CHECK CROSSING
# =========================================================

def check_crossing(track_id, current_position):

    global previous_positions

    current_side = get_side(
        current_position
    )

    if current_side == 0:
        return None

    previous_side = previous_positions.get(
        track_id
    )

    previous_positions[
        track_id
    ] = current_side

    if previous_side is None:
        return None

    if previous_side == current_side:
        return None

    if previous_side == -1 and current_side == 1:

        return "SIDE_A_TO_SIDE_B"

    if previous_side == 1 and current_side == -1:

        return "SIDE_B_TO_SIDE_A"

    return None


# =========================================================
# CLEAR BORDER + TRAJECTORY
# =========================================================

def redraw_border():

    global border_created
    global border_start
    global border_end
    global previous_positions
    global last_event

    border_created = False

    border_start = None
    border_end = None

    # Very important:
    # clear old trajectory side history
    previous_positions.clear()

    # Clear trajectory tracker history
    try:
        trajectory.history.clear()
    except Exception:
        pass

    last_event = None

    print()
    print("🔄 Border cleared.")
    print("🖱️ Draw the new border using mouse drag.")


# =========================================================
# CAMERA THREAD
# =========================================================

def camera_thread():

    global latest_frame
    global running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(
        cv2.CAP_PROP_BUFFERSIZE,
        1
    )

    if not cap.isOpened():

        print("❌ Camera failed")

        running = False

        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            continue

        frame = cv2.resize(
            frame,
            (640, 480)
        )

        with frame_lock:

            latest_frame = frame

    cap.release()


# =========================================================
# TRACKING THREAD
# =========================================================

def tracking_thread():

    global latest_result
    global running

    tracker = Tracker()

    print("🚀 Tracking started")

    while running:

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        result = tracker.track(frame)

        with result_lock:

            latest_result = result


# =========================================================
# START THREADS
# =========================================================

threading.Thread(
    target=camera_thread,
    daemon=True
).start()

threading.Thread(
    target=tracking_thread,
    daemon=True
).start()


# =========================================================
# WINDOW
# =========================================================

window_name = (
    "IBVAP - USER DEFINED TRAJECTORY BORDER"
)

cv2.namedWindow(window_name)

cv2.setMouseCallback(
    window_name,
    mouse_callback
)


# =========================================================
# INSTRUCTIONS
# =========================================================

print()
print("=" * 65)
print("IBVAP - USER DEFINED TRAJECTORY BORDER")
print("=" * 65)
print()
print("🖱️ LEFT MOUSE DRAG  → Draw Border")
print("🔄 R               → Redraw Border")
print("❌ Q               → Exit")
print()
print("Border can be:")
print("  • Horizontal")
print("  • Vertical")
print("  • Diagonal")
print()
print("After drawing the border, cross it with a person.")
print("=" * 65)


# =========================================================
# MAIN LOOP
# =========================================================

while running:

    # -----------------------------------------------------
    # GET LATEST FRAME
    # -----------------------------------------------------

    with frame_lock:

        if latest_frame is None:
            continue

        frame = latest_frame.copy()


    # -----------------------------------------------------
    # GET RESULT
    # -----------------------------------------------------

    with result_lock:

        result = latest_result


    # -----------------------------------------------------
    # PROCESS DETECTIONS
    # -----------------------------------------------------

    if result is not None:

        frame = result.plot()

        if result.boxes is not None:

            for box in result.boxes:

                if box.id is None:
                    continue

                track_id = int(
                    box.id[0]
                )

                class_id = int(
                    box.cls[0]
                )

                class_name = result.names[
                    class_id
                ]

                # Only humans
                if class_name != "person":
                    continue

                x1, y1, x2, y2 = map(
                    int,
                    box.xyxy[0]
                )

                # Center point
                center_x = int(
                    (x1 + x2) / 2
                )

                center_y = int(
                    (y1 + y2) / 2
                )

                center = (
                    center_x,
                    center_y
                )


                # ------------------------------------------------
                # UPDATE TRAJECTORY
                # ------------------------------------------------

                try:

                    trajectory_data = (
                        trajectory.update(
                            track_id,
                            center
                        )
                    )

                    direction = (
                        trajectory_data[
                            "direction"
                        ]
                    )

                except Exception:

                    direction = "UNKNOWN"


                # ------------------------------------------------
                # BORDER CROSSING
                # ------------------------------------------------

                crossing = check_crossing(
                    track_id,
                    center
                )

                if crossing is not None:

                    last_event = (
                        f"🚨 BORDER CROSSING | "
                        f"ID={track_id} | "
                        f"{crossing}"
                    )

                    print()
                    print(last_event)


                # ------------------------------------------------
                # PERSON INFORMATION
                # ------------------------------------------------

                cv2.putText(
                    frame,
                    f"ID: {track_id}",
                    (
                        x1,
                        max(y1 - 40, 20)
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (255, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    f"Direction: {direction}",
                    (
                        x1,
                        max(y1 - 20, 20)
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (255, 255, 255),
                    2
                )

                # Center point
                cv2.circle(
                    frame,
                    center,
                    5,
                    (0, 255, 255),
                    -1
                )


    # =====================================================
    # DRAW BORDER
    # =====================================================

    if drawing_border:

        if border_start is not None and border_end is not None:

            cv2.line(
                frame,
                border_start,
                border_end,
                (255, 0, 0),
                3
            )

            cv2.putText(
                frame,
                "DRAWING BORDER...",
                (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 0, 0),
                2
            )


    elif border_created:

        cv2.line(
            frame,
            border_start,
            border_end,
            (255, 0, 0),
            3
        )

        cv2.putText(
            frame,
            "VIRTUAL BORDER",
            (
                border_start[0],
                max(border_start[1] - 10, 20)
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 0, 0),
            2
        )


    else:

        cv2.putText(
            frame,
            "Draw border using LEFT MOUSE DRAG",
            (20, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )


    # =====================================================
    # LAST EVENT
    # =====================================================

    if last_event is not None:

        cv2.putText(
            frame,
            last_event,
            (20, 450),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 0, 255),
            2
        )


    # =====================================================
    # DISPLAY
    # =====================================================

    cv2.imshow(
        window_name,
        frame
    )


    # =====================================================
    # KEYBOARD
    # =====================================================

    key = cv2.waitKey(1) & 0xFF

    # R = REDRAW
    if key == ord("r"):

        redraw_border()

    # Q = QUIT
    elif key == ord("q"):

        running = False

        break


cv2.destroyAllWindows()

print()
print("Test finished.")