"""Central configuration for IBVAP.

Change the camera IP in THIS FILE ONLY when the camera/network address changes.
The rest of the backend imports CAMERA_URL from here.
"""

# ============================================================
# CAMERA CONFIGURATION - CHANGE ONLY THIS VALUE
# ============================================================
CAMERA_IP = "192.168.1.8"
CAMERA_PORT = 554
CAMERA_PROTOCOL = "rtsp"

CAMERA_URL = "rtsp://192.168.1.8:554/live/ch00_1"

# ============================================================
# VIDEO / AI PERFORMANCE
# ============================================================
# Run YOLO on every Nth frame. Tracking remains persistent between inferences.
PROCESS_EVERY_N_FRAMES = 2
YOLO_IMAGE_SIZE = 640
YOLO_CONFIDENCE = 0.35

# Minimum time before the same track/event can create another incident.
INCIDENT_COOLDOWN_SECONDS = 5.0

# Fast JPEG evidence encoding quality (75-90 is generally enough for evidence).
EVIDENCE_JPEG_QUALITY = 85

# Local FastAPI endpoint used by the AI worker.
API_URL = "http://127.0.0.1:8000"
