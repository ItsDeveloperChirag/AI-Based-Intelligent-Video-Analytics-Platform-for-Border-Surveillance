import cv2
import threading
import time

from config import CAMERA_URL
from ai.license_plate_detector import LicensePlateDetector


# ============================================================
# CAMERA THREAD
# ============================================================

latest_frame = None
running = True


def camera_worker():

    global latest_frame
    global running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():

        print("❌ Camera connection failed")
        running = False
        return

    print("✅ Camera connected")
    print("📡 RTSP:", CAMERA_URL)

    while running:

        ret, frame = cap.read()

        if not ret:
            print("⚠️ Frame read failed")
            time.sleep(0.1)
            continue

        # Always keep only latest frame
        latest_frame = frame

    cap.release()


# ============================================================
# MAIN
# ============================================================

print("=" * 60)
print("       LICENSE PLATE DETECTION TEST")
print("=" * 60)

print()
print("Camera:", CAMERA_URL)
print()

# Load model
try:

    detector = LicensePlateDetector(
        model_path="models/license-plate-finetune-v1n.pt",
        confidence=0.35,
        image_size=640
    )

except Exception as e:

    print("❌ Model loading failed")
    print(e)
    exit()


# Start camera
camera_thread = threading.Thread(
    target=camera_worker,
    daemon=True
)

camera_thread.start()


# Wait for camera
print("Waiting for camera...")

while latest_frame is None and running:

    time.sleep(0.1)


if not running:

    print("❌ Camera thread stopped")
    exit()


print("🚀 License plate detection started")
print()
print("Press Q to quit")
print("=" * 60)


while running:

    frame = latest_frame

    if frame is None:
        continue

    # Detection
    plates = detector.detect(frame)

    # Draw
    display = frame.copy()

    for plate in plates:

        x1, y1, x2, y2 = plate["bbox"]

        confidence = plate["confidence"]

        label = f"PLATE {confidence:.2f}"

        cv2.rectangle(
            display,
            (x1, y1),
            (x2, y2),
            (0, 255, 255),
            2
        )

        cv2.putText(
            display,
            label,
            (x1, max(25, y1 - 10)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 255),
            2
        )

    # Information
    cv2.rectangle(
        display,
        (10, 10),
        (310, 55),
        (0, 0, 0),
        -1
    )

    cv2.putText(
        display,
        f"License Plates: {len(plates)}",
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 255),
        2
    )

    cv2.imshow(
        "ANPR - License Plate Detection",
        display
    )

    # Terminal information
    for plate in plates:

        print(
            f"Plate detected | "
            f"Confidence: {plate['confidence']:.2f} | "
            f"BBox: {plate['bbox']}"
        )

    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        running = False
        break


cv2.destroyAllWindows()

print()
print("🛑 License plate detection stopped")