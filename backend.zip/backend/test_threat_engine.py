from ai.threat_engine import ThreatEngine


def print_result(title, result):

    print("\n" + "=" * 65)
    print(title)
    print("=" * 65)

    print(
        "Threat Score :",
        result["threat_score"]
    )

    print(
        "Threat Level :",
        result["threat_level"]
    )

    print(
        "Reasons:"
    )

    if result["reasons"]:

        for reason in result["reasons"]:

            print(
                "  -",
                reason
            )

    else:

        print(
            "  - No suspicious activity"
        )


def main():

    engine = ThreatEngine()

    # ======================================================
    # TEST 1
    # NORMAL PERSON
    # ======================================================

    result = engine.calculate(
        object_type="person",
        movement=150,
        behavior="NORMAL"
    )

    print_result(
        "TEST 1 - NORMAL PERSON",
        result
    )

    # ======================================================
    # TEST 2
    # LOITERING
    # ======================================================

    result = engine.calculate(
        object_type="person",
        loitering=True,
        loitering_duration=25,
        movement=10,
        behavior="LOITERING"
    )

    print_result(
        "TEST 2 - LOITERING",
        result
    )

    # ======================================================
    # TEST 3
    # BORDER CROSSING
    # ======================================================

    result = engine.calculate(
        object_type="person",
        border_crossed=True,
        movement=100,
        behavior="BORDER_CROSSING"
    )

    print_result(
        "TEST 3 - BORDER CROSSING",
        result
    )

    # ======================================================
    # TEST 4
    # RESTRICTED ZONE
    # ======================================================

    result = engine.calculate(
        object_type="person",
        zone_intrusion=True,
        movement=100,
        behavior="RESTRICTED_ZONE_INTRUSION"
    )

    print_result(
        "TEST 4 - RESTRICTED ZONE",
        result
    )

    # ======================================================
    # TEST 5
    # MULTIPLE THREAT SIGNALS
    # ======================================================

    result = engine.calculate(
        object_type="person",
        border_crossed=True,
        zone_intrusion=True,
        loitering=True,
        loitering_duration=45,
        movement=8,
        behavior="SUSPICIOUS_ACTIVITY"
    )

    print_result(
        "TEST 5 - MULTIPLE THREAT SIGNALS",
        result
    )

    # ======================================================
    # TEST 6
    # VEHICLE IN RESTRICTED ZONE
    # ======================================================

    result = engine.calculate(
        object_type="car",
        zone_intrusion=True,
        movement=15,
        behavior="RESTRICTED_ZONE_INTRUSION"
    )

    print_result(
        "TEST 6 - VEHICLE IN RESTRICTED ZONE",
        result
    )


if __name__ == "__main__":

    main()