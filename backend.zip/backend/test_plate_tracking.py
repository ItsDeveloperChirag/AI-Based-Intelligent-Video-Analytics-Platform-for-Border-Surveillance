import cv2
import time
import threading

# =========================================================
# ORIGINAL OPENCV IMHOW
# =========================================================
# Ultralytics kabhi-kabhi cv2.imshow ko patch karta hai.
# Isliye original function pehle save kar rahe hain.

_original_imshow = cv2.imshow


# =========================================================
# AI MODULES
# =========================================================

from ai.tracker import Tracker
from ai.license_plate_detector import LicensePlateDetector
from ai.plate_tracker import PlateTracker
from ai.plate_ocr import PlateOCR


# =========================================================
# CONFIGURATION
# =========================================================

# Camera
RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"

# Window
WINDOW_NAME = "ANPR - License Plate Recognition"

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 500

# Models
YOLO_MODEL = "yolo11n.pt"

PLATE_MODEL = "models/license-plate-finetune-v1n.pt"

# Confidence
TRACK_CONFIDENCE = 0.25
PLATE_CONFIDENCE = 0.20

# OCR
OCR_INTERVAL = 1.0


# =========================================================
# SHARED CAMERA FRAME
# =========================================================

latest_frame = None

frame_lock = threading.Lock()

camera_running = True
camera_connected = False


# =========================================================
# CAMERA WORKER
# =========================================================

def camera_worker():

    global latest_frame
    global camera_running
    global camera_connected

    print()
    print("📡 Connecting to camera...")
    print(f"RTSP: {RTSP_URL}")

    # -----------------------------------------------------
    # Try FFMPEG first
    # -----------------------------------------------------

    cap = cv2.VideoCapture(
        RTSP_URL,
        cv2.CAP_FFMPEG
    )

    # -----------------------------------------------------
    # Fallback
    # -----------------------------------------------------

    if not cap.isOpened():

        print("⚠️ FFMPEG opening failed")
        print("🔄 Trying normal OpenCV backend...")

        cap.release()

        cap = cv2.VideoCapture(
            RTSP_URL
        )

    # -----------------------------------------------------
    # Connection failed
    # -----------------------------------------------------

    if not cap.isOpened():

        print("❌ Camera connection failed")

        camera_running = False

        return

    # -----------------------------------------------------
    # Reduce buffer
    # -----------------------------------------------------

    try:

        cap.set(
            cv2.CAP_PROP_BUFFERSIZE,
            1
        )

    except Exception:

        pass

    camera_connected = True

    print("✅ Camera connected")

    # =====================================================
    # CONTINUOUS CAMERA LOOP
    # =====================================================

    while camera_running:

        ret, frame = cap.read()

        if not ret:

            print("⚠️ Camera frame read failed")

            time.sleep(0.05)

            continue

        # -------------------------------------------------
        # IMPORTANT:
        # Store ONLY latest frame.
        # Old frames are discarded.
        # -------------------------------------------------

        with frame_lock:

            latest_frame = frame

    # =====================================================
    # RELEASE
    # =====================================================

    cap.release()

    print("📴 Camera thread stopped")


# =========================================================
# START CAMERA THREAD
# =========================================================

camera_thread = threading.Thread(
    target=camera_worker,
    daemon=True
)

camera_thread.start()


# =========================================================
# WAIT FOR CAMERA
# =========================================================

print()
print("⏳ Waiting for camera...")

while latest_frame is None and camera_running:

    time.sleep(0.1)


if not camera_running:

    print("❌ Unable to start camera")

    raise SystemExit


print("🎥 Camera frame received")


# =========================================================
# LOAD VEHICLE TRACKER
# =========================================================

print()
print("🚀 Loading AI models...")

tracker = Tracker(
    model_path=YOLO_MODEL,
    confidence=TRACK_CONFIDENCE,
    image_size=640
)

print("✅ Vehicle/person tracker loaded")


# =========================================================
# LOAD LICENSE PLATE DETECTOR
# =========================================================

plate_detector = LicensePlateDetector(
    model_path=PLATE_MODEL,
    confidence=PLATE_CONFIDENCE,
    image_size=640
)

print("✅ License plate detector loaded")


# =========================================================
# LOAD PLATE TRACKER
# =========================================================

plate_tracker = PlateTracker()

print("✅ Plate tracker loaded")


# =========================================================
# LOAD OCR
# =========================================================

ocr = PlateOCR()

print("✅ OCR engine loaded")


# =========================================================
# SYSTEM STARTED
# =========================================================

print()
print("==============================================")
print("🚀 ANPR SYSTEM STARTED")
print("==============================================")
print()
print("Q → Quit")
print()


# =========================================================
# CREATE WINDOW
# =========================================================

cv2.namedWindow(
    WINDOW_NAME,
    cv2.WINDOW_NORMAL
)

cv2.resizeWindow(
    WINDOW_NAME,
    WINDOW_WIDTH,
    WINDOW_HEIGHT
)


# =========================================================
# OCR CACHE
# =========================================================

ocr_cache = {}


# =========================================================
# FPS VARIABLES
# =========================================================

fps_time = time.time()

fps_counter = 0

fps = 0.0


# =========================================================
# FRAME COUNTER
# =========================================================

frame_count = 0


# =========================================================
# MAIN LOOP
# =========================================================

while True:

    # =====================================================
    # GET LATEST CAMERA FRAME
    # =====================================================

    with frame_lock:

        if latest_frame is None:

            continue

        frame = latest_frame.copy()


    frame_count += 1

    fps_counter += 1


    # =====================================================
    # FPS CALCULATION
    # =====================================================

    current_time = time.time()

    elapsed = current_time - fps_time

    if elapsed >= 1.0:

        fps = fps_counter / elapsed

        fps_counter = 0

        fps_time = current_time


    # =====================================================
    # VEHICLE / PERSON TRACKING
    # =====================================================

    result = tracker.track(
        frame
    )

    tracks = tracker.get_tracks(
        result
    )


    # =====================================================
    # FILTER VEHICLES
    # =====================================================

    vehicles = []

    for track in tracks:

        class_name = track["class_name"]

        if class_name in [
            "car",
            "motorcycle",
            "bus",
            "truck"
        ]:

            vehicles.append(track)


    # =====================================================
    # DRAW VEHICLES
    # =====================================================

    for vehicle in vehicles:

        x1, y1, x2, y2 = vehicle["bbox"]

        track_id = vehicle["track_id"]

        vehicle_type = vehicle["class_name"]

        confidence = vehicle["confidence"]


        # -------------------------------------------------
        # Vehicle box
        # -------------------------------------------------

        cv2.rectangle(
            frame,
            (x1, y1),
            (x2, y2),
            (0, 255, 0),
            2
        )


        # -------------------------------------------------
        # Vehicle label
        # -------------------------------------------------

        label = (
            f"ID {track_id} | "
            f"{vehicle_type} "
            f"{confidence:.2f}"
        )


        cv2.putText(
            frame,
            label,
            (x1, max(20, y1 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 255, 0),
            2
        )


    # =====================================================
    # LICENSE PLATE DETECTION
    # =====================================================

    plates = plate_detector.detect(
        frame
    )
    print(f"🟨 PLATES FOUND: {len(plates)}")


    # =====================================================
    # DEBUG PLATE COUNT
    # =====================================================

    if len(plates) > 0:

        print(
            f"🚘 Plate detected: "
            f"{len(plates)}"
        )


    # =====================================================
    # DRAW ALL DETECTED PLATES
    # =====================================================

    for plate in plates:
        print("🔎 OCR STARTING...")

        px1, py1, px2, py2 = plate["bbox"]

        plate_confidence = plate["confidence"]


        # -------------------------------------------------
        # Plate box
        # -------------------------------------------------

        cv2.rectangle(
            frame,
            (px1, py1),
            (px2, py2),
            (0, 255, 255),
            2
        )


        # -------------------------------------------------
        # Plate detection label
        # -------------------------------------------------

        cv2.putText(
            frame,
            f"PLATE {plate_confidence:.2f}",
            (
                px1,
                max(20, py1 - 6)
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.50,
            (0, 255, 255),
            2
        )


    # =====================================================
    # PLATE → VEHICLE ASSOCIATION
    # =====================================================

    associations = plate_tracker.associate(
        vehicles,
        plates
    )


    # =====================================================
    # DIRECT OCR
    # =====================================================
    #
    # IMPORTANT:
    # OCR runs directly on every detected plate.
    #
    # This means even if plate_tracker fails to associate
    # the plate with a vehicle, OCR can still read it.
    #
    # =====================================================

    for plate in plates:

        px1, py1, px2, py2 = plate["bbox"]


        # -------------------------------------------------
        # Image boundaries
        # -------------------------------------------------

        h, w = frame.shape[:2]

        px1 = max(0, px1)

        py1 = max(0, py1)

        px2 = min(w, px2)

        py2 = min(h, py2)


        # -------------------------------------------------
        # Invalid box
        # -------------------------------------------------

        if px2 <= px1 or py2 <= py1:

            continue


        # -------------------------------------------------
        # Crop plate
        # -------------------------------------------------

        plate_crop = frame[
            py1:py2,
            px1:px2
        ]


        if plate_crop.size == 0:

            continue


        # =================================================
        # OCR
        # =================================================

        try:

            # IMPORTANT:
            # Your PlateOCR class uses read()
            # and returns:
            #
            # text, confidence
            #

            plate_text, ocr_confidence = ocr.read(
                plate_crop
            )


            # -------------------------------------------------
            # Terminal debug
            # -------------------------------------------------

            print(
                f"🔎 OCR RESULT: "
                f"{plate_text} | "
                f"Confidence: {ocr_confidence:.2f}"
            )


            # -------------------------------------------------
            # If text found
            # -------------------------------------------------

            if plate_text:

                # Use plate bbox as cache key
                cache_key = (
                    px1,
                    py1,
                    px2,
                    py2
                )


                ocr_cache[cache_key] = {
                    "text": plate_text,
                    "confidence": ocr_confidence,
                    "last_time": current_time
                }


        except Exception as e:

            print(
                f"⚠️ OCR error: {e}"
            )


        # =================================================
        # SHOW OCR RESULT
        # =================================================

        cache_key = (
            px1,
            py1,
            px2,
            py2
        )


        cached = ocr_cache.get(
            cache_key
        )


        if cached:

            plate_text = cached["text"]

            ocr_confidence = cached["confidence"]


            # -------------------------------------------------
            # Number
            # -------------------------------------------------

            cv2.putText(
                frame,
                f"NUMBER: {plate_text}",
                (
                    px1,
                    py2 + 25
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (0, 255, 255),
                2
            )


            # -------------------------------------------------
            # OCR confidence
            # -------------------------------------------------

            cv2.putText(
                frame,
                f"OCR: {ocr_confidence:.2f}",
                (
                    px1,
                    py2 + 48
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.50,
                (0, 255, 255),
                2
            )


    # =====================================================
    # VEHICLE ID + PLATE INFORMATION
    # =====================================================

    for association in associations:

        vehicle_id = association["track_id"]

        vehicle_type = association["vehicle_type"]

        plate_bbox = association["plate_bbox"]


        px1, py1, px2, py2 = plate_bbox


        # -------------------------------------------------
        # Find nearest OCR cache
        # -------------------------------------------------

        best_text = None

        best_confidence = 0.0

        best_distance = float("inf")


        plate_center_x = (
            px1 + px2
        ) / 2

        plate_center_y = (
            py1 + py2
        ) / 2


        for cache_key, data in ocr_cache.items():

            cx1, cy1, cx2, cy2 = cache_key


            cache_center_x = (
                cx1 + cx2
            ) / 2

            cache_center_y = (
                cy1 + cy2
            ) / 2


            distance = (
                (plate_center_x - cache_center_x) ** 2
                +
                (plate_center_y - cache_center_y) ** 2
            )


            if distance < best_distance:

                best_distance = distance

                best_text = data["text"]

                best_confidence = data["confidence"]


        # -------------------------------------------------
        # Show vehicle ID + number
        # -------------------------------------------------

        if best_text:

            cv2.putText(
                frame,
                f"Vehicle ID: {vehicle_id}",
                (
                    px1,
                    max(20, py1 - 25)
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.50,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                f"{best_text}",
                (
                    px1,
                    py2 + 70
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (255, 255, 0),
                2
            )


    # =====================================================
    # INFORMATION PANEL
    # =====================================================

    cv2.rectangle(
        frame,
        (10, 10),
        (310, 90),
        (0, 0, 0),
        -1
    )


    cv2.putText(
        frame,
        f"FPS: {fps:.1f}",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 255),
        2
    )


    cv2.putText(
        frame,
        f"Vehicles: {len(vehicles)}",
        (20, 62),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 255),
        2
    )


    cv2.putText(
        frame,
        f"Plates: {len(plates)}",
        (170, 62),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.55,
        (255, 255, 255),
        2
    )


    # =====================================================
    # DISPLAY
    # =====================================================

    _original_imshow(
        WINDOW_NAME,
        frame
    )


    # =====================================================
    # KEYBOARD
    # =====================================================

    key = cv2.waitKey(1) & 0xFF


    if key == ord("q"):

        print()
        print("🛑 Stopping ANPR...")

        camera_running = False

        break


# =========================================================
# CLEANUP
# =========================================================

camera_running = False


camera_thread.join(
    timeout=2
)


cv2.destroyAllWindows()


print()
print("==============================================")
print("✅ ANPR STOPPED")
print("==============================================")