import cv2
import threading
import time

from config import CAMERA_URL
from ai.vehicle_classifier import VehicleClassifier


# =========================================================
# Latest-frame camera worker
# =========================================================

latest_frame = None
running = True

frame_lock = threading.Lock()


def camera_worker():
    global latest_frame
    global running

    print("=" * 50)
    print("   IBVAP VEHICLE CLASSIFICATION TEST")
    print("=" * 50)

    print("\n📡 Camera:")
    print(CAMERA_URL)

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():
        print("\n❌ Camera connection failed")
        running = False
        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            print("⚠️ Failed to read frame")
            time.sleep(0.1)
            continue

        with frame_lock:
            latest_frame = frame.copy()

    cap.release()

    print("📡 Camera stopped")


# =========================================================
# Main
# =========================================================

def main():

    global running

    # -----------------------------------------------------
    # Start camera thread
    # -----------------------------------------------------

    camera_thread = threading.Thread(
        target=camera_worker,
        daemon=True
    )

    camera_thread.start()

    # Wait for camera
    time.sleep(2)

    if not running:
        return

    # -----------------------------------------------------
    # Load vehicle classifier
    # -----------------------------------------------------

    classifier = VehicleClassifier(
        model_path="yolo11n.pt",
        confidence=0.35,
        image_size=640
    )

    print("\n🚗 Vehicle classification started")
    print("Press Q to quit\n")

    while running:

        # -------------------------------------------------
        # Get latest frame
        # -------------------------------------------------

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        # -------------------------------------------------
        # Detect vehicles
        # -------------------------------------------------

        output, vehicles = classifier.detect_and_draw(
            frame
        )

        # -------------------------------------------------
        # Display vehicle information
        # -------------------------------------------------

        vehicle_count = len(vehicles)

        cv2.rectangle(
            output,
            (10, 10),
            (300, 55),
            (0, 0, 0),
            -1
        )

        cv2.putText(
            output,
            f"Vehicles: {vehicle_count}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 255),
            2
        )

        # -------------------------------------------------
        # Print detections in terminal
        # -------------------------------------------------

        if vehicles:

            print("\n--------------------------------")

            for vehicle in vehicles:

                print(
                    f"Vehicle: "
                    f"{vehicle['vehicle_type']} | "
                    f"Confidence: "
                    f"{vehicle['confidence']:.2f}"
                )

        # -------------------------------------------------
        # Show frame
        # -------------------------------------------------

        cv2.imshow(
            "IBVAP - Vehicle Classification",
            output
        )

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            running = False
            break

    cv2.destroyAllWindows()

    print("\n================================")
    print("   TEST FINISHED")
    print("================================")


if __name__ == "__main__":
    main()