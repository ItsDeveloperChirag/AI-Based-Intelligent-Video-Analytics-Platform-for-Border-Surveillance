import cv2
import time

from ultralytics import YOLO

from ai.loitering import LoiteringDetector


# ============================================================
# CONFIG
# ============================================================

RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"

MODEL_PATH = "yolo11n.pt"

CONFIDENCE = 0.30
IMAGE_SIZE = 640

LOITERING_TIME = 10.0
MOVEMENT_THRESHOLD = 80.0


# ============================================================
# CAMERA THREAD
# ============================================================

from threading import Thread, Lock


class CameraStream:

    def __init__(self, url):

        self.url = url

        self.cap = None

        self.frame = None

        self.lock = Lock()

        self.running = False

        self.thread = None

    def start(self):

        self.cap = cv2.VideoCapture(
            self.url,
            cv2.CAP_FFMPEG
        )

        self.cap.set(
            cv2.CAP_PROP_BUFFERSIZE,
            1
        )

        if not self.cap.isOpened():

            raise RuntimeError(
                "❌ Cannot open RTSP camera"
            )

        self.running = True

        self.thread = Thread(
            target=self._update,
            daemon=True
        )

        self.thread.start()

        return self

    def _update(self):

        while self.running:

            ret, frame = self.cap.read()

            if not ret:
                time.sleep(0.01)
                continue

            with self.lock:

                self.frame = frame

    def read(self):

        with self.lock:

            if self.frame is None:
                return None

            return self.frame.copy()

    def stop(self):

        self.running = False

        if self.cap:

            self.cap.release()


# ============================================================
# MAIN
# ============================================================

def main():

    print("=" * 60)
    print("       LIVE LOITERING DETECTION")
    print("=" * 60)

    print("\nLoading YOLO...")

    model = YOLO(MODEL_PATH)

    print("✅ YOLO loaded")

    loitering_detector = LoiteringDetector(
        loitering_time=LOITERING_TIME,
        movement_threshold=MOVEMENT_THRESHOLD
    )

    camera = CameraStream(
        RTSP_URL
    ).start()

    window_name = "AI Border Surveillance - Loitering"

    cv2.namedWindow(
        window_name,
        cv2.WINDOW_NORMAL
    )

    cv2.resizeWindow(
        window_name,
        1100,
        700
    )

    print("\n📡 Camera started")
    print("Press Q to quit\n")

    try:

        while True:

            frame = camera.read()

            if frame is None:

                time.sleep(0.01)

                continue

            # ------------------------------------------------
            # YOLO + TRACKING
            # ------------------------------------------------

            results = model.track(
                source=frame,
                persist=True,
                tracker="bytetrack.yaml",
                conf=CONFIDENCE,
                imgsz=IMAGE_SIZE,
                classes=[0],
                verbose=False
            )

            result = results[0]

            if result.boxes is not None:

                boxes = result.boxes

                for box in boxes:

                    if box.id is None:
                        continue

                    track_id = int(
                        box.id[0]
                    )

                    confidence = float(
                        box.conf[0]
                    )

                    class_id = int(
                        box.cls[0]
                    )

                    object_type = model.names[
                        class_id
                    ]

                    x1, y1, x2, y2 = map(
                        int,
                        box.xyxy[0]
                    )

                    # ------------------------------------------------
                    # CENTER
                    # ------------------------------------------------

                    center_x = int(
                        (x1 + x2) / 2
                    )

                    center_y = int(
                        (y1 + y2) / 2
                    )

                    center = (
                        center_x,
                        center_y
                    )

                    # ------------------------------------------------
                    # LOITERING
                    # ------------------------------------------------

                    status = loitering_detector.update(
                        track_id,
                        center
                    )

                    is_loitering = status[
                        "loitering"
                    ]

                    duration = status[
                        "duration"
                    ]

                    movement = status[
                        "movement"
                    ]

                    # ------------------------------------------------
                    # DRAW TRACK
                    # ------------------------------------------------

                    cv2.rectangle(
                        frame,
                        (x1, y1),
                        (x2, y2),
                        (255, 255, 255),
                        2
                    )

                    cv2.circle(
                        frame,
                        center,
                        5,
                        (255, 255, 255),
                        -1
                    )

                    # ------------------------------------------------
                    # TEXT
                    # ------------------------------------------------

                    cv2.putText(
                        frame,
                        f"ID: {track_id}",
                        (x1, y1 - 35),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        f"Time: {duration:.1f}s",
                        (x1, y1 - 12),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (255, 255, 255),
                        2
                    )

                    # ------------------------------------------------
                    # LOITERING LABEL
                    # ------------------------------------------------

                    if is_loitering:

                        cv2.putText(
                            frame,
                            "LOITERING",
                            (x1, y2 + 25),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.7,
                            (0, 0, 255),
                            2
                        )

                    else:

                        cv2.putText(
                            frame,
                            "NORMAL",
                            (x1, y2 + 25),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6,
                            (0, 255, 0),
                            2
                        )

            # ------------------------------------------------
            # SYSTEM STATUS
            # ------------------------------------------------

            cv2.putText(
                frame,
                "AI BORDER SURVEILLANCE",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (255, 255, 255),
                2
            )

            cv2.putText(
                frame,
                "LOITERING DETECTION: ACTIVE",
                (20, 65),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )

            cv2.imshow(
                window_name,
                frame
            )

            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):

                break

    finally:

        camera.stop()

        cv2.destroyAllWindows()

        print("\n🛑 Loitering detection stopped")


if __name__ == "__main__":

    main()