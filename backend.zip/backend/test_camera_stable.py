import os

# Force RTSP over TCP
os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = (
    "rtsp_transport;tcp|"
    "fflags;nobuffer|"
    "flags;low_delay|"
    "stimeout;5000000"
)

import cv2
import time


RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"


# How many consecutive failed frames
# before reconnecting
MAX_FAILED_FRAMES = 3


def connect_camera():

    print()
    print("=" * 70)
    print("CONNECTING TO RTSP CAMERA")
    print("=" * 70)

    cap = cv2.VideoCapture(
        RTSP_URL,
        cv2.CAP_FFMPEG
    )

    try:
        cap.set(
            cv2.CAP_PROP_BUFFERSIZE,
            1
        )
    except:
        pass

    if not cap.isOpened():

        print("❌ Could not open camera")

        cap.release()

        return None

    print("✅ Camera connected")

    return cap


# ============================================================
# INITIAL CONNECTION
# ============================================================

cap = connect_camera()

if cap is None:

    raise SystemExit(
        "Could not connect to camera"
    )


print()
print("=" * 70)
print("STABLE RTSP TEST")
print("=" * 70)
print("Camera:", RTSP_URL)
print("Press Q to quit")
print()


frame_count = 0
failed_frames = 0

connection_number = 1

last_time = time.time()


# ============================================================
# MAIN LOOP
# ============================================================

while True:

    try:

        ret, frame = cap.read()

    except Exception as e:

        print(
            "⚠️ OpenCV read error:",
            e
        )

        ret = False
        frame = None


    # ========================================================
    # FRAME FAILED
    # ========================================================

    if not ret or frame is None:

        failed_frames += 1

        print(
            f"⚠️ Frame decoding failed "
            f"({failed_frames}/{MAX_FAILED_FRAMES})"
        )

        # ----------------------------------------------------
        # Too many failures
        # ----------------------------------------------------

        if failed_frames >= MAX_FAILED_FRAMES:

            print()
            print("=" * 70)
            print("🔄 RTSP STREAM LOST")
            print("=" * 70)
            print("Reconnecting camera...")
            print()

            # Release broken connection

            try:
                cap.release()
            except:
                pass

            cap = None

            # Small delay

            time.sleep(1)

            # Try reconnecting

            while cap is None:

                connection_number += 1

                print(
                    f"🔌 Connection attempt "
                    f"#{connection_number}"
                )

                cap = connect_camera()

                if cap is None:

                    print(
                        "❌ Reconnect failed"
                    )

                    time.sleep(2)

                else:

                    print(
                        "✅ Reconnected successfully"
                    )

                    failed_frames = 0

                    last_time = time.time()

                    print()

        else:

            # Don't hammer the camera
            time.sleep(0.05)

        continue


    # ========================================================
    # VALID FRAME
    # ========================================================

    failed_frames = 0

    frame_count += 1


    # ========================================================
    # FPS
    # ========================================================

    now = time.time()

    fps = 1.0 / max(
        now - last_time,
        0.001
    )

    last_time = now


    # ========================================================
    # DISPLAY
    # ========================================================

    cv2.putText(
        frame,
        f"FPS: {fps:.1f}",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        f"Frames: {frame_count}",
        (20, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        f"Connection: {connection_number}",
        (20, 105),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )


    cv2.imshow(
        "Stable RTSP Camera",
        frame
    )


    # ========================================================
    # KEYBOARD
    # ========================================================

    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):

        print()
        print("Stopping camera test...")

        break


# ============================================================
# CLEANUP
# ============================================================

try:
    cap.release()
except:
    pass


cv2.destroyAllWindows()


print()
print("=" * 70)
print("TEST FINISHED")
print("=" * 70)
print("Total frames:", frame_count)
print("Connections:", connection_number)
print("=" * 70)