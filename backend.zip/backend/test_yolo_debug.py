import cv2
import sys
import time

from ultralytics import YOLO
from ai.camera import Camera


print("=" * 60)
print("IBVAP - YOLO DEBUG TEST")
print("=" * 60)


# ---------------------------------------------------------
# Load YOLO
# ---------------------------------------------------------

print("\n[1] Loading YOLO model...")

try:
    model = YOLO("yolo11n.pt")
    print("✅ YOLO loaded")

except Exception as e:
    print("❌ YOLO loading failed")
    print(e)
    sys.exit(1)


# ---------------------------------------------------------
# Camera
# ---------------------------------------------------------

print("\n[2] Starting camera...")

try:
    camera = Camera()
    camera.start()
    print("✅ Camera started")

except Exception as e:
    print("❌ Camera failed")
    print(e)
    sys.exit(1)


print("\n[3] Starting detection...")
print("Stand clearly in front of the camera.")
print("Press Q to exit.\n")


frame_number = 0
last_print = time.time()


# ---------------------------------------------------------
# Loop
# ---------------------------------------------------------

while True:

    frame = camera.read()

    if frame is None:
        continue

    frame_number += 1

    # Resize for testing
    frame = cv2.resize(frame, (640, 480))

    # -----------------------------------------------------
    # YOLO
    # -----------------------------------------------------

    results = model(
        frame,
        conf=0.20,
        imgsz=640,
        verbose=False
    )

    result = results[0]

    detection_count = 0

    # -----------------------------------------------------
    # Print ALL detections
    # -----------------------------------------------------

    if result.boxes is not None:

        for box in result.boxes:

            detection_count += 1

            class_id = int(box.cls[0])
            confidence = float(box.conf[0])

            class_name = model.names[class_id]

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            print(
                f"DETECTED → "
                f"{class_name} | "
                f"confidence={confidence:.2f}"
            )

            # Draw EVERY detected object
            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"{class_name} {confidence:.2f}",
                (x1, max(y1 - 10, 20)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 0),
                2
            )


    # -----------------------------------------------------
    # Display detection count
    # -----------------------------------------------------

    cv2.putText(
        frame,
        f"Detections: {detection_count}",
        (15, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 0),
        2
    )

    cv2.putText(
        frame,
        "YOLO DEBUG",
        (15, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )


    cv2.imshow(
        "IBVAP - YOLO DEBUG",
        frame
    )


    # -----------------------------------------------------
    # Status every 2 seconds
    # -----------------------------------------------------

    if time.time() - last_print > 2:

        print(
            f"[STATUS] Frame={frame_number} "
            f"| Detections={detection_count}"
        )

        last_print = time.time()


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# ---------------------------------------------------------
# Cleanup
# ---------------------------------------------------------

camera.stop()
cv2.destroyAllWindows()

print("\n" + "=" * 60)
print("YOLO DEBUG TEST FINISHED")
print("=" * 60)
