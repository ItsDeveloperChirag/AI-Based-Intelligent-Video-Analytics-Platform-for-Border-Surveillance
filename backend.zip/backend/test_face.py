import cv2
import threading
import time

from config import CAMERA_URL
from ai.face_detector import FaceDetector


# =========================================================
# Global camera state
# =========================================================

latest_frame = None
running = True

frame_lock = threading.Lock()


# =========================================================
# Camera Thread
# =========================================================

def camera_worker():

    global latest_frame
    global running

    print("=" * 55)
    print("       IBVAP FACE DETECTION TEST")
    print("=" * 55)

    print("\n📡 Camera:")
    print(CAMERA_URL)

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(
        cv2.CAP_PROP_BUFFERSIZE,
        1
    )

    if not cap.isOpened():

        print("\n❌ Camera connection failed")

        running = False

        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:

            print("⚠️ Failed to read frame")

            time.sleep(0.1)

            continue

        with frame_lock:

            latest_frame = frame.copy()

    cap.release()

    print("📡 Camera stopped")


# =========================================================
# Main
# =========================================================

def main():

    global running

    # -----------------------------------------------------
    # Start camera
    # -----------------------------------------------------

    camera_thread = threading.Thread(
        target=camera_worker,
        daemon=True
    )

    camera_thread.start()

    # Give camera time to connect
    time.sleep(2)

    if not running:
        return

    # -----------------------------------------------------
    # Load face detector
    # -----------------------------------------------------

    try:

        face_detector = FaceDetector(
            model_path="models/face_detection_yunet_2023mar.onnx",
            confidence=0.6
        )

    except Exception as e:

        print("\n❌ Failed to load face detector")
        print(e)

        running = False

        return

    print("\n👤 Face detection started")
    print("Press Q to quit\n")

    # -----------------------------------------------------
    # Detection loop
    # -----------------------------------------------------

    while running:

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        # -------------------------------------------------
        # Detect faces
        # -------------------------------------------------

        output, faces = face_detector.detect_and_draw(
            frame
        )

        # -------------------------------------------------
        # Display count
        # -------------------------------------------------

        face_count = len(faces)

        cv2.rectangle(
            output,
            (10, 10),
            (280, 55),
            (0, 0, 0),
            -1
        )

        cv2.putText(
            output,
            f"Faces: {face_count}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (255, 255, 255),
            2
        )

        # -------------------------------------------------
        # Terminal output
        # -------------------------------------------------

        if faces:

            print("\n-------------------------------")

            for index, face in enumerate(
                faces,
                start=1
            ):

                print(
                    f"Face {index} | "
                    f"Confidence: "
                    f"{face['confidence']:.2f} | "
                    f"BBox: "
                    f"{face['bbox']}"
                )

        # -------------------------------------------------
        # Show camera
        # -------------------------------------------------

        cv2.imshow(
            "IBVAP - Face Detection",
            output
        )

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):

            running = False

            break

    cv2.destroyAllWindows()

    print("\n========================================")
    print("       FACE TEST FINISHED")
    print("========================================")


# =========================================================
# Entry point
# =========================================================

if __name__ == "__main__":
    main()