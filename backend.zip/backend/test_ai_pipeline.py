import cv2
import time

from ai.ai_pipeline import AIPipeline


def main():

    print("=" * 70)
    print("          AI BORDER SURVEILLANCE SYSTEM")
    print("=" * 70)

    print("\nLoading AI pipeline...\n")

    pipeline = AIPipeline(
        model_path="yolo11n.pt"
    )
    print("AIPipeline object created")

    if not pipeline.start():
        print()
        print("=" * 70)
        print("❌ PIPELINE COULD NOT START")
        print("=" * 70)

        print("Pipeline object:", pipeline)

        if hasattr(pipeline, "camera"):
            print("Camera object:", pipeline.camera)

            if hasattr(pipeline.camera, "cap"):
                print(
                    "Camera capture:",
                    pipeline.camera.cap
                )

                if pipeline.camera.cap is not None:
                    print(
                        "Camera opened:",
                        pipeline.camera.cap.isOpened()
                    )

        print()
        print("Please check the messages above.")
        print("=" * 70)

        return

    window_name = "AI Border Surveillance"

    cv2.namedWindow(
        window_name,
        cv2.WINDOW_NORMAL
    )

    cv2.resizeWindow(
        window_name,
        1100,
        700
    )

    print("Camera connected")
    print("AI pipeline active")

    print("\nControls:")
    print("Q = Quit")
    print()

    try:

        while True:

            frame, detections = pipeline.read()

            if frame is None:

                time.sleep(0.01)
                continue

            # --------------------------------------------------
            # HEADER
            # --------------------------------------------------

            cv2.putText(
                frame,
                "AI BORDER SURVEILLANCE",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.85,
                (255, 255, 255),
                2
            )

            cv2.putText(
                frame,
                f"Tracked Objects: {len(detections)}",
                (20, 65),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (255, 255, 255),
                2
            )

            # --------------------------------------------------
            # TERMINAL EVENTS
            # --------------------------------------------------

            for detection in detections:

                track_id = detection.get(
                    "track_id"
                )

                behavior = detection.get(
                    "behavior",
                    "NORMAL"
                )

                score = detection.get(
                    "threat_score",
                    0
                )

                level = detection.get(
                    "threat_level",
                    "LOW"
                )

                if (
                    behavior != "NORMAL"
                    or score > 0
                ):

                    print(
                        f"ID={track_id} | "
                        f"Behavior={behavior} | "
                        f"Threat={score} | "
                        f"Level={level}"
                    )

                    if detection.get(
                        "border_crossed",
                        False
                    ):

                        print(
                            "  BORDER CROSSING"
                        )

                        if detection.get(
                            "direction"
                        ):

                            print(
                                "  Direction:",
                                detection.get(
                                    "direction"
                                )
                            )

                    if detection.get(
                        "zone_intrusion",
                        False
                    ):

                        print(
                            "  RESTRICTED ZONE"
                        )

                    if detection.get(
                        "loitering",
                        False
                    ):

                        print(
                            "  LOITERING:",
                            f"{detection.get('loitering_duration', 0):.1f}s"
                        )

            # --------------------------------------------------
            # DISPLAY
            # --------------------------------------------------

            cv2.imshow(
                window_name,
                frame
            )

            key = (
                cv2.waitKey(1)
                & 0xFF
            )

            if key == ord("q"):
                break

    finally:

        pipeline.stop()

        cv2.destroyAllWindows()

        print(
            "\nAI pipeline stopped"
        )


if __name__ == "__main__":
    main()

