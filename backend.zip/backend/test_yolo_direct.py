import cv2
import threading
import time
from ultralytics import YOLO
from config import CAMERA_URL

# -----------------------------
# GLOBAL VARIABLES
# -----------------------------

latest_frame = None
latest_result = None

frame_lock = threading.Lock()
result_lock = threading.Lock()

running = True


# -----------------------------
# CAMERA THREAD
# -----------------------------

def camera_thread():

    global latest_frame, running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():
        print("❌ Camera failed")
        running = False
        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            continue

        # Keep resolution manageable
        frame = cv2.resize(
            frame,
            (640, 480)
        )

        # IMPORTANT:
        # Always replace old frame
        # Never build a queue
        with frame_lock:
            latest_frame = frame

    cap.release()


# -----------------------------
# YOLO THREAD
# -----------------------------

def yolo_thread():

    global latest_result, running

    print("Loading YOLO...")

    model = YOLO("yolo11n.pt")

    print("✅ YOLO loaded")

    last_processed = None

    while running:

        # Get ONLY latest frame
        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        # YOLO
        results = model.predict(
            source=frame,
            conf=0.25,
            imgsz=640,
            verbose=False,
            device="cpu"
        )

        result = results[0]

        # Store latest result
        with result_lock:
            latest_result = result


# -----------------------------
# START THREADS
# -----------------------------

t1 = threading.Thread(
    target=camera_thread,
    daemon=True
)

t2 = threading.Thread(
    target=yolo_thread,
    daemon=True
)

t1.start()
t2.start()

print("======================================")
print("IBVAP LOW LATENCY YOLO TEST")
print("======================================")
print("Stand in front of camera")
print("Press Q to exit")


# -----------------------------
# DISPLAY
# -----------------------------

while running:

    with frame_lock:

        if latest_frame is None:
            continue

        display_frame = latest_frame.copy()

    with result_lock:

        result = latest_result

    # Draw latest detection
    if result is not None:

        display_frame = result.plot()

    cv2.imshow(
        "IBVAP - LOW LATENCY YOLO",
        display_frame
    )

    if cv2.waitKey(1) & 0xFF == ord("q"):

        running = False
        break


cv2.destroyAllWindows()

print("Test finished.")