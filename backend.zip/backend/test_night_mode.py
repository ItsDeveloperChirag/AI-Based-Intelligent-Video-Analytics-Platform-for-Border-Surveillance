import os

os.environ["OPENCV_FFMPEG_CAPTURE_OPTIONS"] = (
    "rtsp_transport;tcp|"
    "fflags;nobuffer|"
    "flags;low_delay"
)

import cv2

from ai.night_movement import NightMovementDetector


RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"


detector = NightMovementDetector(
    brightness_threshold=110.0,
    saturation_threshold=18.0,
    min_movement=12.0,
    history_size=8,
    cooldown=5.0
)


cap = cv2.VideoCapture(
    RTSP_URL,
    cv2.CAP_FFMPEG
)

cap.set(
    cv2.CAP_PROP_BUFFERSIZE,
    1
)


if not cap.isOpened():
    raise RuntimeError(
        "Could not open RTSP camera"
    )


print("=" * 70)
print("NIGHT / IR MODE TEST")
print("=" * 70)
print("Press Q to quit")
print()


while True:

    ret, frame = cap.read()

    if not ret or frame is None:
        continue

    status = detector.analyze_frame(frame)

    if status["is_night"]:

        mode_text = (
            f"NIGHT MODE | "
            f"Brightness={status['brightness']:.1f} | "
            f"Saturation={status['saturation']:.1f}"
        )

        text_color = (255, 0, 255)

    else:

        mode_text = (
            f"DAY MODE | "
            f"Brightness={status['brightness']:.1f} | "
            f"Saturation={status['saturation']:.1f}"
        )

        text_color = (0, 255, 0)


    cv2.putText(
        frame,
        mode_text,
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.65,
        text_color,
        2
    )


    cv2.putText(
        frame,
        f"IR-LIKE: {status['ir_like']}",
        (20, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        text_color,
        2
    )


    cv2.imshow(
        "Night Mode Test",
        frame
    )


    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break


cap.release()

cv2.destroyAllWindows()