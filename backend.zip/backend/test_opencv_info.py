import cv2
import sys

print("=" * 60)
print("PYTHON / OPENCV INFORMATION")
print("=" * 60)

print("Python:")
print(sys.executable)

print("\nOpenCV version:")
print(cv2.__version__)

print("\nOpenCV location:")
print(cv2.__file__)

print("\nBuild information - GUI:")
info = cv2.getBuildInformation()

for line in info.splitlines():
    if "GUI:" in line or "Win32 UI" in line:
        print(line)

print("\nTesting GUI...")

img = cv2.imread("")

try:
    cv2.namedWindow("TEST", cv2.WINDOW_NORMAL)
    print("✅ namedWindow works")

    test = cv2.UMat(400, 600, cv2.CV_8UC3).get()

    cv2.imshow("TEST", test)
    print("✅ imshow works")

    cv2.waitKey(2000)

    cv2.destroyAllWindows()

except Exception as e:
    print("❌ GUI FAILED")
    print(e)