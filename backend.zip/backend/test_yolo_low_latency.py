import cv2
import time
from ultralytics import YOLO
from config import CAMERA_URL


# =========================================================
# SETTINGS
# =========================================================

MODEL_PATH = "yolo11n.pt"

# YOLO har frame par nahi chalega.
# 2 = every 2nd frame
PROCESS_EVERY_N_FRAMES = 2

CONFIDENCE = 0.35

# Smaller image = faster YOLO
IMG_SIZE = 640


# =========================================================
# LOAD MODEL
# =========================================================

print("=" * 60)
print("IBVAP - LOW LATENCY YOLO TEST")
print("=" * 60)

print("\nLoading YOLO...")

model = YOLO(MODEL_PATH)

print("✅ YOLO loaded")


# =========================================================
# OPEN RTSP
# =========================================================

print("\nConnecting camera...")

cap = cv2.VideoCapture(
    CAMERA_URL,
    cv2.CAP_FFMPEG
)

# Try to keep capture buffer very small
cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

if not cap.isOpened():
    print("❌ Camera connect nahi hua!")
    exit()

print("✅ Camera connected")
print("✅ Low-latency YOLO started")
print("Press Q to quit")


# =========================================================
# VARIABLES
# =========================================================

frame_count = 0
last_detection = None

fps_counter = 0
fps_start = time.time()
fps = 0


# =========================================================
# MAIN LOOP
# =========================================================

while True:

    ret, frame = cap.read()

    if not ret:
        print("❌ Frame nahi mil raha...")
        break

    frame_count += 1


    # -----------------------------------------------------
    # Resize BEFORE YOLO
    # -----------------------------------------------------

    frame = cv2.resize(
        frame,
        (640, 480),
        interpolation=cv2.INTER_LINEAR
    )


    # -----------------------------------------------------
    # YOLO ONLY EVERY Nth FRAME
    # -----------------------------------------------------

    if frame_count % PROCESS_EVERY_N_FRAMES == 0:

        results = model.predict(
            frame,
            conf=CONFIDENCE,
            imgsz=IMG_SIZE,
            verbose=False
        )

        last_detection = results[0].plot()


    # -----------------------------------------------------
    # DISPLAY
    # -----------------------------------------------------

    if last_detection is not None:

        display_frame = last_detection

    else:

        display_frame = frame


    # -----------------------------------------------------
    # FPS
    # -----------------------------------------------------

    fps_counter += 1

    elapsed = time.time() - fps_start

    if elapsed >= 1:

        fps = fps_counter / elapsed

        fps_counter = 0
        fps_start = time.time()


    cv2.putText(
        display_frame,
        f"FPS: {fps:.1f}",
        (15, 30),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )

    cv2.putText(
        display_frame,
        "LOW LATENCY YOLO",
        (15, 60),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (0, 255, 0),
        2
    )


    cv2.imshow(
        "IBVAP - Low Latency YOLO",
        display_frame
    )


    # -----------------------------------------------------
    # EXIT
    # -----------------------------------------------------

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# =========================================================
# CLEANUP
# =========================================================

cap.release()
cv2.destroyAllWindows()

print("\nCamera stopped.")
print("Test completed.")