import cv2
import time
import re
from pathlib import Path
from threading import Thread, Lock
from queue import Queue, Empty
from collections import Counter, defaultdict

from ultralytics import YOLO

from ai.plate_ocr import PlateOCR
from ai.license_plate_detector import LicensePlateDetector
from ai.plate_tracker import PlateTracker


# ============================================================
# CONFIGURATION
# ============================================================

RTSP_URL = "rtsp://192.168.1.8:554/live/ch00_1"

YOLO_MODEL = "yolo11n.pt"
PLATE_MODEL = "models/license-plate-finetune-v1n.pt"

VEHICLE_CONFIDENCE = 0.25
PLATE_CONFIDENCE = 0.20

IMAGE_SIZE = 640

# OCR request interval for same vehicle
OCR_INTERVAL = 2.0

# Maximum OCR jobs waiting
OCR_QUEUE_SIZE = 3

# Minimum physical plate crop size
MIN_PLATE_WIDTH = 20
MIN_PLATE_HEIGHT = 7

# Number of OCR observations to remember
MAX_OCR_HISTORY = 15

# Minimum confidence to consider a result strong
STRONG_OCR_CONFIDENCE = 0.45

# Minimum length for a strong plate candidate
MIN_STRONG_LENGTH = 6

# How many strong observations are needed
MIN_STABLE_OBSERVATIONS = 2

# Forget vehicle after this many seconds
VEHICLE_RESULT_TIMEOUT = 30


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

DEBUG_DIR = (
    BASE_DIR /
    "evidence" /
    "plate_debug"
)

DEBUG_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# CAMERA STREAM
# ============================================================

class CameraStream:

    def __init__(self, url):

        self.url = url

        self.cap = None

        self.latest_frame = None

        self.lock = Lock()

        self.running = False

        self.thread = None

    # --------------------------------------------------------

    def start(self):

        print("\n📡 Connecting to camera...")
        print("RTSP:", self.url)

        self.cap = cv2.VideoCapture(
            self.url,
            cv2.CAP_FFMPEG
        )

        try:

            self.cap.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )

        except Exception:

            pass

        if not self.cap.isOpened():

            print(
                "❌ Camera connection failed"
            )

            return False

        print(
            "✅ Camera connected"
        )

        self.running = True

        self.thread = Thread(
            target=self._update,
            daemon=True
        )

        self.thread.start()

        return True

    # --------------------------------------------------------

    def _update(self):

        while self.running:

            ret, frame = self.cap.read()

            if not ret:

                time.sleep(0.05)

                continue

            with self.lock:

                self.latest_frame = frame

    # --------------------------------------------------------

    def read(self):

        with self.lock:

            if self.latest_frame is None:

                return None

            return self.latest_frame.copy()

    # --------------------------------------------------------

    def stop(self):

        self.running = False

        if self.cap is not None:

            self.cap.release()


# ============================================================
# VEHICLE TRACKER
# ============================================================

class VehicleTracker:

    def __init__(self, model):

        self.model = model

    # --------------------------------------------------------

    def track(self, frame):

        results = self.model.track(
            source=frame,
            persist=True,
            tracker="bytetrack.yaml",
            conf=VEHICLE_CONFIDENCE,
            imgsz=IMAGE_SIZE,
            verbose=False
        )

        if not results:

            return []

        result = results[0]

        if result.boxes is None:

            return []

        vehicles = []

        names = self.model.names

        vehicle_classes = {
            "car",
            "motorcycle",
            "bus",
            "truck"
        }

        for box in result.boxes:

            try:

                class_id = int(
                    box.cls[0]
                )

                confidence = float(
                    box.conf[0]
                )

                class_name = names[
                    class_id
                ]

                if class_name not in vehicle_classes:

                    continue

                x1, y1, x2, y2 = map(
                    int,
                    box.xyxy[0]
                )

                track_id = -1

                if box.id is not None:

                    track_id = int(
                        box.id[0]
                    )

                vehicles.append({

                    "track_id": track_id,

                    "class_id": class_id,

                    "class_name": class_name,

                    "confidence": confidence,

                    "bbox": [
                        x1,
                        y1,
                        x2,
                        y2
                    ]

                })

            except Exception as e:

                print(
                    "⚠️ Vehicle parsing error:",
                    e
                )

        return vehicles


# ============================================================
# PLATE CROP
# ============================================================

def get_plate_crop(
    frame,
    bbox
):

    if frame is None:

        return None

    h, w = frame.shape[:2]

    x1, y1, x2, y2 = bbox

    # --------------------------------------------------------
    # Clamp coordinates
    # --------------------------------------------------------

    x1 = max(
        0,
        min(x1, w - 1)
    )

    y1 = max(
        0,
        min(y1, h - 1)
    )

    x2 = max(
        0,
        min(x2, w)
    )

    y2 = max(
        0,
        min(y2, h)
    )

    if x2 <= x1 or y2 <= y1:

        return None

    # --------------------------------------------------------
    # Padding
    # --------------------------------------------------------

    plate_width = x2 - x1

    plate_height = y2 - y1

    pad_x = int(
        plate_width * 0.20
    )

    pad_y = int(
        plate_height * 0.30
    )

    x1 = max(
        0,
        x1 - pad_x
    )

    y1 = max(
        0,
        y1 - pad_y
    )

    x2 = min(
        w,
        x2 + pad_x
    )

    y2 = min(
        h,
        y2 + pad_y
    )

    crop = frame[
        y1:y2,
        x1:x2
    ]

    if crop is None:

        return None

    if crop.size == 0:

        return None

    return crop


# ============================================================
# PLATE TEXT NORMALIZATION
# ============================================================

def normalize_plate(text):

    if text is None:

        return ""

    text = str(text).upper()

    # Remove spaces
    text = text.replace(
        " ",
        ""
    )

    # Keep only A-Z and 0-9
    text = re.sub(
        r"[^A-Z0-9]",
        "",
        text
    )

    return text


# ============================================================
# OCR RESULT MANAGER
# ============================================================

class OCRResultManager:

    def __init__(self):

        # ----------------------------------------------------
        # Raw observations
        #
        # vehicle_id -> [
        #   {
        #       text,
        #       confidence,
        #       timestamp
        #   }
        # ]
        # ----------------------------------------------------

        self.history = defaultdict(list)

        # ----------------------------------------------------
        # Final stable results
        #
        # vehicle_id -> {
        #     text,
        #     confidence,
        #     timestamp
        # }
        # ----------------------------------------------------

        self.stable_results = {}

        self.lock = Lock()

    # --------------------------------------------------------

    def add_result(
        self,
        vehicle_id,
        text,
        confidence
    ):

        text = normalize_plate(
            text
        )

        if not text:

            return

        confidence = float(
            confidence
        )

        now = time.time()

        with self.lock:

            history = self.history[
                vehicle_id
            ]

            history.append({

                "text": text,

                "confidence": confidence,

                "timestamp": now

            })

            # Keep only latest observations
            if len(history) > MAX_OCR_HISTORY:

                self.history[
                    vehicle_id
                ] = history[
                    -MAX_OCR_HISTORY:
                ]

            self._update_stable_result(
                vehicle_id
            )

    # --------------------------------------------------------

    def _update_stable_result(
        self,
        vehicle_id
    ):

        history = self.history[
            vehicle_id
        ]

        if not history:

            return

        # ----------------------------------------------------
        # Remove very old observations
        # ----------------------------------------------------

        now = time.time()

        history = [
            item
            for item in history
            if now - item["timestamp"]
            < VEHICLE_RESULT_TIMEOUT
        ]

        if not history:

            return

        # ----------------------------------------------------
        # Count exact OCR readings
        # ----------------------------------------------------

        counts = Counter()

        confidence_sum = defaultdict(float)

        for item in history:

            text = item["text"]

            confidence = item[
                "confidence"
            ]

            # Weight longer readings more
            length_weight = min(
                len(text) / 6.0,
                2.0
            )

            # Confidence weight
            confidence_weight = max(
                confidence,
                0.1
            )

            weight = (
                length_weight *
                confidence_weight
            )

            counts[text] += weight

            confidence_sum[
                text
            ] += confidence

        if not counts:

            return

        # ----------------------------------------------------
        # Find strongest candidate
        # ----------------------------------------------------

        candidates = []

        for text, weight in counts.items():

            exact_count = sum(
                1
                for item in history
                if item["text"] == text
            )

            avg_confidence = (
                confidence_sum[text] /
                max(exact_count, 1)
            )

            candidates.append({

                "text": text,

                "weight": weight,

                "count": exact_count,

                "confidence":
                    avg_confidence

            })

        candidates.sort(
            key=lambda x: (
                x["weight"],
                len(x["text"]),
                x["count"]
            ),
            reverse=True
        )

        best = candidates[0]

        best_text = best[
            "text"
        ]

        best_confidence = best[
            "confidence"
        ]

        best_count = best[
            "count"
        ]

        # ----------------------------------------------------
        # Existing result
        # ----------------------------------------------------

        existing = self.stable_results.get(
            vehicle_id
        )

        # ----------------------------------------------------
        # STRONG RESULT
        # ----------------------------------------------------

        is_strong = (
            len(best_text)
            >= MIN_STRONG_LENGTH
            and
            best_confidence
            >= STRONG_OCR_CONFIDENCE
            and
            best_count
            >= MIN_STABLE_OBSERVATIONS
        )

        if is_strong:

            # Always accept reliable long result
            self.stable_results[
                vehicle_id
            ] = {

                "text": best_text,

                "confidence":
                    best_confidence,

                "timestamp": now,

                "observations":
                    best_count

            }

            return

        # ----------------------------------------------------
        # If no strong result yet
        # ----------------------------------------------------

        if existing is None:

            # Don't immediately accept very short
            # readings such as 1939.
            if len(best_text) >= 6:

                self.stable_results[
                    vehicle_id
                ] = {

                    "text": best_text,

                    "confidence":
                        best_confidence,

                    "timestamp": now,

                    "observations":
                        best_count

                }

            return

        # ----------------------------------------------------
        # Existing strong result
        #
        # Never replace a good result with a weak
        # partial OCR result.
        # ----------------------------------------------------

        existing_text = existing[
            "text"
        ]

        existing_confidence = existing[
            "confidence"
        ]

        if len(best_text) < len(
            existing_text
        ):

            return

        if (
            len(best_text)
            == len(existing_text)
            and
            best_confidence
            < existing_confidence * 0.80
        ):

            return

        # ----------------------------------------------------
        # Replace only if candidate is clearly stronger
        # ----------------------------------------------------

        if (
            len(best_text)
            > len(existing_text)
            and
            best_confidence
            >= 0.40
        ):

            self.stable_results[
                vehicle_id
            ] = {

                "text": best_text,

                "confidence":
                    best_confidence,

                "timestamp": now,

                "observations":
                    best_count

            }

    # --------------------------------------------------------

    def get(
        self,
        vehicle_id
    ):

        with self.lock:

            return self.stable_results.get(
                vehicle_id
            )

    # --------------------------------------------------------

    def get_history(
        self,
        vehicle_id
    ):

        with self.lock:

            return list(
                self.history.get(
                    vehicle_id,
                    []
                )
            )


# ============================================================
# BACKGROUND OCR WORKER
# ============================================================

class OCRWorker:

    def __init__(self):

        print(
            "\n🔤 Starting background OCR..."
        )

        self.ocr = PlateOCR()

        self.queue = Queue(
            maxsize=OCR_QUEUE_SIZE
        )

        self.results = (
            OCRResultManager()
        )

        self.running = True

        self.last_request = {}

        self.request_lock = Lock()

        self.counter = 0

        self.thread = Thread(
            target=self._worker,
            daemon=True
        )

        self.thread.start()

        print(
            "✅ Background OCR ready"
        )

    # --------------------------------------------------------

    def can_submit(
        self,
        vehicle_id
    ):

        now = time.time()

        with self.request_lock:

            last = self.last_request.get(
                vehicle_id,
                0
            )

            if (
                now - last
                < OCR_INTERVAL
            ):

                return False

            self.last_request[
                vehicle_id
            ] = now

        return True

    # --------------------------------------------------------

    def submit(
        self,
        vehicle_id,
        plate_crop
    ):

        if vehicle_id < 0:

            return False

        if plate_crop is None:

            return False

        if plate_crop.size == 0:

            return False

        h, w = plate_crop.shape[:2]

        if w < MIN_PLATE_WIDTH:

            return False

        if h < MIN_PLATE_HEIGHT:

            return False

        if not self.can_submit(
            vehicle_id
        ):

            return False

        # Important:
        # make independent copy
        crop_copy = plate_crop.copy()

        job = (
            vehicle_id,
            crop_copy
        )

        try:

            self.queue.put_nowait(
                job
            )

            return True

        except:

            # Queue full.
            # Main video loop NEVER waits.
            return False

    # --------------------------------------------------------

    def _worker(self):

        while self.running:

            try:

                vehicle_id, plate_crop = (
                    self.queue.get(
                        timeout=0.2
                    )
                )

            except Empty:

                continue

            try:

                h, w = plate_crop.shape[:2]

                print(
                    f"\n🔤 OCR processing "
                    f"Vehicle {vehicle_id} "
                    f"({w}x{h})"
                )

                # ------------------------------------------------
                # Save debug crop
                # ------------------------------------------------

                self.counter += 1

                debug_path = (
                    DEBUG_DIR /
                    f"vehicle_{vehicle_id}_"
                    f"{self.counter}.jpg"
                )

                cv2.imwrite(
                    str(debug_path),
                    plate_crop
                )

                # ------------------------------------------------
                # OCR
                # ------------------------------------------------

                text, confidence = (
                    self.ocr.read(
                        plate_crop
                    )
                )

                # ------------------------------------------------
                # OCR returned result
                # ------------------------------------------------

                if text:

                    text = normalize_plate(
                        text
                    )

                    print(
                        f"🔎 OCR candidate | "
                        f"Vehicle={vehicle_id} | "
                        f"{text} | "
                        f"conf={confidence:.2f}"
                    )

                    self.results.add_result(
                        vehicle_id,
                        text,
                        confidence
                    )

                    # Show current stable result
                    stable = (
                        self.results.get(
                            vehicle_id
                        )
                    )

                    if stable:

                        print(
                            f"✅ STABLE PLATE | "
                            f"Vehicle={vehicle_id} | "
                            f"NUMBER="
                            f"{stable['text']} | "
                            f"conf="
                            f"{stable['confidence']:.2f} | "
                            f"observations="
                            f"{stable['observations']}"
                        )

                else:

                    print(
                        f"❌ OCR no text | "
                        f"Vehicle={vehicle_id}"
                    )

            except Exception as e:

                print(
                    f"⚠️ OCR worker error "
                    f"Vehicle {vehicle_id}:",
                    e
                )

            finally:

                self.queue.task_done()

    # --------------------------------------------------------

    def get_result(
        self,
        vehicle_id
    ):

        return self.results.get(
            vehicle_id
        )

    # --------------------------------------------------------

    def stop(self):

        self.running = False


# ============================================================
# DRAW TEXT
# ============================================================

def draw_text(
    frame,
    text,
    position,
    scale=0.6,
    thickness=2
):

    cv2.putText(
        frame,
        text,
        position,
        cv2.FONT_HERSHEY_SIMPLEX,
        scale,
        (0, 255, 0),
        thickness,
        cv2.LINE_AA
    )


# ============================================================
# MAIN
# ============================================================

def main():

    print("\n")
    print("=" * 70)
    print("             AI BORDER ANPR SYSTEM")
    print("      NON-BLOCKING + MULTI-FRAME OCR")
    print("=" * 70)

    # ========================================================
    # LOAD VEHICLE MODEL
    # ========================================================

    print(
        "\n🚗 Loading YOLO vehicle model..."
    )

    vehicle_model = YOLO(
        str(
            BASE_DIR /
            YOLO_MODEL
        )
    )

    print(
        "✅ YOLO vehicle model loaded"
    )

    # ========================================================
    # LOAD PLATE DETECTOR
    # ========================================================

    print(
        "\n🔲 Loading license plate detector..."
    )

    plate_detector = (
        LicensePlateDetector(
            model_path=PLATE_MODEL,
            confidence=PLATE_CONFIDENCE,
            image_size=IMAGE_SIZE
        )
    )

    print(
        "✅ License plate detector loaded"
    )

    # ========================================================
    # PLATE TRACKER
    # ========================================================

    plate_tracker = PlateTracker()

    print(
        "✅ Plate tracker loaded"
    )

    # ========================================================
    # VEHICLE TRACKER
    # ========================================================

    vehicle_tracker = VehicleTracker(
        vehicle_model
    )

    # ========================================================
    # OCR WORKER
    # ========================================================

    ocr_worker = OCRWorker()

    # ========================================================
    # CAMERA
    # ========================================================

    camera = CameraStream(
        RTSP_URL
    )

    if not camera.start():

        return

    # ========================================================
    # WINDOW
    # ========================================================

    window_name = (
        "AI BORDER ANPR"
    )

    cv2.namedWindow(
        window_name,
        cv2.WINDOW_NORMAL
    )

    cv2.resizeWindow(
        window_name,
        1100,
        700
    )

    print("\n")
    print("=" * 70)
    print("🚀 ANPR SYSTEM STARTED")
    print("=" * 70)
    print("Q → Quit")
    print("")
    print(
        "ℹ️ OCR runs in background."
    )
    print(
        "ℹ️ Multiple OCR readings are combined."
    )
    print("")

    # ========================================================
    # FPS
    # ========================================================

    fps_counter = 0

    fps_time = time.time()

    fps = 0

    # ========================================================
    # MAIN LOOP
    # ========================================================

    try:

        while True:

            # =================================================
            # GET LATEST FRAME
            # =================================================

            frame = camera.read()

            if frame is None:

                time.sleep(
                    0.005
                )

                continue

            # =================================================
            # VEHICLE TRACKING
            # =================================================

            vehicles = (
                vehicle_tracker.track(
                    frame
                )
            )

            # =================================================
            # PLATE DETECTION
            # =================================================

            plates = (
                plate_detector.detect(
                    frame
                )
            )

            # =================================================
            # PLATE → VEHICLE
            # =================================================

            associations = (
                plate_tracker.associate(
                    vehicles,
                    plates
                )
            )

            # =================================================
            # DRAW VEHICLES
            # =================================================

            for vehicle in vehicles:

                x1, y1, x2, y2 = (
                    vehicle["bbox"]
                )

                track_id = (
                    vehicle["track_id"]
                )

                class_name = (
                    vehicle["class_name"]
                )

                confidence = (
                    vehicle["confidence"]
                )

                # Vehicle box
                cv2.rectangle(
                    frame,
                    (x1, y1),
                    (x2, y2),
                    (255, 0, 0),
                    2
                )

                label = (
                    f"{class_name} "
                    f"ID:{track_id} "
                    f"{confidence:.2f}"
                )

                draw_text(
                    frame,
                    label,
                    (
                        x1,
                        max(
                            20,
                            y1 - 8
                        )
                    ),
                    0.55,
                    2
                )

            # =================================================
            # DRAW PLATES
            # =================================================

            for plate in plates:

                px1, py1, px2, py2 = (
                    plate["bbox"]
                )

                pconf = (
                    plate["confidence"]
                )

                cv2.rectangle(
                    frame,
                    (px1, py1),
                    (px2, py2),
                    (0, 255, 255),
                    2
                )

                draw_text(
                    frame,
                    f"PLATE {pconf:.2f}",
                    (
                        px1,
                        max(
                            20,
                            py1 - 5
                        )
                    ),
                    0.5,
                    2
                )

            # =================================================
            # SUBMIT PLATES TO OCR
            # =================================================

            for association in associations:

                vehicle_id = (
                    association["track_id"]
                )

                plate_bbox = (
                    association[
                        "plate_bbox"
                    ]
                )

                # Current frame crop
                plate_crop = (
                    get_plate_crop(
                        frame,
                        plate_bbox
                    )
                )

                if plate_crop is None:

                    continue

                # ------------------------------------------------
                # Background OCR submission
                #
                # IMPORTANT:
                # This DOES NOT WAIT.
                # ------------------------------------------------

                ocr_worker.submit(
                    vehicle_id,
                    plate_crop
                )

            # =================================================
            # DISPLAY STABLE OCR RESULTS
            # =================================================

            for vehicle in vehicles:

                vehicle_id = (
                    vehicle["track_id"]
                )

                stable = (
                    ocr_worker.get_result(
                        vehicle_id
                    )
                )

                if stable is None:

                    continue

                text = stable[
                    "text"
                ]

                confidence = stable[
                    "confidence"
                ]

                observations = stable[
                    "observations"
                ]

                vx1, vy1, vx2, vy2 = (
                    vehicle["bbox"]
                )

                # ------------------------------------------------
                # Green number
                # ------------------------------------------------

                number_y = min(
                    frame.shape[0] - 45,
                    vy2 + 25
                )

                cv2.rectangle(
                    frame,
                    (
                        vx1,
                        max(
                            0,
                            number_y - 22
                        )
                    ),
                    (
                        min(
                            frame.shape[1],
                            vx1 + 350
                        ),
                        number_y + 8
                    ),
                    (0, 0, 0),
                    -1
                )

                draw_text(
                    frame,
                    f"NUMBER: {text}",
                    (
                        vx1 + 5,
                        number_y
                    ),
                    0.70,
                    2
                )

                # ------------------------------------------------
                # Confidence
                # ------------------------------------------------

                confidence_y = min(
                    frame.shape[0] - 10,
                    vy2 + 48
                )

                draw_text(
                    frame,
                    (
                        f"OCR: "
                        f"{confidence:.2f} "
                        f"| READS: "
                        f"{observations}"
                    ),
                    (
                        vx1,
                        confidence_y
                    ),
                    0.50,
                    2
                )

            # =================================================
            # FPS
            # =================================================

            fps_counter += 1

            current_time = time.time()

            elapsed = (
                current_time -
                fps_time
            )

            if elapsed >= 1.0:

                fps = (
                    fps_counter /
                    elapsed
                )

                fps_counter = 0

                fps_time = (
                    current_time
                )

            # =================================================
            # STATUS BAR
            # =================================================

            status = (
                f"FPS: {fps:.1f} | "
                f"Vehicles: {len(vehicles)} | "
                f"Plates: {len(plates)} | "
                f"OCR Queue: "
                f"{ocr_worker.queue.qsize()}"
            )

            cv2.rectangle(
                frame,
                (0, 0),
                (
                    frame.shape[1],
                    40
                ),
                (0, 0, 0),
                -1
            )

            draw_text(
                frame,
                status,
                (10, 28),
                0.65,
                2
            )

            # =================================================
            # SHOW FRAME
            # =================================================

            cv2.imshow(
                window_name,
                frame
            )

            key = (
                cv2.waitKey(1)
                & 0xFF
            )

            if key == ord("q"):

                print(
                    "\n🛑 Stopping ANPR..."
                )

                break

    except KeyboardInterrupt:

        print(
            "\n🛑 Stopped by user"
        )

    except Exception as e:

        print(
            "\n❌ SYSTEM ERROR:",
            e
        )

        import traceback

        traceback.print_exc()

    finally:

        camera.stop()

        ocr_worker.stop()

        cv2.destroyAllWindows()

        print(
            "\n✅ ANPR system stopped"
        )


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    main()