import cv2
import threading

from config import CAMERA_URL
from ai.tracker import Tracker


# ==========================================
# GLOBAL VARIABLES
# ==========================================

latest_frame = None
latest_result = None

frame_lock = threading.Lock()
result_lock = threading.Lock()

running = True


# ==========================================
# CAMERA THREAD
# ==========================================

def camera_thread():

    global latest_frame, running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():

        print("❌ Camera failed")
        running = False
        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            continue

        frame = cv2.resize(
            frame,
            (640, 480)
        )

        # Always keep newest frame
        with frame_lock:
            latest_frame = frame

    cap.release()


# ==========================================
# TRACKING THREAD
# ==========================================

def tracking_thread():

    global latest_result, running

    tracker = Tracker()

    print("🚀 Tracking started")

    while running:

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        result = tracker.track(frame)

        with result_lock:
            latest_result = result


# ==========================================
# START THREADS
# ==========================================

camera_worker = threading.Thread(
    target=camera_thread,
    daemon=True
)

tracking_worker = threading.Thread(
    target=tracking_thread,
    daemon=True
)

camera_worker.start()
tracking_worker.start()


print("=" * 60)
print("IBVAP - OBJECT TRACKING TEST")
print("=" * 60)
print("Walk in front of the camera")
print("Move left/right")
print("Press Q to exit")
print("=" * 60)


# ==========================================
# DISPLAY
# ==========================================

while running:

    with frame_lock:

        if latest_frame is None:
            continue

        display_frame = latest_frame.copy()

    with result_lock:

        result = latest_result

    if result is not None:

        display_frame = result.plot()

    cv2.imshow(
        "IBVAP - Object Tracking",
        display_frame
    )

    if cv2.waitKey(1) & 0xFF == ord("q"):

        running = False
        break


cv2.destroyAllWindows()

print("Tracking test finished.")