import cv2
import threading

from config import CAMERA_URL
from ai.tracker import Tracker
from ai.zone import RestrictedZone


latest_frame = None
latest_result = None

frame_lock = threading.Lock()
result_lock = threading.Lock()

running = True


# ==========================================
# CAMERA
# ==========================================

def camera_thread():

    global latest_frame, running

    cap = cv2.VideoCapture(
        CAMERA_URL,
        cv2.CAP_FFMPEG
    )

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

    if not cap.isOpened():

        print("❌ Camera failed")
        running = False
        return

    print("✅ Camera connected")

    while running:

        ret, frame = cap.read()

        if not ret:
            continue

        frame = cv2.resize(
            frame,
            (640, 480)
        )

        with frame_lock:
            latest_frame = frame

    cap.release()


# ==========================================
# TRACKING
# ==========================================

def tracking_thread():

    global latest_result, running

    tracker = Tracker()

    print("🚀 Tracking started")

    while running:

        with frame_lock:

            if latest_frame is None:
                continue

            frame = latest_frame.copy()

        result = tracker.track(frame)

        with result_lock:
            latest_result = result


# ==========================================
# THREADS
# ==========================================

threading.Thread(
    target=camera_thread,
    daemon=True
).start()

threading.Thread(
    target=tracking_thread,
    daemon=True
).start()


# ==========================================
# RESTRICTED ZONE
# ==========================================

zone = RestrictedZone(
    200,  # x1
    100,  # y1
    500,  # x2
    400   # y2
)


print("=" * 60)
print("IBVAP - VIRTUAL FENCE TEST")
print("=" * 60)
print("🔴 Red rectangle = Restricted Zone")
print("Walk inside the red rectangle")
print("Press Q to exit")
print("=" * 60)


# ==========================================
# DISPLAY
# ==========================================

while running:

    with frame_lock:

        if latest_frame is None:
            continue

        frame = latest_frame.copy()

    with result_lock:
        result = latest_result

    # Draw detections
    if result is not None:

        frame = result.plot()

        if result.boxes is not None:

            for box in result.boxes:

                if box.id is None:
                    continue

                track_id = int(box.id[0])

                class_id = int(box.cls[0])

                class_name = result.names[class_id]

                # Only person for now
                if class_name != "person":
                    continue

                bbox = list(
                    map(
                        int,
                        box.xyxy[0]
                    )
                )

                # Check restricted zone
                inside = zone.is_inside(bbox)

                x1, y1, x2, y2 = bbox

                bottom_x = int((x1 + x2) / 2)
                bottom_y = int(y2)

                print(
                    f"ID={track_id} | "
                    f"Bottom=({bottom_x},{bottom_y}) | "
                    f"Inside Zone={inside}"
                )

                if inside:

                    print(
                        f"🚨 INTRUSION DETECTED | "
                        f"Person ID: {track_id}"
                    )

                    cv2.putText(
                        frame,
                        f"INTRUSION! ID {track_id}",
                        (x1, max(y1 - 10, 30)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 0, 255),
                        2
                    )

                    x1, y1, x2, y2 = bbox

                    cv2.putText(
                        frame,
                        f"INTRUSION! ID {track_id}",
                        (x1, max(y1 - 10, 30)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 0, 255),
                        2
                    )

    # Draw zone
    frame = zone.draw(frame)

    cv2.imshow(
        "IBVAP - Virtual Fence",
        frame
    )

    if cv2.waitKey(1) & 0xFF == ord("q"):

        running = False
        break


cv2.destroyAllWindows()

print("Virtual fence test finished.")