import cv2
import numpy as np

print("OpenCV version:", cv2.__version__)
print("OpenCV location:", cv2.__file__)

img = np.zeros((500, 800, 3), dtype=np.uint8)

cv2.imshow("OpenCV GUI Test", img)

print("✅ GUI window opened")
print("Press Q to close")

while True:
    key = cv2.waitKey(1) & 0xFF

    if key == ord("q"):
        break

cv2.destroyAllWindows()