import cv2
import time
import threading
import traceback
from datetime import datetime

from ultralytics import YOLO

from ai.border import BorderDetector
from ai.zone import RestrictedZone
from ai.loitering import LoiteringDetector
from ai.behavior import BehaviorAnalyzer
from ai.threat_engine import ThreatEngine
from ai.incident import IncidentManager
from ai.anpr_pipeline import ANPRPipeline
from ai.anpr_worker import ANPRWorker
from ai.night_movement import NightMovementDetector


# ============================================================
# CAMERA STREAM
# ============================================================

class CameraStream:

    def __init__(self, url):

        self.url = url

        self.cap = None
        self.running = False
        self.thread = None

        self.lock = threading.Lock()
        self.latest_frame = None
        self.last_frame_time = 0.0

        # Prevent race condition
        self.initialized = threading.Event()

    # --------------------------------------------------------
    # CLOSE CAPTURE
    # --------------------------------------------------------

    def _close_capture(self):

        if self.cap is not None:

            try:
                self.cap.release()
            except Exception:
                pass

        self.cap = None

    # --------------------------------------------------------
    # CONNECT CAPTURE
    # --------------------------------------------------------

    def _connect(self):

        self._close_capture()

        print("📡 Opening camera stream...")
        print("URL:", self.url)

        self.cap = cv2.VideoCapture(
            self.url,
            cv2.CAP_FFMPEG
        )

        try:
            self.cap.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )
        except Exception:
            pass

        if not self.cap.isOpened():
            print("❌ VideoCapture could not open")
            self.initialized.set()
            return False

        print("✅ VideoCapture opened successfully")
        self.initialized.set()
        return True

    # --------------------------------------------------------
    # START CAMERA
    # --------------------------------------------------------

    def start(self):

        if self.running:
            return True

        self.running = True
        self.initialized.clear()

        self.thread = threading.Thread(
            target=self._update,
            daemon=True
        )

        self.thread.start()

        # Wait for VideoCapture initialization
        self.initialized.wait(timeout=8)

        if self.cap is None:
            print("❌ Camera capture: None")
            return False

        if not self.cap.isOpened():
            print("❌ Camera failed to open")
            return False

        print("✅ Camera stream started")

        return True

    # --------------------------------------------------------
    # CAMERA THREAD
    # --------------------------------------------------------

    def _update(self):

        try:

            if not self._connect():
                return

            while self.running:

                if self.cap is None or not self.cap.isOpened():
                    if not self._connect():
                        time.sleep(0.5)
                        continue

                ret, frame = self.cap.read()

                if not ret or frame is None:
                    print("⚠️ Camera frame read failed, reconnecting...")
                    self._close_capture()
                    time.sleep(0.5)
                    continue

                self.last_frame_time = time.monotonic()

                with self.lock:
                    self.latest_frame = frame

                time.sleep(0.01)

        except Exception as e:

            print("❌ Camera stream error:", e)

            traceback.print_exc()

            self.initialized.set()

        finally:

            self._close_capture()
            print("📴 Camera stream stopped")

    # --------------------------------------------------------
    # READ LATEST FRAME
    # --------------------------------------------------------

    def read(self):

        with self.lock:

            if self.latest_frame is None:
                return None

            if time.monotonic() - self.last_frame_time > 3.0:
                return None

            return self.latest_frame.copy()

    # --------------------------------------------------------
    # STOP CAMERA
    # --------------------------------------------------------

    def stop(self):

        self.running = False

        if self.thread is not None:

            self.thread.join(timeout=2)

        self.thread = None

        self._close_capture()

        with self.lock:

            self.latest_frame = None
            self.last_frame_time = 0.0

# ============================================================
# CAMERA STREAM
# ============================================================

# class CameraStream:
#     """
#     Threaded RTSP camera.
#     Always keeps only the latest frame to reduce RTSP delay.
#     """

#     def __init__(self, url):
#         self.url = url
#         self.cap = None

#         self.frame = None
#         self.running = False

#         self.lock = threading.Lock()
#         self.thread = None

#     def start(self):
#         print("Opening camera...")

#         self.cap = cv2.VideoCapture(
#             self.url,
#             cv2.CAP_FFMPEG
#         )

#         self.cap.set(
#             cv2.CAP_PROP_BUFFERSIZE,
#             1
#         )

#         if not self.cap.isOpened():
#             print("ERROR: Camera could not be opened")
#             return False

#         print("Camera opened successfully")

#         self.running = True

#         self.thread = threading.Thread(
#             target=self._update,
#             daemon=True
#         )

#         self.thread.start()

#         return True

#     def _update(self):
#         while self.running:
#             try:
#                 ret, frame = self.cap.read()

#                 if not ret:
#                     time.sleep(0.01)
#                     continue

#                 with self.lock:
#                     self.frame = frame

#             except Exception as e:
#                 print("Camera error:", e)
#                 time.sleep(0.1)

#     def read(self):
#         with self.lock:
#             if self.frame is None:
#                 return None

#             return self.frame.copy()

#     def stop(self):
#         self.running = False

#         if self.thread is not None:
#             self.thread.join(timeout=2)

#         if self.cap is not None:
#             self.cap.release()

#         self.cap = None

# ============================================================
# AI PIPELINE
# ============================================================

class AIPipeline:

    def __init__(
        self,
        model_path="yolo11n.pt",
        camera_url="rtsp://192.168.1.8:554/live/ch00_1"
    ):

        print("=" * 60)
        print("INITIALIZING AI PIPELINE")
        print("=" * 60)

        # ----------------------------------------------------
        # CONFIG
        # ----------------------------------------------------

        self.camera_url = camera_url

        self.running = False
        self.thread = None

        # ----------------------------------------------------
        # MAIN DATA LOCK
        # ----------------------------------------------------

        self.data_lock = threading.Lock()

        # Latest processed AI frame
        self.latest_frame = None

        # Latest YOLO / AI detections
        self.latest_detections = []

        # Latest ANPR results
        self.latest_anpr_results = []

        # Frame counter
        self.frame_count = 0

        # ----------------------------------------------------
        # PROCESS EVERY NTH FRAME
        # ----------------------------------------------------

        self.process_every_n_frames = 2

        # ----------------------------------------------------
        # INCIDENT COOLDOWN
        # ----------------------------------------------------

        self.incident_cooldown = 2.0

        self.last_incident_time = {}

        # ----------------------------------------------------
        # ANPR SUBMISSION CONTROL
        # ----------------------------------------------------

        self.last_anpr_submit = 0.0

        self.anpr_submit_interval = 1.5

        # ----------------------------------------------------
        # YOLO
        # ----------------------------------------------------

        print("Loading YOLO model...")

        self.model = YOLO(model_path)

        print("✅ YOLO model loaded")

        # ----------------------------------------------------
        # CAMERA
        # ----------------------------------------------------

        self.camera = CameraStream(
            self.camera_url
        )

        # ----------------------------------------------------
        # BORDER
        # ----------------------------------------------------

        self.border = BorderDetector()

        # ----------------------------------------------------
        # RESTRICTED ZONE
        # ----------------------------------------------------

        self.zone = RestrictedZone()

        # ----------------------------------------------------
        # LOITERING
        # ----------------------------------------------------

        self.loitering = LoiteringDetector(
            loitering_time=10.0,
            movement_threshold=80.0,
            history_size=30
        )

        # ----------------------------------------------------
        # BEHAVIOR
        # ----------------------------------------------------

        self.behavior = BehaviorAnalyzer()

        # ----------------------------------------------------
        # THREAT ENGINE
        # ----------------------------------------------------

        self.threat = ThreatEngine()

        # ----------------------------------------------------
        # INCIDENT MANAGER
        # ----------------------------------------------------

        self.incident = IncidentManager()

        # ----------------------------------------------------
        # NIGHT MOVEMENT
        # ----------------------------------------------------

        self.night_movement = NightMovementDetector(
            brightness_threshold=110.0,
            saturation_threshold=18.0,
            min_movement=12.0,
            history_size=8,
            cooldown=5.0
        )

        # ----------------------------------------------------
        # ANPR
        # ----------------------------------------------------

        print("Initializing ANPR...")

        self.anpr = ANPRPipeline(
            plate_model="models/license-plate-finetune-v1n.pt",
            confidence=0.35,
            image_size=640,
            ocr_cooldown=3.0
        )

        self.anpr_worker = ANPRWorker(
            self.anpr,
            interval=1.5
        )

        print("✅ ANPR initialized")

        print("=" * 60)
        print("AI PIPELINE READY")
        print("=" * 60)

    # ========================================================
    # START
    # ========================================================

    def start(self):

        if self.running:

            print("⚠️ AI Pipeline already running")

            return True

        print()
        print("=" * 60)
        print("STARTING AI PIPELINE")
        print("=" * 60)

        # ----------------------------------------------------
        # CAMERA
        # ----------------------------------------------------

        camera_started = self.camera.start()

        if not camera_started:

            print("❌ PIPELINE COULD NOT START")
            print("Camera object:", self.camera)
            print("Camera capture:", self.camera.cap)

            return False

        # ----------------------------------------------------
        # ANPR WORKER
        # ----------------------------------------------------

        self.anpr_worker.start()

        # ----------------------------------------------------
        # AI THREAD
        # ----------------------------------------------------

        self.running = True

        self.thread = threading.Thread(
            target=self._ai_loop,
            daemon=True
        )

        self.thread.start()

        print("✅ AI pipeline started")

        return True

    # ========================================================
    # AI LOOP
    # ========================================================

    def _ai_loop(self):

        print("🧠 AI processing thread started")

        while self.running:

            try:

                frame = self.camera.read()

                if frame is None:

                    time.sleep(0.01)

                    continue

                self.frame_count += 1

                # --------------------------------------------
                # FRAME SKIP
                # --------------------------------------------

                if (
                    self.frame_count %
                    self.process_every_n_frames != 0
                ):

                    continue

                # --------------------------------------------
                # PROCESS FRAME
                # --------------------------------------------

                processed_frame, detections = \
                    self.process_frame(frame)

                # --------------------------------------------
                # SAVE LATEST AI RESULT
                # --------------------------------------------

                with self.data_lock:

                    if processed_frame is not None:

                        self.latest_frame = \
                            processed_frame.copy()

                    self.latest_detections = \
                        list(detections)

                    # Get ANPR result at same time
                    try:

                        self.latest_anpr_results = \
                            list(
                                self.anpr_worker.get_results()
                            )

                    except Exception:

                        self.latest_anpr_results = []

            except Exception as e:

                print()
                print("❌ AI LOOP ERROR")
                print(e)

                traceback.print_exc()

                time.sleep(0.1)

        print("🧠 AI processing thread stopped")

    # ========================================================
    # PROCESS FRAME
    # ========================================================

    def process_frame(self, frame):

        if frame is None:

            return None, []

        detections = []

        # ----------------------------------------------------
        # NIGHT STATUS
        # ----------------------------------------------------

        night_status = \
            self.night_movement.analyze_frame(frame)

        is_night = night_status["is_night"]

        # ----------------------------------------------------
        # YOLO TRACKING
        # ----------------------------------------------------

        results = self.model.track(
            frame,
            persist=True,
            tracker="bytetrack.yaml",
            conf=0.35,
            imgsz=640,
            verbose=False
        )

        # Vehicle list for ANPR
        vehicles_for_anpr = []

        # ----------------------------------------------------
        # PROCESS YOLO RESULTS
        # ----------------------------------------------------

        if results:

            result = results[0]

            boxes = result.boxes

            if boxes is not None:

                for i in range(len(boxes)):

                    try:

                        # ------------------------------------
                        # CLASS
                        # ------------------------------------

                        cls_id = int(
                            boxes.cls[i].item()
                        )

                        # ------------------------------------
                        # CONFIDENCE
                        # ------------------------------------

                        confidence = float(
                            boxes.conf[i].item()
                        )

                        # ------------------------------------
                        # BBOX
                        # ------------------------------------

                        x1, y1, x2, y2 = map(
                            int,
                            boxes.xyxy[i].tolist()
                        )

                        # ------------------------------------
                        # TRACK ID
                        # ------------------------------------

                        track_id = None

                        if boxes.id is not None:

                            track_id = int(
                                boxes.id[i].item()
                            )

                        else:

                            track_id = i

                        # ------------------------------------
                        # CLASS NAME
                        # ------------------------------------

                        try:

                            object_type = \
                                self.model.names[cls_id]

                        except Exception:

                            object_type = str(cls_id)

                        # ------------------------------------
                        # CENTER
                        # ------------------------------------

                        center_x = int(
                            (x1 + x2) / 2
                        )

                        center_y = int(
                            (y1 + y2) / 2
                        )

                        center = (
                            center_x,
                            center_y
                        )

                        # ------------------------------------
                        # DETECTION DICTIONARY
                        # ------------------------------------

                        detection = {

                            "track_id": track_id,

                            "class_id": cls_id,

                            "object_type": object_type,

                            "confidence": confidence,

                            "bbox": [
                                x1,
                                y1,
                                x2,
                                y2
                            ],

                            "center": center,

                            "border_crossed": False,

                            "zone_intrusion": False,

                            "loitering": False,

                            "loitering_duration": 0.0,

                            "movement": 0.0,

                            "behavior": "NORMAL",

                            "threat_score": 0,

                            "threat_level": "LOW",

                            "direction": None,

                            "night_movement": False
                        }

                        # ====================================
                        # PERSON
                        # ====================================

                        if cls_id == 0:

                            # --------------------------------
                            # BORDER
                            # --------------------------------

                            border_result = \
                                self.border.check_crossing(
                                    track_id,
                                    center
                                )

                            border_crossed = bool(
                                border_result["crossed"]
                            )

                            direction = \
                                border_result["direction"]

                            detection[
                                "border_crossed"
                            ] = border_crossed

                            detection[
                                "direction"
                            ] = direction

                            # --------------------------------
                            # RESTRICTED ZONE
                            # --------------------------------

                            zone_result = \
                                self.zone.check_intrusion(
                                    track_id,
                                    center
                                )

                            zone_entered = bool(
                                zone_result["intrusion"]
                            )

                            zone_inside = bool(
                                zone_result["inside"]
                            )

                            detection[
                                "zone_intrusion"
                            ] = zone_inside

                            detection[
                                "zone_entry"
                            ] = zone_entered

                            # --------------------------------
                            # LOITERING
                            # --------------------------------

                            loiter_result = \
                                self.loitering.update(
                                    track_id,
                                    center
                                )

                            loitering = bool(
                                loiter_result["loitering"]
                            )

                            loitering_started = bool(
                                loiter_result.get(
                                    "loitering_started",
                                    False
                                )
                            )

                            loitering_duration = float(
                                loiter_result["duration"]
                            )

                            movement = float(
                                loiter_result["movement"]
                            )

                            detection[
                                "loitering"
                            ] = loitering

                            detection[
                                "loitering_duration"
                            ] = loitering_duration

                            detection[
                                "movement"
                            ] = movement

                            # --------------------------------
                            # BEHAVIOR
                            # --------------------------------

                            behavior_result = \
                                self.behavior.analyze(
                                    track_id=track_id,
                                    object_type="person",
                                    loitering=loitering,
                                    loitering_duration=
                                        loitering_duration,
                                    movement=movement,
                                    border_crossed=
                                        border_crossed,
                                    zone_intrusion=
                                        zone_inside,
                                    direction=direction
                                )

                            behavior = \
                                behavior_result[
                                    "behavior"
                                ]

                            detection[
                                "behavior"
                            ] = behavior

                            detection[
                                "behavior_severity"
                            ] = behavior_result[
                                "severity"
                            ]

                            detection[
                                "reasons"
                            ] = behavior_result[
                                "reasons"
                            ]

                            # --------------------------------
                            # THREAT
                            # --------------------------------

                            threat_result = \
                                self.threat.calculate(
                                    object_type="person",
                                    border_crossed=
                                        border_crossed,
                                    zone_intrusion=
                                        zone_inside,
                                    loitering=
                                        loitering,
                                    loitering_duration=
                                        loitering_duration,
                                    behavior=behavior,
                                    movement=movement
                                )

                            detection[
                                "threat_score"
                            ] = threat_result[
                                "threat_score"
                            ]

                            detection[
                                "threat_level"
                            ] = threat_result[
                                "threat_level"
                            ]

                            detection[
                                "threat_reasons"
                            ] = threat_result[
                                "reasons"
                            ]

                            # --------------------------------
                            # NIGHT MOVEMENT
                            # --------------------------------

                            night_result = \
                                self.night_movement.update_track(
                                    track_id,
                                    center,
                                    is_night
                                )

                            night_movement = bool(
                                night_result[
                                    "night_movement"
                                ]
                            )

                            detection[
                                "night_movement"
                            ] = night_movement

                            detection[
                                "night_movement_distance"
                            ] = night_result[
                                "movement"
                            ]

                            # --------------------------------
                            # INCIDENTS
                            # --------------------------------

                            if border_crossed:

                                self._create_incident(
                                    event_type=
                                        "BORDER_CROSSING",
                                    track_id=track_id,
                                    object_type="person",
                                    confidence=confidence,
                                    direction=direction,
                                    frame=frame,
                                    detection=detection,
                                    night_status=night_status
                                )

                            if zone_entered:

                                self._create_incident(
                                    event_type=
                                        "ZONE_INTRUSION",
                                    track_id=track_id,
                                    object_type="person",
                                    confidence=confidence,
                                    direction=direction,
                                    frame=frame,
                                    detection=detection,
                                    night_status=night_status
                                )

                            if loitering_started:

                                self._create_incident(
                                    event_type="LOITERING",
                                    track_id=track_id,
                                    object_type="person",
                                    confidence=confidence,
                                    direction=direction,
                                    frame=frame,
                                    detection=detection,
                                    night_status=night_status
                                )

                            if night_movement:

                                self._create_incident(
                                    event_type=
                                        "NIGHT_TIME_MOVEMENT",
                                    track_id=track_id,
                                    object_type="person",
                                    confidence=confidence,
                                    direction=None,
                                    frame=frame,
                                    detection=detection,
                                    night_status=night_status
                                )

                        # ====================================
                        # VEHICLES
                        # ====================================

                        elif cls_id in [2, 3, 5, 7]:

                            vehicles_for_anpr.append({

                                "track_id": track_id,

                                "vehicle_type":
                                    object_type,

                                "bbox": [
                                    x1,
                                    y1,
                                    x2,
                                    y2
                                ],

                                "confidence":
                                    confidence
                            })

                        # ------------------------------------
                        # ADD DETECTION
                        # ------------------------------------

                        detections.append(
                            detection
                        )

                        # ------------------------------------
                        # DRAW BOUNDING BOX
                        # ------------------------------------

                        self._draw_detection(
                            frame,
                            detection
                        )

                    except Exception as e:

                        print(
                            "⚠️ Detection processing error:",
                            e
                        )

                        traceback.print_exc()

        # ====================================================
        # DRAW BORDER
        # ====================================================

        frame = self.border.draw(frame)

        # ====================================================
        # DRAW RESTRICTED ZONE
        # ====================================================

        frame = self.zone.draw(frame)

        # ====================================================
        # ANPR
        # ====================================================

        self._process_anpr(
            frame,
            vehicles_for_anpr
        )

        # Get latest ANPR results
        anpr_results = \
            self.anpr_worker.get_results()

        # Draw ANPR
        if anpr_results:

            try:

                frame = self.anpr.draw(
                    frame,
                    anpr_results
                )

            except Exception as e:

                print(
                    "⚠️ ANPR drawing error:",
                    e
                )

        # ====================================================
        # NIGHT STATUS DISPLAY
        # ====================================================

        self._draw_night_status(
            frame,
            night_status
        )

        # ====================================================
        # RETURN
        # ====================================================

        return frame, detections

    # ========================================================
    # ANPR PROCESSING
    # ========================================================

    def _process_anpr(
        self,
        frame,
        vehicles
    ):

        if frame is None:
            return

        if not vehicles:
            return

        now = time.time()

        if (
            now - self.last_anpr_submit
            < self.anpr_submit_interval
        ):

            return

        try:

            self.anpr_worker.submit(
                frame,
                vehicles
            )

            self.last_anpr_submit = now

        except Exception as e:

            print(
                "⚠️ ANPR submit error:",
                e
            )

    # ========================================================
    # CREATE INCIDENT
    # ========================================================

    def _create_incident(
        self,
        event_type,
        track_id,
        object_type,
        confidence,
        direction=None,
        frame=None,
        detection=None,
        night_status=None
    ):

        key = (
            event_type,
            int(track_id)
        )

        now = time.time()

        last_time = \
            self.last_incident_time.get(
                key,
                0.0
            )

        # --------------------------------------------
        # COOLDOWN
        # --------------------------------------------

        if (
            now - last_time
            < self.incident_cooldown
        ):

            return None

        self.last_incident_time[key] = now

        try:

            evidence_frame = frame

            if frame is not None and detection is not None:

                evidence_frame = frame.copy()

                self._draw_detection(
                    evidence_frame,
                    detection
                )

                self._draw_incident_summary(
                    evidence_frame,
                    event_type,
                    track_id,
                    detection
                )

                if night_status is not None:

                    self._draw_night_status(
                        evidence_frame,
                        night_status
                    )

            event = \
                self.incident.create_event(
                    event_type=event_type,
                    track_id=track_id,
                    object_type=object_type,
                    confidence=confidence,
                    direction=direction,
                    frame=evidence_frame
                )

            return event

        except Exception as e:

            print(
                "❌ Incident creation error:",
                e
            )

            traceback.print_exc()

            return None

    def _draw_incident_summary(
        self,
        frame,
        event_type,
        track_id,
        detection
    ):

        threat_score = int(
            detection.get("threat_score", 0)
        )

        threat_level = detection.get(
            "threat_level",
            "LOW"
        )

        timestamp = datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )

        lines = [
            f"EVENT: {event_type}",
            f"TRACK ID: {track_id}",
            f"THREAT: {threat_score} ({threat_level})",
            f"TIME: {timestamp}",
            "RESTRICTED ZONE INTRUSION!"
            if event_type == "ZONE_INTRUSION"
            else event_type.replace("_", " "),
            "STATUS: MONITOR"
        ]

        for index, line in enumerate(lines):

            color = (
                (0, 0, 255)
                if index in (0, 2, 4)
                else (255, 255, 255)
            )

            cv2.putText(
                frame,
                line,
                (14, 25 + index * 22),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.58,
                color,
                2
            )

    # ========================================================
    # DRAW DETECTION
    # ========================================================

    def _draw_detection(
        self,
        frame,
        detection
    ):

        x1, y1, x2, y2 = \
            detection["bbox"]

        object_type = \
            detection["object_type"]

        confidence = \
            detection["confidence"]

        track_id = \
            detection["track_id"]

        # --------------------------------------------
        # NORMAL BOX
        # --------------------------------------------

        cv2.rectangle(
            frame,
            (x1, y1),
            (x2, y2),
            (0, 255, 0),
            2
        )

        # --------------------------------------------
        # LABEL
        # --------------------------------------------

        label = (
            f"{object_type} "
            f"ID:{track_id} "
            f"{confidence:.2f}"
        )

        cv2.putText(
            frame,
            label,
            (x1, max(y1 - 8, 20)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 255, 0),
            2
        )

        # --------------------------------------------
        # PERSON INFORMATION
        # --------------------------------------------

        if object_type == "person":

            y = y2 + 20

            # Behavior
            behavior = \
                detection.get(
                    "behavior",
                    "NORMAL"
                )

            cv2.putText(
                frame,
                f"Behavior: {behavior}",
                (x1, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                (255, 255, 255),
                1
            )

            y += 18

            # Threat
            threat_level = \
                detection.get(
                    "threat_level",
                    "LOW"
                )

            threat_score = \
                detection.get(
                    "threat_score",
                    0
                )

            cv2.putText(
                frame,
                f"Threat: {threat_level} "
                f"({threat_score})",
                (x1, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                (255, 255, 255),
                1
            )

            y += 18

            # Border
            if detection.get(
                "border_crossed",
                False
            ):

                cv2.putText(
                    frame,
                    "BORDER CROSSING",
                    (x1, y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 0, 255),
                    2
                )

                y += 18

            # Zone
            if detection.get(
                "zone_intrusion",
                False
            ):

                cv2.putText(
                    frame,
                    "ZONE INTRUSION",
                    (x1, y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 0, 255),
                    2
                )

                y += 18

            # Loitering
            if detection.get(
                "loitering",
                False
            ):

                duration = \
                    detection.get(
                        "loitering_duration",
                        0
                    )

                cv2.putText(
                    frame,
                    f"LOITERING {duration:.1f}s",
                    (x1, y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 165, 255),
                    2
                )

                y += 18

            # Night movement
            if detection.get(
                "night_movement",
                False
            ):

                cv2.putText(
                    frame,
                    "NIGHT MOVEMENT",
                    (x1, y),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (255, 0, 255),
                    2
                )

    # ========================================================
    # DRAW NIGHT STATUS
    # ========================================================

    def _draw_night_status(
        self,
        frame,
        night_status
    ):

        if frame is None:
            return

        is_night = \
            night_status.get(
                "is_night",
                False
            )

        brightness = \
            night_status.get(
                "brightness",
                0.0
            )

        saturation = \
            night_status.get(
                "saturation",
                0.0
            )

        if is_night:

            text = (
                f"NIGHT / IR MODE | "
                f"B:{brightness:.1f} "
                f"S:{saturation:.1f}"
            )

            cv2.putText(
                frame,
                text,
                (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )

        else:

            text = (
                f"DAY MODE | "
                f"B:{brightness:.1f} "
                f"S:{saturation:.1f}"
            )

            cv2.putText(
                frame,
                text,
                (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )

    # ========================================================
    # READ PROCESSED FRAME + DETECTIONS
    # ========================================================

    def read(self):

        with self.data_lock:

            if self.latest_frame is None:

                # AI has not processed anything yet
                raw_frame = self.camera.read()

                return (
                    raw_frame,
                    []
                )

            return (
                self.latest_frame.copy(),
                list(self.latest_detections)
            )

    # ========================================================
    # SET VIRTUAL BORDER
    # ========================================================

    def set_border(
        self,
        start_point,
        end_point=None
    ):

        # Backward compatibility:
        #
        # set_border([(x1,y1),(x2,y2)])
        #
        # OR
        #
        # set_border((x1,y1),(x2,y2))

        if end_point is None:

            if (
                isinstance(start_point, (list, tuple))
                and len(start_point) == 2
            ):

                end_point = start_point[1]
                start_point = start_point[0]

            else:

                raise ValueError(
                    "Border requires two points"
                )

        self.border.set_border(
            start_point,
            end_point
        )

        print(
            "✅ Virtual border set:",
            start_point,
            "->",
            end_point
        )

    # ========================================================
    # CLEAR BORDER
    # ========================================================

    def clear_border(self):

        self.border.clear()

        print(
            "🗑️ Virtual border cleared"
        )

    # ========================================================
    # SET RESTRICTED ZONE
    # ========================================================

    def set_zone(self, points):

        if not points or len(points) < 3:

            raise ValueError(
                "Restricted zone requires at least 3 points"
            )

        self.zone.set_polygon(
            points
        )

        print(
            "✅ Restricted zone set:",
            points
        )

    # ========================================================
    # CLEAR ZONE
    # ========================================================

    def clear_zone(self):

        self.zone.clear()

        print(
            "🗑️ Restricted zone cleared"
        )

    # ========================================================
    # GET LATEST DETECTIONS
    # ========================================================

    def get_detections(self):

        with self.data_lock:

            return list(
                self.latest_detections
            )

    # ========================================================
    # GET ANPR RESULTS
    # ========================================================

    def get_anpr_results(self):

        with self.data_lock:

            return list(
                self.latest_anpr_results
            )

    # ========================================================
    # STOP PIPELINE
    # ========================================================

    def stop(self):

        print()
        print("=" * 60)
        print("STOPPING AI PIPELINE")
        print("=" * 60)

        self.running = False

        # --------------------------------------------
        # AI THREAD
        # --------------------------------------------

        if self.thread is not None:

            self.thread.join(timeout=2)

        self.thread = None

        # --------------------------------------------
        # ANPR
        # --------------------------------------------

        try:

            self.anpr_worker.stop()

        except Exception as e:

            print(
                "⚠️ ANPR stop error:",
                e
            )

        # --------------------------------------------
        # CAMERA
        # --------------------------------------------

        try:

            self.camera.stop()

        except Exception as e:

            print(
                "⚠️ Camera stop error:",
                e
            )

        # --------------------------------------------
        # NIGHT TRACKING
        # --------------------------------------------

        try:

            self.night_movement.clear()

        except Exception:

            pass

        # --------------------------------------------
        # LOITERING
        # --------------------------------------------

        try:

            self.loitering.reset_all()

        except Exception:

            pass

        # --------------------------------------------
        # CLEAR DATA
        # --------------------------------------------

        with self.data_lock:

            self.latest_frame = None

            self.latest_detections = []

            self.latest_anpr_results = []

        print("✅ AI pipeline stopped")

    # ========================================================
    # RESET TRACK
    # ========================================================

    def reset_track(self, track_id):

        try:

            self.loitering.reset_track(
                track_id
            )

        except Exception:

            pass

        try:

            self.night_movement.reset_track(
                track_id
            )

        except Exception:

            pass

        try:

            self.anpr.reset_track(
                track_id
            )

        except Exception:

            pass

    # ========================================================
    # STATUS
    # ========================================================

    def is_running(self):

        return self.running