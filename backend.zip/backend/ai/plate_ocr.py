import cv2
import easyocr
import re


class PlateOCR:

    def __init__(self):

        print("Loading OCR engine...")

        self.reader = easyocr.Reader(
            ["en"],
            gpu=False
        )

        print("✅ OCR engine loaded")

    # ========================================================
    # CLEAN TEXT
    # ========================================================

    def clean_text(self, text):

        if text is None:

            return ""

        text = text.upper()

        text = text.replace(
            " ",
            ""
        )

        text = re.sub(
            r"[^A-Z0-9]",
            "",
            text
        )

        return text

    # ========================================================
    # VALIDATE PLATE
    # ========================================================

    def is_valid_plate(self, text):

        if not text:

            return False

        if len(text) < 3:

            return False

        if len(text) > 15:

            return False

        # At least one number
        if not any(
            char.isdigit()
            for char in text
        ):

            return False

        return True

    # ========================================================
    # PREPROCESSING
    # ========================================================

    def preprocess_variants(
        self,
        plate_crop
    ):

        if plate_crop is None:

            return []

        if plate_crop.size == 0:

            return []

        variants = []

        # ----------------------------------------------------
        # Original
        # ----------------------------------------------------

        original = plate_crop.copy()

        variants.append(
            (
                "original",
                original
            )
        )

        # ----------------------------------------------------
        # Resize
        # ----------------------------------------------------

        gray = cv2.cvtColor(
            plate_crop,
            cv2.COLOR_BGR2GRAY
        )

        gray = cv2.resize(
            gray,
            None,
            fx=6,
            fy=6,
            interpolation=cv2.INTER_CUBIC
        )

        variants.append(
            (
                "gray",
                gray
            )
        )

        # ----------------------------------------------------
        # Gaussian blur
        # ----------------------------------------------------

        blur = cv2.GaussianBlur(
            gray,
            (3, 3),
            0
        )

        variants.append(
            (
                "blur",
                blur
            )
        )

        # ----------------------------------------------------
        # CLAHE
        # ----------------------------------------------------

        clahe = cv2.createCLAHE(
            clipLimit=2.0,
            tileGridSize=(8, 8)
        )

        enhanced = clahe.apply(
            gray
        )

        variants.append(
            (
                "clahe",
                enhanced
            )
        )

        # ----------------------------------------------------
        # OTSU
        # ----------------------------------------------------

        _, otsu = cv2.threshold(
            enhanced,
            0,
            255,
            cv2.THRESH_BINARY +
            cv2.THRESH_OTSU
        )

        variants.append(
            (
                "otsu",
                otsu
            )
        )

        # ----------------------------------------------------
        # Adaptive threshold
        # ----------------------------------------------------

        adaptive = cv2.adaptiveThreshold(
            enhanced,
            255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            21,
            5
        )

        variants.append(
            (
                "adaptive",
                adaptive
            )
        )

        # ----------------------------------------------------
        # Inverted
        # ----------------------------------------------------

        inverted = cv2.bitwise_not(
            otsu
        )

        variants.append(
            (
                "inverted",
                inverted
            )
        )

        return variants

    # ========================================================
    # OCR
    # ========================================================

    def read(
        self,
        plate_crop
    ):

        if plate_crop is None:

            return None, 0.0

        if plate_crop.size == 0:

            return None, 0.0

        variants = (
            self.preprocess_variants(
                plate_crop
            )
        )

        all_results = []

        # ====================================================
        # Run EasyOCR on all variants
        # ====================================================

        for variant_name, image in variants:

            try:

                results = self.reader.readtext(
                    image,
                    detail=1,
                    paragraph=False,
                    allowlist=(
                        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                        "0123456789"
                    ),
                    text_threshold=0.25,
                    low_text=0.15,
                    link_threshold=0.15,
                    mag_ratio=1.5
                )

                for result in results:

                    if len(result) < 3:

                        continue

                    text = result[1]

                    confidence = float(
                        result[2]
                    )

                    text = self.clean_text(
                        text
                    )

                    if not text:

                        continue

                    all_results.append({

                        "text": text,

                        "confidence": confidence,

                        "variant": variant_name

                    })

            except Exception as e:

                print(
                    f"⚠️ OCR variant "
                    f"{variant_name} failed:",
                    e
                )

        # ====================================================
        # No result
        # ====================================================

        if not all_results:

            return None, 0.0

        # ====================================================
        # Filter valid results
        # ====================================================

        valid_results = [
            result
            for result in all_results
            if self.is_valid_plate(
                result["text"]
            )
        ]

        if valid_results:

            all_results = valid_results

        # ====================================================
        # Sort by confidence
        # ====================================================

        all_results.sort(
            key=lambda x: x["confidence"],
            reverse=True
        )

        # ====================================================
        # BEST RESULT
        # ====================================================

        best = all_results[0]

        print(
            f"🔤 OCR candidate: "
            f"{best['text']} "
            f"| confidence="
            f"{best['confidence']:.2f} "
            f"| variant="
            f"{best['variant']}"
        )

        return (
            best["text"],
            best["confidence"]
        )