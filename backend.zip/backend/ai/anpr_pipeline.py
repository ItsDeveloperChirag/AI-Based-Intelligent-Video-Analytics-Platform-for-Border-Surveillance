import cv2
import time

from ai.license_plate_detector import LicensePlateDetector
from ai.plate_tracker import PlateTracker
from ai.plate_ocr import PlateOCR


class ANPRPipeline:
    """
    Automatic Number Plate Recognition Pipeline

    Flow:

    Camera Frame
         ↓
    License Plate Detection
         ↓
    Vehicle Association
         ↓
    OCR
         ↓
    Plate Number
    """

    def __init__(
        self,
        plate_model="models/license-plate-finetune-v1n.pt",
        confidence=0.35,
        image_size=640,
        ocr_cooldown=2.0
    ):

        print("\nLoading ANPR modules...")

        # ======================================================
        # PLATE DETECTOR
        # ======================================================

        self.plate_detector = LicensePlateDetector(

            model_path=plate_model,

            confidence=confidence,

            image_size=image_size
        )

        print("Plate detector loaded")

        # ======================================================
        # PLATE TRACKER
        # ======================================================

        self.plate_tracker = PlateTracker()

        print("Plate tracker loaded")

        # ======================================================
        # OCR
        # ======================================================

        self.ocr = PlateOCR()

        print("OCR loaded")

        # ======================================================
        # OCR CACHE
        # ======================================================

        self.plate_results = {}

        # Last OCR time for a vehicle
        self.last_ocr_time = {}

        self.ocr_cooldown = ocr_cooldown

        print("ANPR initialized successfully")

    # ==========================================================
    # OCR COOLDOWN
    # ==========================================================

    def can_run_ocr(self, track_id):

        now = time.time()

        last_time = self.last_ocr_time.get(
            track_id
        )

        if last_time is None:

            return True

        return (
            now - last_time
            >= self.ocr_cooldown
        )

    # ==========================================================
    # PROCESS FRAME
    # ==========================================================

    def process(
        self,
        frame,
        vehicles
    ):

        results = []

        if frame is None:

            return results

        # ======================================================
        # PLATE DETECTION
        # ======================================================

        plates = self.plate_detector.detect(
            frame
        )

        if not plates:

            return results

        # ======================================================
        # PLATE → VEHICLE ASSOCIATION
        # ======================================================

        associations = self.plate_tracker.associate(

            vehicles,

            plates
        )

        # ======================================================
        # PROCESS ASSOCIATED PLATES
        # ======================================================

        for association in associations:

            track_id = association[
                "track_id"
            ]

            vehicle_type = association[
                "vehicle_type"
            ]

            plate_bbox = association[
                "plate_bbox"
            ]

            plate_confidence = association[
                "plate_confidence"
            ]

            x1, y1, x2, y2 = plate_bbox

            # --------------------------------------------------
            # CROP PLATE
            # --------------------------------------------------

            h, w = frame.shape[:2]

            x1 = max(
                0,
                min(x1, w - 1)
            )

            x2 = max(
                0,
                min(x2, w)
            )

            y1 = max(
                0,
                min(y1, h - 1)
            )

            y2 = max(
                0,
                min(y2, h)
            )

            if x2 <= x1 or y2 <= y1:

                continue

            plate_crop = frame[
                y1:y2,
                x1:x2
            ]

            if plate_crop.size == 0:

                continue

            # ==================================================
            # OCR
            # ==================================================

            text = ""

            ocr_confidence = 0.0

            # --------------------------------------------------
            # If we already know the plate and cooldown
            # has not expired, use cached result.
            # --------------------------------------------------

            if (
                track_id in self.plate_results
                and not self.can_run_ocr(track_id)
            ):

                cached = self.plate_results[
                    track_id
                ]

                text = cached[
                    "plate_number"
                ]

                ocr_confidence = cached[
                    "ocr_confidence"
                ]

            else:

                try:

                    text, ocr_confidence = (
                        self.ocr.read(
                            plate_crop
                        )
                    )

                except Exception as e:

                    print(
                        "OCR error:",
                        e
                    )

                    text = ""

                    ocr_confidence = 0.0

                self.last_ocr_time[
                    track_id
                ] = time.time()

            # ==================================================
            # CLEAN TEXT
            # ==================================================

            text = str(
                text
            ).strip().upper()

            # ==================================================
            # STORE RESULT
            # ==================================================

            result = {

                "track_id":
                    track_id,

                "vehicle_type":
                    vehicle_type,

                "plate_bbox":
                    plate_bbox,

                "plate_confidence":
                    plate_confidence,

                "plate_number":
                    text,

                "ocr_confidence":
                    float(
                        ocr_confidence
                    ),

                "timestamp":
                    time.time()
            }

            self.plate_results[
                track_id
            ] = result

            results.append(
                result
            )

        return results

    # ==========================================================
    # DRAW ANPR RESULTS
    # ==========================================================

    def draw(
        self,
        frame,
        anpr_results
    ):

        for result in anpr_results:

            x1, y1, x2, y2 = result[
                "plate_bbox"
            ]

            plate_number = result[
                "plate_number"
            ]

            plate_confidence = result[
                "plate_confidence"
            ]

            ocr_confidence = result[
                "ocr_confidence"
            ]

            track_id = result[
                "track_id"
            ]

            # ==================================================
            # PLATE BOX
            # ==================================================

            cv2.rectangle(

                frame,

                (x1, y1),

                (x2, y2),

                (0, 255, 255),

                2
            )

            # ==================================================
            # PLATE NUMBER
            # ==================================================

            if plate_number:

                label = (
                    f"{plate_number}"
                )

            else:

                label = "READING..."

            cv2.putText(

                frame,

                label,

                (
                    x1,
                    max(
                        20,
                        y1 - 10
                    )
                ),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.60,

                (0, 255, 255),

                2
            )

            # ==================================================
            # TRACK ID
            # ==================================================

            cv2.putText(

                frame,

                f"Vehicle ID: {track_id}",

                (
                    x1,
                    y2 + 20
                ),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.45,

                (255, 255, 255),

                1
            )

            # ==================================================
            # CONFIDENCE
            # ==================================================

            cv2.putText(

                frame,

                f"Plate: {plate_confidence:.2f} "
                f"OCR: {ocr_confidence:.2f}",

                (
                    x1,
                    y2 + 40
                ),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.40,

                (255, 255, 255),

                1
            )

        return frame

    # ==========================================================
    # GET PLATE FOR VEHICLE
    # ==========================================================

    def get_plate(
        self,
        track_id
    ):

        return self.plate_results.get(
            track_id
        )

    # ==========================================================
    # RESET VEHICLE
    # ==========================================================

    def reset_track(
        self,
        track_id
    ):

        self.plate_results.pop(
            track_id,
            None
        )

        self.last_ocr_time.pop(
            track_id,
            None
        )

    # ==========================================================
    # RESET ALL
    # ==========================================================

    def reset_all(self):

        self.plate_results.clear()

        self.last_ocr_time.clear()