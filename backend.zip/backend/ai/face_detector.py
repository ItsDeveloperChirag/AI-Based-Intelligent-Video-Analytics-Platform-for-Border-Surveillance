import cv2
from pathlib import Path


class FaceDetector:
    """
    Face Detection using OpenCV YuNet.

    Detects faces and returns:
    - bounding box
    - confidence
    - face landmarks
    """

    def __init__(
        self,
        model_path="models/face_detection_yunet_2023mar.onnx",
        confidence=0.6,
        input_size=(640, 480)
    ):
        project_root = Path(__file__).resolve().parent.parent

        self.model_path = project_root / model_path
        self.confidence = confidence
        self.input_size = input_size

        print("Loading face detection model...")
        print(f"Model: {self.model_path}")

        if not self.model_path.exists():
            raise FileNotFoundError(
                f"\n❌ Face model not found:\n"
                f"{self.model_path}\n\n"
                f"Please download:\n"
                f"face_detection_yunet_2023mar.onnx"
            )

        self.detector = cv2.FaceDetectorYN.create(
            str(self.model_path),
            "",
            self.input_size,
            self.confidence,
            0.3,
            5000
        )

        print("✅ Face detection model loaded")

    def detect(self, frame):
        """
        Detect faces in a frame.

        Returns:
            list of dictionaries
        """

        if frame is None:
            return []

        height, width = frame.shape[:2]

        # Update detector input size
        self.detector.setInputSize((width, height))

        _, faces = self.detector.detect(frame)

        detected_faces = []

        if faces is None:
            return detected_faces

        for face in faces:

            x = int(face[0])
            y = int(face[1])
            w = int(face[2])
            h = int(face[3])

            confidence = float(face[-1])

            # Keep coordinates inside image
            x = max(0, x)
            y = max(0, y)

            w = min(w, width - x)
            h = min(h, height - y)

            detected_faces.append({
                "bbox": [x, y, w, h],
                "confidence": confidence,
                "landmarks": {
                    "right_eye": [
                        float(face[4]),
                        float(face[5])
                    ],
                    "left_eye": [
                        float(face[6]),
                        float(face[7])
                    ],
                    "nose": [
                        float(face[8]),
                        float(face[9])
                    ],
                    "right_mouth": [
                        float(face[10]),
                        float(face[11])
                    ],
                    "left_mouth": [
                        float(face[12]),
                        float(face[13])
                    ]
                }
            })

        return detected_faces

    def detect_and_draw(self, frame):
        """
        Detect faces and draw bounding boxes.
        """

        faces = self.detect(frame)

        output = frame.copy()

        for index, face in enumerate(faces, start=1):

            x, y, w, h = face["bbox"]
            confidence = face["confidence"]

            # Face bounding box
            cv2.rectangle(
                output,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                2
            )

            # Label
            label = (
                f"FACE {index} "
                f"{confidence:.2f}"
            )

            # Label background
            label_y = max(25, y)

            cv2.rectangle(
                output,
                (x, label_y - 25),
                (x + 150, label_y),
                (0, 255, 0),
                -1
            )

            cv2.putText(
                output,
                label,
                (x + 5, label_y - 7),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (0, 0, 0),
                2
            )

            # Draw landmarks
            landmarks = face["landmarks"]

            for point in landmarks.values():

                px = int(point[0])
                py = int(point[1])

                cv2.circle(
                    output,
                    (px, py),
                    2,
                    (255, 0, 0),
                    -1
                )

        return output, faces