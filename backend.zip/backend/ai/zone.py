import cv2


class RestrictedZone:
    """
    User-defined polygon restricted zone.

    Example:

        point 1 -------- point 2
           |               |
           |   RESTRICTED  |
           |      ZONE     |
           |               |
        point 4 -------- point 3
    """

    def __init__(self, points=None):

        self.points = points or []

        # Previous center position for every tracked object
        self.previous_positions = {}

        # Tracks currently considered inside
        self.inside_tracks = set()

    # ---------------------------------------------------------
    # SET POLYGON
    # ---------------------------------------------------------

    def set_polygon(self, points):

        self.points = list(points)

        self.previous_positions.clear()
        self.inside_tracks.clear()

    # ---------------------------------------------------------
    # CLEAR
    # ---------------------------------------------------------

    def clear(self):

        self.points = []

        self.previous_positions.clear()
        self.inside_tracks.clear()

    # ---------------------------------------------------------
    # CHECK DEFINED
    # ---------------------------------------------------------

    def is_defined(self):

        return len(self.points) >= 4

    # ---------------------------------------------------------
    # POINT INSIDE POLYGON
    # ---------------------------------------------------------

    def is_point_inside(self, point):

        if not self.is_defined():
            return False

        x, y = point

        inside = False

        j = len(self.points) - 1

        for i in range(len(self.points)):

            xi, yi = self.points[i]
            xj, yj = self.points[j]

            intersects = (
                ((yi > y) != (yj > y))
                and
                (
                    x
                    <
                    (xj - xi)
                    * (y - yi)
                    /
                    ((yj - yi) + 1e-9)
                    + xi
                )
            )

            if intersects:
                inside = not inside

            j = i

        return inside

    # ---------------------------------------------------------
    # SEGMENT GEOMETRY
    # ---------------------------------------------------------

    @staticmethod
    def _orientation(a, b, c):

        value = (
            (b[1] - a[1]) * (c[0] - b[0])
            -
            (b[0] - a[0]) * (c[1] - b[1])
        )

        if abs(value) < 1e-9:
            return 0

        return 1 if value > 0 else 2

    @staticmethod
    def _on_segment(a, b, c):

        return (
            min(a[0], c[0]) <= b[0] <= max(a[0], c[0])
            and
            min(a[1], c[1]) <= b[1] <= max(a[1], c[1])
        )

    @classmethod
    def _segments_intersect(cls, p1, p2, q1, q2):

        o1 = cls._orientation(p1, p2, q1)
        o2 = cls._orientation(p1, p2, q2)

        o3 = cls._orientation(q1, q2, p1)
        o4 = cls._orientation(q1, q2, p2)

        if o1 != o2 and o3 != o4:
            return True

        if o1 == 0 and cls._on_segment(p1, q1, p2):
            return True

        if o2 == 0 and cls._on_segment(p1, q2, p2):
            return True

        if o3 == 0 and cls._on_segment(q1, p1, q2):
            return True

        if o4 == 0 and cls._on_segment(q1, p2, q2):
            return True

        return False

    # ---------------------------------------------------------
    # CHECK TRAJECTORY ENTRY
    # ---------------------------------------------------------

    def check_intrusion(self, track_id, center):

        if not self.is_defined():

            return {
                "intrusion": False,
                "inside": False
            }

        # First observation
        if track_id not in self.previous_positions:

            self.previous_positions[track_id] = center

            inside = self.is_point_inside(center)

            if inside:
                self.inside_tracks.add(track_id)

            return {
                "intrusion": False,
                "inside": inside
            }

        previous_center = self.previous_positions[track_id]

        previous_inside = self.is_point_inside(
            previous_center
        )

        current_inside = self.is_point_inside(
            center
        )

        intrusion = False

        # -----------------------------------------------------
        # OUTSIDE -> INSIDE
        # -----------------------------------------------------

        if not previous_inside and current_inside:

            if track_id not in self.inside_tracks:

                intrusion = True
                self.inside_tracks.add(track_id)

        # -----------------------------------------------------
        # TRAJECTORY CROSSES ZONE BOUNDARY
        # -----------------------------------------------------

        elif not previous_inside and not current_inside:

            for i in range(len(self.points)):

                p1 = self.points[i]
                p2 = self.points[
                    (i + 1) % len(self.points)
                ]

                if self._segments_intersect(
                    previous_center,
                    center,
                    p1,
                    p2
                ):

                    # Crossing boundary
                    # and current point outside.
                    # Don't trigger as permanent entry.
                    break

        # -----------------------------------------------------
        # OBJECT EXITED
        # -----------------------------------------------------

        if not current_inside:

            self.inside_tracks.discard(track_id)

        # Update trajectory
        self.previous_positions[track_id] = center

        return {
            "intrusion": intrusion,
            "inside": current_inside
        }

    # ---------------------------------------------------------
    # DRAW ZONE
    # ---------------------------------------------------------

    def draw(self, frame):

        if len(self.points) == 0:
            return frame

        # Draw points
        for point in self.points:

            cv2.circle(
                frame,
                point,
                5,
                (0, 255, 255),
                -1
            )

        # Draw polygon lines
        if len(self.points) >= 2:

            for i in range(
                len(self.points) - 1
            ):

                cv2.line(
                    frame,
                    self.points[i],
                    self.points[i + 1],
                    (0, 255, 255),
                    2
                )

        # Close polygon
        if self.is_defined():

            cv2.line(
                frame,
                self.points[-1],
                self.points[0],
                (0, 255, 255),
                2
            )

            # Transparent fill
            overlay = frame.copy()

            pts = __import__("numpy").array(
                self.points,
                dtype="int32"
            )

            cv2.fillPoly(
                overlay,
                [pts],
                (0, 255, 255)
            )

            cv2.addWeighted(
                overlay,
                0.15,
                frame,
                0.85,
                0,
                frame
            )

            x, y = self.points[0]

            cv2.putText(
                frame,
                "RESTRICTED ZONE",
                (
                    x,
                    max(25, y - 10)
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 255),
                2
            )

        return frame