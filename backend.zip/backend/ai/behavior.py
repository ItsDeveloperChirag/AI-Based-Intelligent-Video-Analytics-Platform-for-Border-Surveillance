from collections import defaultdict
import time


class BehaviorAnalyzer:
    """
    Behavior analysis engine for tracked objects.

    It combines:
    - Loitering
    - Border crossing
    - Restricted-zone intrusion
    - Movement
    - Recent behavior history
    """

    def __init__(self, history_size=20):
        self.history_size = history_size
        self.history = defaultdict(list)

    # ==========================================================
    # ANALYZE BEHAVIOR
    # ==========================================================

    def analyze(
        self,
        track_id,
        object_type,
        loitering=False,
        loitering_duration=0.0,
        movement=0.0,
        border_crossed=False,
        zone_intrusion=False,
        direction=None
    ):

        reasons = []

        behavior = "NORMAL"
        severity = "LOW"

        # ------------------------------------------------------
        # BORDER CROSSING
        # ------------------------------------------------------

        if border_crossed:

            behavior = "BORDER_CROSSING"
            severity = "HIGH"

            reasons.append(
                "Virtual border crossed"
            )

        # ------------------------------------------------------
        # RESTRICTED ZONE
        # ------------------------------------------------------

        if zone_intrusion:

            behavior = "RESTRICTED_ZONE_INTRUSION"
            severity = "HIGH"

            reasons.append(
                "Restricted zone entered"
            )

        # ------------------------------------------------------
        # LOITERING
        # ------------------------------------------------------

        if loitering:

            # Don't overwrite a more serious event
            if not border_crossed and not zone_intrusion:

                behavior = "LOITERING"
                severity = "MEDIUM"

            reasons.append(
                f"Object remained in the area for "
                f"{loitering_duration:.1f} seconds"
            )

        # ------------------------------------------------------
        # LOW MOVEMENT
        # ------------------------------------------------------

        if movement < 20:

            reasons.append(
                "Very low movement detected"
            )

        # ------------------------------------------------------
        # SUSPICIOUS ACTIVITY
        # ------------------------------------------------------

        suspicious_signals = 0

        if loitering:
            suspicious_signals += 1

        if border_crossed:
            suspicious_signals += 1

        if zone_intrusion:
            suspicious_signals += 1

        if movement < 20:
            suspicious_signals += 1

        # Multiple suspicious signals
        if suspicious_signals >= 2:

            if not border_crossed and not zone_intrusion:

                behavior = "SUSPICIOUS_ACTIVITY"
                severity = "MEDIUM"

        # ------------------------------------------------------
        # RESULT
        # ------------------------------------------------------

        result = {
            "track_id": track_id,
            "object_type": object_type,
            "behavior": behavior,
            "severity": severity,
            "loitering": bool(loitering),
            "loitering_duration": round(
                loitering_duration,
                2
            ),
            "movement": round(
                movement,
                2
            ),
            "border_crossed": bool(
                border_crossed
            ),
            "zone_intrusion": bool(
                zone_intrusion
            ),
            "direction": direction,
            "reasons": reasons,
            "timestamp": time.time()
        }

        # ------------------------------------------------------
        # STORE HISTORY
        # ------------------------------------------------------

        self.history[track_id].append(
            result
        )

        if len(
            self.history[track_id]
        ) > self.history_size:

            self.history[track_id].pop(0)

        return result

    # ==========================================================
    # GET CURRENT BEHAVIOR
    # ==========================================================

    def get_behavior(self, track_id):

        if track_id not in self.history:
            return None

        if not self.history[track_id]:
            return None

        return self.history[track_id][-1]

    # ==========================================================
    # GET HISTORY
    # ==========================================================

    def get_history(self, track_id):

        return self.history.get(
            track_id,
            []
        )

    # ==========================================================
    # RESET TRACK
    # ==========================================================

    def reset_track(self, track_id):

        if track_id in self.history:

            del self.history[track_id]

    # ==========================================================
    # RESET EVERYTHING
    # ==========================================================

    def reset_all(self):

        self.history.clear()