import time
from collections import defaultdict, deque

import cv2
import numpy as np


class NightMovementDetector:
    """
    Detects night / IR conditions and movement of tracked persons.

    Night detection uses:
    1. Brightness
    2. Color saturation
    3. Grayscale / IR-like appearance
    """

    def __init__(
        self,
        brightness_threshold=110.0,
        saturation_threshold=18.0,
        min_movement=12.0,
        history_size=8,
        cooldown=5.0
    ):
        self.brightness_threshold = float(
            brightness_threshold
        )

        self.saturation_threshold = float(
            saturation_threshold
        )

        self.min_movement = float(
            min_movement
        )

        self.history_size = max(
            3,
            int(history_size)
        )

        self.cooldown = float(
            cooldown
        )

        self.track_history = defaultdict(
            lambda: deque(
                maxlen=self.history_size
            )
        )

        self.last_event_time = {}

    # =========================================================
    # NIGHT / DAY DETECTION
    # =========================================================

    def analyze_frame(self, frame):

        if frame is None:
            return {
                "is_night": False,
                "brightness": 0.0,
                "saturation": 0.0,
                "ir_like": False
            }

        try:

            # ---------------------------------------------
            # Grayscale
            # ---------------------------------------------

            gray = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2GRAY
            )

            brightness = float(
                np.mean(gray)
            )

            # ---------------------------------------------
            # HSV / Saturation
            # ---------------------------------------------

            hsv = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2HSV
            )

            saturation = float(
                np.mean(hsv[:, :, 1])
            )

            # ---------------------------------------------
            # IR detection
            # ---------------------------------------------

            ir_like = (
                saturation <
                self.saturation_threshold
            )

            # ---------------------------------------------
            # Night decision
            # ---------------------------------------------

            if ir_like:

                is_night = True

            elif brightness < self.brightness_threshold:

                is_night = True

            else:

                is_night = False

            return {
                "is_night": is_night,
                "brightness": brightness,
                "saturation": saturation,
                "ir_like": ir_like
            }

        except Exception as e:

            print(
                "Night detection error:",
                e
            )

            return {
                "is_night": False,
                "brightness": 0.0,
                "saturation": 0.0,
                "ir_like": False
            }

    # =========================================================
    # TRACK MOVEMENT
    # =========================================================

    def update_track(
        self,
        track_id,
        center,
        frame_is_night
    ):

        track_id = int(track_id)

        history = self.track_history[
            track_id
        ]

        current_point = (
            int(center[0]),
            int(center[1])
        )

        movement = 0.0

        if history:

            previous = history[-1]

            movement = (
                (
                    (
                        current_point[0]
                        -
                        previous[0]
                    ) ** 2
                    +
                    (
                        current_point[1]
                        -
                        previous[1]
                    ) ** 2
                ) ** 0.5
            )

        history.append(
            current_point
        )

        night_movement = False

        if frame_is_night:

            now = time.time()

            last_event = self.last_event_time.get(
                track_id,
                0.0
            )

            if (
                movement >= self.min_movement
                and
                now - last_event >= self.cooldown
            ):

                night_movement = True

                self.last_event_time[
                    track_id
                ] = now

        return {
            "night_movement": night_movement,
            "movement": movement
        }

    # =========================================================
    # RESET ONE TRACK
    # =========================================================

    def reset_track(self, track_id):

        track_id = int(track_id)

        self.track_history.pop(
            track_id,
            None
        )

        self.last_event_time.pop(
            track_id,
            None
        )

    # =========================================================
    # CLEAR ALL TRACKS
    # =========================================================

    def clear(self):

        self.track_history.clear()

        self.last_event_time.clear()