import cv2


class FaceTracker:
    """
    Face Detection + Human Tracking Association

    Workflow:

        YOLO Person Tracking
                ↓
        Person Bounding Box
                ↓
        Crop Person
                ↓
        Face Detection inside Person Crop
                ↓
        Associate Face with Person ID
    """

    def __init__(
        self,
        face_detector,
        min_face_width=15,
        min_face_height=15
    ):
        self.face_detector = face_detector

        # Ignore extremely tiny face detections
        self.min_face_width = min_face_width
        self.min_face_height = min_face_height

    # =====================================================
    # Crop person from frame
    # =====================================================

    @staticmethod
    def crop_person(frame, bbox):

        height, width = frame.shape[:2]

        x1, y1, x2, y2 = bbox

        # Keep coordinates inside frame
        x1 = max(0, min(x1, width - 1))
        y1 = max(0, min(y1, height - 1))

        x2 = max(0, min(x2, width))
        y2 = max(0, min(y2, height))

        if x2 <= x1 or y2 <= y1:
            return None, (x1, y1)

        crop = frame[y1:y2, x1:x2]

        return crop, (x1, y1)

    # =====================================================
    # Validate face size
    # =====================================================

    def valid_face_size(self, face):

        x, y, w, h = face["bbox"]

        return (
            w >= self.min_face_width
            and
            h >= self.min_face_height
        )

    # =====================================================
    # Process all tracked persons
    # =====================================================

    def process(self, frame, tracks):

        if frame is None:
            return []

        results = []

        for track in tracks:

            # ---------------------------------------------
            # Only process persons
            # ---------------------------------------------

            if track.get("class_name") != "person":
                continue

            person_id = track.get("track_id")

            person_bbox = track.get("bbox")

            if person_bbox is None:
                continue

            # ---------------------------------------------
            # Crop person
            # ---------------------------------------------

            person_crop, offset = self.crop_person(
                frame,
                person_bbox
            )

            if person_crop is None:
                continue

            if person_crop.size == 0:
                continue

            offset_x, offset_y = offset

            # ---------------------------------------------
            # Detect face inside person crop
            # ---------------------------------------------

            faces = self.face_detector.detect(
                person_crop
            )

            # ---------------------------------------------
            # Process detected faces
            # ---------------------------------------------

            for face in faces:

                if not self.valid_face_size(face):
                    continue

                x, y, w, h = face["bbox"]

                # Convert crop coordinates
                # back to original frame coordinates

                original_x = x + offset_x
                original_y = y + offset_y

                face_bbox = [
                    original_x,
                    original_y,
                    w,
                    h
                ]

                results.append({

                    "person_id": person_id,

                    "person_bbox": person_bbox,

                    "face_bbox": face_bbox,

                    "face_confidence":
                        face["confidence"],

                    "face_width": w,

                    "face_height": h
                })

        return results

    # =====================================================
    # Draw results
    # =====================================================

    def draw(
        self,
        frame,
        face_results,
        draw_person_box=False
    ):

        output = frame.copy()

        for result in face_results:

            person_id = result["person_id"]

            x, y, w, h = result["face_bbox"]

            confidence = result[
                "face_confidence"
            ]

            # ---------------------------------------------
            # Face rectangle
            # ---------------------------------------------

            cv2.rectangle(
                output,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                2
            )

            # ---------------------------------------------
            # Face label
            # ---------------------------------------------

            label = (
                f"ID:{person_id} "
                f"FACE {confidence:.2f}"
            )

            label_y = max(25, y)

            text_size = cv2.getTextSize(
                label,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                2
            )[0]

            cv2.rectangle(
                output,
                (x, label_y - 25),
                (
                    x + text_size[0] + 10,
                    label_y
                ),
                (0, 255, 0),
                -1
            )

            cv2.putText(
                output,
                label,
                (x + 5, label_y - 7),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (0, 0, 0),
                2
            )

            # ---------------------------------------------
            # Optional person bounding box
            # ---------------------------------------------

            if draw_person_box:

                px1, py1, px2, py2 = (
                    result["person_bbox"]
                )

                cv2.rectangle(
                    output,
                    (px1, py1),
                    (px2, py2),
                    (255, 0, 0),
                    2
                )

        return output