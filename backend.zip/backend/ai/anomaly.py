class AnomalyDetector:

    def __init__(self):
        pass

    def analyze(
        self,
        inside_zone=False,
        loitering=False,
        approaching_border=False,
        border_crossed=False,
        suspicious_movement=False,
        distance=0
    ):

        anomaly_score = 0
        reasons = []

        # ====================================================
        # RESTRICTED ZONE INTRUSION
        # ====================================================

        if inside_zone:
            anomaly_score += 25
            reasons.append("Restricted zone intrusion")


        # ====================================================
        # LOITERING
        # ====================================================

        if loitering:
            anomaly_score += 20
            reasons.append("Prolonged loitering")


        # ====================================================
        # APPROACHING BORDER
        # ====================================================

        if approaching_border:
            anomaly_score += 15
            reasons.append("Approaching virtual border")


        # ====================================================
        # BORDER CROSSING
        # ====================================================

        if border_crossed:
            anomaly_score += 30
            reasons.append("Virtual border crossing")


        # ====================================================
        # SUSPICIOUS MOVEMENT
        # ====================================================

        if suspicious_movement:
            anomaly_score += 20
            reasons.append("Suspicious movement")


        # ====================================================
        # RAPID MOVEMENT
        # ====================================================

        if distance > 150:
            anomaly_score += 10
            reasons.append("Rapid movement")


        # ====================================================
        # LIMIT SCORE
        # ====================================================

        anomaly_score = min(
            anomaly_score,
            100
        )


        # ====================================================
        # ANOMALY LEVEL
        # ====================================================

        if anomaly_score <= 30:

            level = "NORMAL"

        elif anomaly_score <= 60:

            level = "SUSPICIOUS"

        elif anomaly_score <= 80:

            level = "HIGH"

        else:

            level = "CRITICAL"


        # ====================================================
        # ANOMALY STATUS
        # ====================================================

        is_anomaly = anomaly_score > 30


        return {
            "is_anomaly": is_anomaly,
            "anomaly_score": anomaly_score,
            "level": level,
            "reasons": reasons
        }