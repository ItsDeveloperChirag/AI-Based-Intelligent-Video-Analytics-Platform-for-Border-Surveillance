from ai.stream_manager import StreamManager
from database import get_connection


class CameraManager:

    def __init__(self):
        # Active stream objects memory mein rahenge
        self.streams = {}

    # --------------------------------------------------
    # ADD CAMERA
    # --------------------------------------------------
    def add_camera(self, camera_id, name, source):

        connection = get_connection()
        cursor = connection.cursor()

        try:
            cursor.execute(
                """
                SELECT camera_id
                FROM cameras
                WHERE camera_id = %s
                """,
                (camera_id,)
            )

            existing = cursor.fetchone()

            if existing:
                return False

            cursor.execute(
                """
                INSERT INTO cameras
                (camera_id, name, source, status)
                VALUES (%s, %s, %s, %s)
                """,
                (
                    camera_id,
                    name,
                    source,
                    "STOPPED"
                )
            )

            connection.commit()

            print(f"✅ Camera {camera_id} saved to MySQL")

            return True

        finally:
            cursor.close()
            connection.close()

    # --------------------------------------------------
    # START CAMERA
    # --------------------------------------------------
    def start_camera(self, camera_id):

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        try:
            cursor.execute(
                """
                SELECT *
                FROM cameras
                WHERE camera_id = %s
                """,
                (camera_id,)
            )

            camera = cursor.fetchone()

            if not camera:
                return False

            # Already running
            if camera_id in self.streams:
                return True

            stream = StreamManager(camera["source"])

            if not stream.start():
                return False

            self.streams[camera_id] = stream

            cursor.execute(
                """
                UPDATE cameras
                SET status = 'RUNNING'
                WHERE camera_id = %s
                """,
                (camera_id,)
            )

            connection.commit()

            print(f"🟢 Camera {camera_id} started")

            return True

        finally:
            cursor.close()
            connection.close()

    # --------------------------------------------------
    # READ FRAME
    # --------------------------------------------------
    def read_frame(self, camera_id):

        if camera_id not in self.streams:
            return False, None

        return self.streams[camera_id].read()

    # --------------------------------------------------
    # STOP CAMERA
    # --------------------------------------------------
    def stop_camera(self, camera_id):

        connection = get_connection()
        cursor = connection.cursor()

        try:

            if camera_id in self.streams:

                self.streams[camera_id].release()

                del self.streams[camera_id]

            cursor.execute(
                """
                UPDATE cameras
                SET status = 'STOPPED'
                WHERE camera_id = %s
                """,
                (camera_id,)
            )

            connection.commit()

            print(f"🔴 Camera {camera_id} stopped")

            return True

        finally:
            cursor.close()
            connection.close()

    # --------------------------------------------------
    # REMOVE CAMERA
    # --------------------------------------------------
    def remove_camera(self, camera_id):

        # Stop stream first
        self.stop_camera(camera_id)

        connection = get_connection()
        cursor = connection.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM cameras
                WHERE camera_id = %s
                """,
                (camera_id,)
            )

            connection.commit()

            print(f"🗑️ Camera {camera_id} removed from MySQL")

            return cursor.rowcount > 0

        finally:
            cursor.close()
            connection.close()

    # --------------------------------------------------
    # GET ONE CAMERA
    # --------------------------------------------------
    def get_camera(self, camera_id):

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        try:

            cursor.execute(
                """
                SELECT *
                FROM cameras
                WHERE camera_id = %s
                """,
                (camera_id,)
            )

            return cursor.fetchone()

        finally:
            cursor.close()
            connection.close()

    # --------------------------------------------------
    # GET ALL CAMERAS
    # --------------------------------------------------
    def get_all_cameras(self):

        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        try:

            cursor.execute(
                """
                SELECT *
                FROM cameras
                ORDER BY id DESC
                """
            )

            return cursor.fetchall()

        finally:
            cursor.close()
            connection.close()