from datetime import datetime


class ThreatEngine:
    """
    Threat scoring engine for the AI Border Surveillance System.

    The engine combines multiple security signals:

    - Border crossing
    - Restricted zone intrusion
    - Loitering
    - Suspicious behavior
    - Object type
    - Movement

    Output:
        threat_score
        threat_level
        reasons
    """

    def __init__(self):

        # ------------------------------------------------------
        # SCORE WEIGHTS
        # ------------------------------------------------------

        self.weights = {
            "border_crossing": 40,
            "restricted_zone": 35,
            "loitering": 20,
            "suspicious_behavior": 15,
            "low_movement": 5,
            "vehicle_in_restricted_zone": 10
        }

        # ------------------------------------------------------
        # THREAT LEVEL LIMITS
        # ------------------------------------------------------

        self.levels = {
            "LOW": 0,
            "MEDIUM": 30,
            "HIGH": 60,
            "CRITICAL": 85
        }

    # ==========================================================
    # CALCULATE THREAT
    # ==========================================================

    def calculate(
        self,
        object_type="person",
        border_crossed=False,
        zone_intrusion=False,
        loitering=False,
        loitering_duration=0.0,
        behavior="NORMAL",
        movement=100.0
    ):

        score = 0

        reasons = []

        # ------------------------------------------------------
        # BORDER CROSSING
        # ------------------------------------------------------

        if border_crossed:

            points = self.weights[
                "border_crossing"
            ]

            score += points

            reasons.append(
                f"Virtual border crossed (+{points})"
            )

        # ------------------------------------------------------
        # RESTRICTED ZONE
        # ------------------------------------------------------

        if zone_intrusion:

            points = self.weights[
                "restricted_zone"
            ]

            score += points

            reasons.append(
                f"Restricted zone intrusion (+{points})"
            )

        # ------------------------------------------------------
        # LOITERING
        # ------------------------------------------------------

        if loitering:

            points = self.weights[
                "loitering"
            ]

            score += points

            reasons.append(
                f"Loitering detected for "
                f"{loitering_duration:.1f} seconds (+{points})"
            )

        # ------------------------------------------------------
        # SUSPICIOUS BEHAVIOR
        # ------------------------------------------------------

        if behavior == "SUSPICIOUS_ACTIVITY":

            points = self.weights[
                "suspicious_behavior"
            ]

            score += points

            reasons.append(
                f"Suspicious activity detected (+{points})"
            )

        # ------------------------------------------------------
        # LOW MOVEMENT
        # ------------------------------------------------------

        if movement < 20:

            points = self.weights[
                "low_movement"
            ]

            score += points

            reasons.append(
                f"Very low movement (+{points})"
            )

        # ------------------------------------------------------
        # VEHICLE INSIDE RESTRICTED AREA
        # ------------------------------------------------------

        if (
            zone_intrusion
            and object_type in [
                "car",
                "motorcycle",
                "bus",
                "truck"
            ]
        ):

            points = self.weights[
                "vehicle_in_restricted_zone"
            ]

            score += points

            reasons.append(
                f"Vehicle detected inside restricted "
                f"zone (+{points})"
            )

        # ------------------------------------------------------
        # LIMIT SCORE
        # ------------------------------------------------------

        score = min(
            score,
            100
        )

        # ------------------------------------------------------
        # THREAT LEVEL
        # ------------------------------------------------------

        threat_level = self._get_level(
            score
        )

        # ------------------------------------------------------
        # RESULT
        # ------------------------------------------------------

        return {
            "threat_score": score,
            "threat_level": threat_level,
            "reasons": reasons,
            "timestamp": datetime.now().isoformat()
        }

    # ==========================================================
    # GET THREAT LEVEL
    # ==========================================================

    def _get_level(self, score):

        if score >= self.levels["CRITICAL"]:

            return "CRITICAL"

        elif score >= self.levels["HIGH"]:

            return "HIGH"

        elif score >= self.levels["MEDIUM"]:

            return "MEDIUM"

        return "LOW"

    # ==========================================================
    # COMBINE WITH BEHAVIOR RESULT
    # ==========================================================

    def evaluate_behavior(
        self,
        behavior_result
    ):

        if behavior_result is None:

            return self.calculate()

        return self.calculate(

            object_type=behavior_result.get(
                "object_type",
                "person"
            ),

            border_crossed=behavior_result.get(
                "border_crossed",
                False
            ),

            zone_intrusion=behavior_result.get(
                "zone_intrusion",
                False
            ),

            loitering=behavior_result.get(
                "loitering",
                False
            ),

            loitering_duration=behavior_result.get(
                "loitering_duration",
                0.0
            ),

            behavior=behavior_result.get(
                "behavior",
                "NORMAL"
            ),

            movement=behavior_result.get(
                "movement",
                100.0
            )
        )