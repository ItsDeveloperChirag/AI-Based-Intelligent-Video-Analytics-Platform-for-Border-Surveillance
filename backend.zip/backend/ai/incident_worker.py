"""Background incident processing.

Disk writes and HTTP requests must not block the real-time video loop.
"""

from queue import Queue, Empty
from threading import Thread, Event

from ai.evidence import EvidenceManager
from ai.api_client import send_incident


class IncidentWorker:

    def __init__(self, evidence_manager=None):
        self.evidence = evidence_manager or EvidenceManager()
        self.queue = Queue(maxsize=100)
        self.stop_event = Event()
        self.thread = Thread(target=self._run, daemon=True)

    def start(self):
        if not self.thread.is_alive():
            self.thread.start()
        print("🟢 Background incident worker started")

    def submit(self, frame, incident):
        # Copy only once here. The live frame will be modified immediately by
        # the next iteration of the video loop.
        job = (frame.copy(), incident.copy())

        try:
            self.queue.put_nowait(job)
            return True
        except Exception:
            print("⚠️ Incident queue full; dropping evidence job")
            return False

    def _run(self):
        while not self.stop_event.is_set() or not self.queue.empty():
            try:
                frame, incident = self.queue.get(timeout=0.2)
            except Empty:
                continue

            try:
                evidence_result = self.evidence.save_snapshot(
                    frame=frame,
                    track_id=incident.get("track_id", "unknown"),
                    event_type=incident.get("event_type", "UNKNOWN"),
                    threat_score=incident.get("threat_score", 0),
                    threat_level=incident.get("threat_level", "UNKNOWN")
                )

                if evidence_result.get("success"):
                    incident["evidence_path"] = evidence_result["filepath"]
                    incident["evidence_timestamp"] = evidence_result["timestamp"]

                # HTTP/database work is also kept off the real-time thread.
                result = send_incident(incident)
                if not result.get("success"):
                    print("⚠️ Incident API submission failed")

            except Exception as error:
                print(f"❌ Background incident processing error: {error}")
            finally:
                self.queue.task_done()

    def stop(self, wait=True):
        self.stop_event.set()
        if wait and self.thread.is_alive():
            self.thread.join(timeout=5)
        print("🛑 Background incident worker stopped")
