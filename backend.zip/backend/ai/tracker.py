from ultralytics import YOLO


class Tracker:

    def __init__(
        self,
        model_path="yolo11n.pt",
        confidence=0.25,
        image_size=640
    ):

        self.confidence = confidence
        self.image_size = image_size

        print("Loading tracking model...")

        self.model = YOLO(model_path)

        # Keep stable class for each track ID
        self.track_classes = {}

        print("✅ Tracking model loaded")

    # =========================================================
    # TRACK
    # =========================================================

    def track(self, frame):

        if frame is None:
            return None

        results = self.model.track(
            source=frame,
            conf=self.confidence,
            imgsz=self.image_size,
            persist=True,
            tracker="bytetrack.yaml",
            verbose=False
        )

        return results[0]

    # =========================================================
    # GET TRACKS
    # =========================================================

    def get_tracks(self, result):

        tracks = []

        if (
            result is None
            or result.boxes is None
        ):
            return tracks

        for box in result.boxes:

            # -------------------------------------------------
            # TRACK ID
            # -------------------------------------------------

            if box.id is not None:

                track_id = int(
                    box.id[0]
                )

            else:

                track_id = -1

            if track_id == -1:
                continue

            # -------------------------------------------------
            # CLASS
            # -------------------------------------------------

            class_id = int(
                box.cls[0]
            )

            confidence = float(
                box.conf[0]
            )

            detected_class = (
                self.model.names[class_id]
            )

            # -------------------------------------------------
            # STABILIZE CLASS
            # -------------------------------------------------

            if track_id not in self.track_classes:

                self.track_classes[
                    track_id
                ] = {
                    "class_id": class_id,
                    "class_name": detected_class,
                    "confidence": confidence
                }

            else:

                previous_class = (
                    self.track_classes[
                        track_id
                    ]["class_id"]
                )

                # Keep original class if YOLO
                # temporarily changes classification
                if class_id != previous_class:

                    class_id = previous_class

                    detected_class = (
                        self.track_classes[
                            track_id
                        ]["class_name"]
                    )

                else:

                    # Update confidence
                    self.track_classes[
                        track_id
                    ]["confidence"] = confidence

            # -------------------------------------------------
            # BOUNDING BOX
            # -------------------------------------------------

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            tracks.append({

                "track_id": track_id,

                "class_id": class_id,

                "class_name": detected_class,

                "confidence": confidence,

                "bbox": [
                    x1,
                    y1,
                    x2,
                    y2
                ]

            })

        return tracks

    # =========================================================
    # CLEAN OLD TRACK IDs
    # =========================================================

    def cleanup_tracks(
        self,
        active_track_ids
    ):

        active_track_ids = set(
            active_track_ids
        )

        old_ids = set(
            self.track_classes.keys()
        )

        for track_id in (
            old_ids - active_track_ids
        ):

            del self.track_classes[
                track_id
            ]