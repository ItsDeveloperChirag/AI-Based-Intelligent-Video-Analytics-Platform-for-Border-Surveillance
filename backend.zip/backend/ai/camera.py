import cv2
from config import CAMERA_URL

url = CAMERA_URL

cap = cv2.VideoCapture(url)

if not cap.isOpened():
    print("Camera connect nahi hua!")
    exit()

print("Live camera started!")
print("Q dabakar camera band karein.")

while True:
    ret, frame = cap.read()

    if not ret:
        print("Frame nahi mil raha...")
        break

    # Video ko chhota karke lag kam karna
    frame = cv2.resize(frame, (640, 480))

    cv2.imshow("Phone Camera - LIVE", frame)

    # Q press karke exit
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()