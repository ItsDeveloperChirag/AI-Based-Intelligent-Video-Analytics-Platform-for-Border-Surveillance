import math


class BorderDetector:
    """
    User-defined virtual border.

    Border is represented by two points:
        start_point = (x1, y1)
        end_point   = (x2, y2)

    Crossing is detected using the trajectory segment
    between previous and current object position.
    """

    def __init__(self, start_point=None, end_point=None):
        self.start_point = start_point
        self.end_point = end_point

        # Previous center position for each track
        self.previous_positions = {}

    # ---------------------------------------------------------
    # SET BORDER
    # ---------------------------------------------------------

    def set_border(self, start_point, end_point):

        self.start_point = start_point
        self.end_point = end_point

        # Reset old trajectory positions
        self.previous_positions.clear()

    # ---------------------------------------------------------
    # CLEAR BORDER
    # ---------------------------------------------------------

    def clear(self):

        self.start_point = None
        self.end_point = None
        self.previous_positions.clear()

    # ---------------------------------------------------------
    # CHECK WHETHER BORDER EXISTS
    # ---------------------------------------------------------

    def is_defined(self):

        return (
            self.start_point is not None
            and self.end_point is not None
        )

    # ---------------------------------------------------------
    # GEOMETRY
    # ---------------------------------------------------------

    @staticmethod
    def _orientation(a, b, c):

        value = (
            (b[1] - a[1]) * (c[0] - b[0])
            -
            (b[0] - a[0]) * (c[1] - b[1])
        )

        if abs(value) < 1e-9:
            return 0

        return 1 if value > 0 else 2

    @staticmethod
    def _on_segment(a, b, c):

        return (
            min(a[0], c[0]) <= b[0] <= max(a[0], c[0])
            and
            min(a[1], c[1]) <= b[1] <= max(a[1], c[1])
        )

    @classmethod
    def _segments_intersect(cls, p1, p2, q1, q2):

        o1 = cls._orientation(p1, p2, q1)
        o2 = cls._orientation(p1, p2, q2)

        o3 = cls._orientation(q1, q2, p1)
        o4 = cls._orientation(q1, q2, p2)

        if o1 != o2 and o3 != o4:
            return True

        if o1 == 0 and cls._on_segment(p1, q1, p2):
            return True

        if o2 == 0 and cls._on_segment(p1, q2, p2):
            return True

        if o3 == 0 and cls._on_segment(q1, p1, q2):
            return True

        if o4 == 0 and cls._on_segment(q1, p2, q2):
            return True

        return False

    # ---------------------------------------------------------
    # DETECT CROSSING
    # ---------------------------------------------------------

    def check_crossing(self, track_id, center):

        if not self.is_defined():

            return {
                "crossed": False,
                "direction": None
            }

        # First observation of this object
        if track_id not in self.previous_positions:

            self.previous_positions[track_id] = center

            return {
                "crossed": False,
                "direction": None
            }

        previous_center = self.previous_positions[track_id]

        crossed = self._segments_intersect(
            previous_center,
            center,
            self.start_point,
            self.end_point
        )

        direction = None

        if crossed:

            direction = self._get_direction(
                previous_center,
                center
            )

        # Update trajectory position
        self.previous_positions[track_id] = center

        return {
            "crossed": crossed,
            "direction": direction
        }

    # ---------------------------------------------------------
    # DETERMINE MOVEMENT DIRECTION
    # ---------------------------------------------------------

    def _get_direction(self, previous, current):

        dx = current[0] - previous[0]
        dy = current[1] - previous[1]

        if abs(dx) > abs(dy):

            if dx > 0:
                return "LEFT_TO_RIGHT"

            return "RIGHT_TO_LEFT"

        else:

            if dy > 0:
                return "TOP_TO_BOTTOM"

            return "BOTTOM_TO_TOP"

    # ---------------------------------------------------------
    # DRAW BORDER
    # ---------------------------------------------------------

    def draw(self, frame):

        import cv2

        if not self.is_defined():
            return frame

        cv2.line(
            frame,
            self.start_point,
            self.end_point,
            (0, 0, 255),
            2
        )

        cv2.circle(
            frame,
            self.start_point,
            6,
            (0, 255, 255),
            -1
        )

        cv2.circle(
            frame,
            self.end_point,
            6,
            (0, 255, 255),
            -1
        )

        text_x = min(
            self.start_point[0],
            self.end_point[0]
        )

        text_y = min(
            self.start_point[1],
            self.end_point[1]
        )

        cv2.putText(
            frame,
            "VIRTUAL BORDER",
            (
                text_x,
                max(25, text_y - 10)
            ),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 0, 255),
            2
        )

        return frame