import threading
import time


class ANPRWorker:

    def __init__(self, anpr_pipeline, interval=0.5):

        self.anpr = anpr_pipeline
        self.interval = interval

        self.lock = threading.Lock()

        self.pending_frame = None
        self.pending_vehicles = []

        self.latest_results = []

        self.job_running = False

        self.running = False
        self.thread = None

    # =========================================================
    # START
    # =========================================================

    def start(self):

        if self.running:
            return

        self.running = True

        self.thread = threading.Thread(
            target=self._worker_loop,
            daemon=True
        )

        self.thread.start()

        print("ANPR background worker started")

    # =========================================================
    # SUBMIT NEW FRAME
    # =========================================================

    def submit(self, frame, vehicles):

        if frame is None:
            return

        with self.lock:

            # Do not start another ANPR job
            # while previous one is still running.

            if self.job_running:
                return

            self.job_running = True

            self.pending_frame = frame.copy()

            self.pending_vehicles = list(vehicles)

    # =========================================================
    # BACKGROUND WORKER
    # =========================================================

    def _worker_loop(self):

        while self.running:

            frame = None
            vehicles = []

            with self.lock:

                if self.pending_frame is not None:

                    frame = self.pending_frame

                    vehicles = self.pending_vehicles

                    self.pending_frame = None

                    self.pending_vehicles = []

            # Nothing to process
            if frame is None:

                time.sleep(0.01)

                continue

            try:

                print("ANPR processing...")

                results = self.anpr.process(
                    frame,
                    vehicles
                )

                with self.lock:

                    self.latest_results = results

                if results:

                    for result in results:

                        print()
                        print("-" * 50)
                        print("VEHICLE DETECTED")
                        print(
                            "Track ID:",
                            result["track_id"]
                        )
                        print(
                            "Vehicle:",
                            result["vehicle_type"]
                        )
                        print(
                            "Plate:",
                            result["plate_number"]
                        )
                        print(
                            "Plate confidence:",
                            round(
                                result["plate_confidence"],
                                2
                            )
                        )
                        print(
                            "OCR confidence:",
                            round(
                                result["ocr_confidence"],
                                2
                            )
                        )
                        print("-" * 50)

            except Exception as e:

                print(
                    "ANPR ERROR:",
                    e
                )

            finally:

                with self.lock:

                    self.job_running = False

            time.sleep(
                self.interval
            )

    # =========================================================
    # GET LATEST RESULT
    # =========================================================

    def get_results(self):

        with self.lock:

            return list(
                self.latest_results
            )

    # =========================================================
    # STOP
    # =========================================================

    def stop(self):

        print(
            "Stopping ANPR worker..."
        )

        self.running = False

        if self.thread is not None:

            self.thread.join(
                timeout=2
            )

        print(
            "ANPR worker stopped"
        )