from datetime import datetime
import uuid

from ai.evidence import EvidenceManager
from database import save_incident


class IncidentManager:

    def __init__(self):
        self.evidence = EvidenceManager()

        print("✅ Incident Manager initialized")

    def create_event(
        self,
        event_type,
        track_id,
        object_type,
        confidence,
        direction=None,
        frame=None
    ):
        """
        Creates a complete incident.

        Flow:
        Incident
            ↓
        Event ID
            ↓
        Evidence Screenshot
            ↓
        MySQL Database
        """

        # -----------------------------------------
        # 1. Generate unique Event ID
        # -----------------------------------------

        timestamp = datetime.now()

        event_id = (
            "INC-"
            + timestamp.strftime("%Y%m%d-%H%M%S")
            + "-"
            + uuid.uuid4().hex[:6].upper()
        )

        # -----------------------------------------
        # 2. Save evidence screenshot
        # -----------------------------------------

        evidence_path = None

        if frame is not None:

            evidence_path = self.evidence.save_frame(
                frame,
                event_id
            )

        # -----------------------------------------
        # 3. Create incident object
        # -----------------------------------------

        event = {

            "event_id": event_id,

            "event_type": event_type,

            "track_id": int(track_id),

            "object_type": object_type,

            "confidence": float(confidence),

            "direction": direction,

            "timestamp": timestamp,

            "evidence_path": evidence_path,

            "status": "NEW"
        }

        # -----------------------------------------
        # 4. Save to database
        # -----------------------------------------

        try:

            save_incident(event)

            database_status = "SAVED"

        except Exception as e:

            database_status = "FAILED"

            print()
            print("❌ DATABASE ERROR")
            print(e)

        # -----------------------------------------
        # 5. Console output
        # -----------------------------------------

        print()
        print("===================================")
        print("        🚨 INCIDENT CREATED")
        print("===================================")

        print(f"Event ID    : {event_id}")
        print(f"Event Type  : {event_type}")
        print(f"Track ID    : {track_id}")
        print(f"Object      : {object_type}")
        print(f"Confidence  : {confidence:.2f}")
        print(f"Direction   : {direction}")
        print(f"Timestamp   : {timestamp}")

        if evidence_path:
            print(f"Evidence    : {evidence_path}")
        else:
            print("Evidence    : Not available")

        print(f"Database    : {database_status}")

        print("===================================")
        print()

        return event