import cv2
from pathlib import Path
from ultralytics import YOLO


class LicensePlateDetector:

    def __init__(
        self,
        model_path="models/license-plate-finetune-v1n.pt",
        confidence=0.35,
        image_size=640
    ):

        backend_dir = Path(__file__).resolve().parent.parent

        model_path = Path(model_path)

        if not model_path.is_absolute():
            model_path = backend_dir / model_path

        if not model_path.exists():

            raise FileNotFoundError(
                f"\n❌ License plate model not found:\n"
                f"{model_path}\n\n"
                f"Put your license plate YOLO .pt model "
                f"inside backend/models/"
            )

        self.model = YOLO(str(model_path))

        self.confidence = confidence
        self.image_size = image_size

        print("✅ License plate model loaded")

    def detect(self, frame):

        if frame is None:
            return []

        results = self.model.predict(
            source=frame,
            conf=self.confidence,
            imgsz=self.image_size,
            verbose=False
        )

        result = results[0]

        plates = []

        if result.boxes is None:
            return plates

        for box in result.boxes:

            confidence = float(box.conf[0])

            class_id = int(box.cls[0])

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            class_name = self.model.names[class_id]

            plates.append({
                "class_id": class_id,
                "class_name": class_name,
                "confidence": confidence,
                "bbox": [x1, y1, x2, y2]
            })

        return plates