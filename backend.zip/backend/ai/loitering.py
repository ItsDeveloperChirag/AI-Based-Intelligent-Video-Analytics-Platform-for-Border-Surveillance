import time
from collections import defaultdict


class LoiteringDetector:
    """
    Detects whether a tracked person/vehicle is staying in approximately
    the same area for too long.

    The detector works with tracking IDs and does not perform detection itself.
    """

    def __init__(
        self,
        loitering_time=20.0,
        movement_threshold=50.0,
        history_size=30
    ):
        self.loitering_time = loitering_time
        self.movement_threshold = movement_threshold
        self.history_size = history_size

        # track_id -> information about the tracked object
        self.tracks = defaultdict(self._new_track)

    def _new_track(self):
        return {
            "first_seen": None,
            "last_seen": None,
            "positions": [],
            "loitering": False,
            "loitering_start": None,
            "duration": 0.0
        }

    def _distance(self, p1, p2):
        dx = p1[0] - p2[0]
        dy = p1[1] - p2[1]

        return (dx * dx + dy * dy) ** 0.5

    def update(self, track_id, center):
        """
        Update the position of one tracked object.

        Parameters
        ----------
        track_id : int
            Tracking ID assigned by ByteTrack.

        center : tuple
            Object center as (x, y).

        Returns
        -------
        dict
            Loitering information.
        """

        if track_id is None or center is None:
            return {
                "loitering": False,
                "duration": 0.0,
                "movement": 0.0
            }

        now = time.time()

        track = self.tracks[track_id]

        # First observation
        if track["first_seen"] is None:
            track["first_seen"] = now

        track["last_seen"] = now

        # Store position
        track["positions"].append((center[0], center[1]))

        # Keep only recent positions
        if len(track["positions"]) > self.history_size:
            track["positions"].pop(0)

        # Calculate movement
        movement = self._calculate_movement(track["positions"])

        # Calculate total tracking duration
        duration = now - track["first_seen"]

        track["duration"] = duration

        # Loitering condition
        loitering_started = False

        if (
            duration >= self.loitering_time
            and movement <= self.movement_threshold
        ):
            if not track["loitering"]:
                track["loitering"] = True
                track["loitering_start"] = now
                loitering_started = True
        else:
            track["loitering"] = False
            track["loitering_start"] = None

        return {
            "track_id": track_id,
            "loitering": track["loitering"],
            "loitering_started": loitering_started,
            "duration": round(duration, 2),
            "movement": round(movement, 2)
        }

    def _calculate_movement(self, positions):
        """
        Calculate movement across the recent trajectory.

        Uses distance between consecutive positions.
        """

        if len(positions) < 2:
            return 0.0

        total_distance = 0.0

        for i in range(1, len(positions)):
            total_distance += self._distance(
                positions[i - 1],
                positions[i]
            )

        return total_distance

    def get_status(self, track_id):
        """
        Get current loitering status for a tracking ID.
        """

        if track_id not in self.tracks:
            return None

        track = self.tracks[track_id]

        movement = self._calculate_movement(
            track["positions"]
        )

        duration = time.time() - track["first_seen"]

        return {
            "track_id": track_id,
            "loitering": track["loitering"],
            "duration": round(duration, 2),
            "movement": round(movement, 2)
        }

    def reset_track(self, track_id):
        """
        Remove a tracking ID from the detector.
        """

        if track_id in self.tracks:
            del self.tracks[track_id]

    def reset_all(self):
        """
        Reset all tracked objects.
        """

        self.tracks.clear()