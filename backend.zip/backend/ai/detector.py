from ultralytics import YOLO
from pathlib import Path


class Detector:
    """
    YOLO-based object detector for IBVAP.

    Camera handling is intentionally NOT done here.
    The camera module provides frames to this detector.
    """

    def __init__(
        self,
        model_path="yolo11n.pt",
        confidence=0.35,
        image_size=640
    ):

        # -------------------------------------------------
        # Settings
        # -------------------------------------------------

        self.confidence = confidence
        self.image_size = image_size

        # -------------------------------------------------
        # Find model from backend root
        # -------------------------------------------------

        project_root = Path(__file__).resolve().parent.parent

        self.model_path = project_root / model_path

        if not self.model_path.exists():
            raise FileNotFoundError(
                f"YOLO model not found: {self.model_path}"
            )

        # -------------------------------------------------
        # Load YOLO
        # -------------------------------------------------

        print(f"Loading YOLO model: {self.model_path}")

        self.model = YOLO(str(self.model_path))

        print("✅ YOLO model loaded successfully")


    # =====================================================
    # DETECT
    # =====================================================

    def detect(self, frame):
        """
        Run YOLO detection on a single frame.

        Returns:
            results[0] from Ultralytics
        """

        if frame is None:
            return None

        results = self.model.predict(
            source=frame,
            conf=self.confidence,
            imgsz=self.image_size,
            verbose=False
        )

        return results[0]


    # =====================================================
    # ANNOTATED FRAME
    # =====================================================

    def detect_and_draw(self, frame):
        """
        Detect objects and return annotated frame.
        """

        result = self.detect(frame)

        if result is None:
            return frame, None

        annotated_frame = result.plot()

        return annotated_frame, result


    # =====================================================
    # GET DETECTIONS
    # =====================================================

    def get_detections(self, frame):
        """
        Convert YOLO output into simple dictionaries.

        Example:

        {
            "class_id": 0,
            "class_name": "person",
            "confidence": 0.91,
            "bbox": [x1, y1, x2, y2]
        }
        """

        result = self.detect(frame)

        if result is None:
            return []

        detections = []

        if result.boxes is None:
            return detections

        for box in result.boxes:

            class_id = int(box.cls[0])

            confidence = float(box.conf[0])

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            class_name = self.model.names[class_id]

            detection = {
                "class_id": class_id,
                "class_name": class_name,
                "confidence": confidence,
                "bbox": [
                    x1,
                    y1,
                    x2,
                    y2
                ]
            }

            detections.append(detection)

        return detections