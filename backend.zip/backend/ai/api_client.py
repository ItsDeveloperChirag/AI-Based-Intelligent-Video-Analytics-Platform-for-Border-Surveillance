import json
import urllib.request
import urllib.error


# ============================================================
# FASTAPI SERVER
# ============================================================

from config import API_URL


# ============================================================
# SEND INCIDENT TO FASTAPI
# ============================================================

def send_incident(incident):

    url = f"{API_URL}/api/incidents"


    # --------------------------------------------------------
    # CONVERT INCIDENT TO JSON
    # --------------------------------------------------------

    data = json.dumps(
        incident
    ).encode("utf-8")


    # --------------------------------------------------------
    # CREATE REQUEST
    # --------------------------------------------------------

    request = urllib.request.Request(

        url,

        data=data,

        headers={
            "Content-Type": "application/json"
        },

        method="POST"
    )


    # --------------------------------------------------------
    # SEND REQUEST
    # --------------------------------------------------------

    try:

        with urllib.request.urlopen(
            request,
            timeout=5
        ) as response:

            response_data = (
                response.read()
                .decode("utf-8")
            )

            result = json.loads(
                response_data
            )


            print(
                "✅ Incident sent to FastAPI"
            )

            return result


    except urllib.error.URLError as error:

        print(
            "⚠️ FastAPI connection failed:"
        )

        print(error)

        return {
            "success": False,
            "message": "FastAPI connection failed"
        }


    except Exception as error:

        print(
            "❌ API request error:"
        )

        print(error)

        return {
            "success": False,
            "message": str(error)
        }