class PlateTracker:

    def __init__(self):
        pass

    def _center(self, bbox):
        x1, y1, x2, y2 = bbox

        return (
            (x1 + x2) / 2,
            (y1 + y2) / 2
        )

    def _point_inside_bbox(self, point, bbox):
        px, py = point

        x1, y1, x2, y2 = bbox

        return (
            x1 <= px <= x2 and
            y1 <= py <= y2
        )

    def _intersection_area(self, plate_bbox, vehicle_bbox):

        px1, py1, px2, py2 = plate_bbox
        vx1, vy1, vx2, vy2 = vehicle_bbox

        ix1 = max(px1, vx1)
        iy1 = max(py1, vy1)
        ix2 = min(px2, vx2)
        iy2 = min(py2, vy2)

        if ix2 <= ix1 or iy2 <= iy1:
            return 0

        return (ix2 - ix1) * (iy2 - iy1)

    def associate(self, vehicles, plates):

        associations = []

        vehicle_classes = [
            "car",
            "motorcycle",
            "bus",
            "truck"
        ]

        for plate in plates:

            plate_bbox = plate["bbox"]

            plate_center = self._center(
                plate_bbox
            )

            best_vehicle = None
            best_score = -1

            for vehicle in vehicles:

                if vehicle["class_name"] not in vehicle_classes:
                    continue

                vehicle_bbox = vehicle["bbox"]

                # ------------------------------------------------
                # METHOD 1:
                # Plate center is inside vehicle
                # ------------------------------------------------

                inside = self._point_inside_bbox(
                    plate_center,
                    vehicle_bbox
                )

                # ------------------------------------------------
                # METHOD 2:
                # Plate overlaps vehicle
                # ------------------------------------------------

                intersection = self._intersection_area(
                    plate_bbox,
                    vehicle_bbox
                )

                plate_width = max(
                    1,
                    plate_bbox[2] - plate_bbox[0]
                )

                plate_height = max(
                    1,
                    plate_bbox[3] - plate_bbox[1]
                )

                plate_area = (
                    plate_width *
                    plate_height
                )

                overlap_ratio = (
                    intersection / plate_area
                )

                # ------------------------------------------------
                # Association score
                # ------------------------------------------------

                score = 0

                if inside:
                    score += 2

                if overlap_ratio > 0.30:
                    score += 2

                elif overlap_ratio > 0.05:
                    score += 1

                if score > best_score:

                    best_score = score
                    best_vehicle = vehicle

            # ----------------------------------------------------
            # Association found
            # ----------------------------------------------------

            if best_vehicle is not None and best_score > 0:

                associations.append({

                    "track_id":
                        best_vehicle["track_id"],

                    "vehicle_type":
                        best_vehicle["class_name"],

                    "vehicle_bbox":
                        best_vehicle["bbox"],

                    "plate_bbox":
                        plate_bbox,

                    "plate_confidence":
                        plate["confidence"],

                    "association_score":
                        best_score
                })

        return associations