import cv2


class StreamManager:
    """Owns one camera connection.

    Camera URL is normally supplied by config.CAMERA_URL. Keeping it injectable
    also makes the class reusable for future multi-camera support.
    """

    def __init__(self, source):
        self.source = source
        self.cap = None

    def start(self):
        self.cap = cv2.VideoCapture(self.source)

        # Reduce buffering where the OpenCV backend supports it. This prevents
        # the application from processing old frames after temporary slowdown.
        try:
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass

        if not self.cap.isOpened():
            print(f"❌ Stream connect nahi hua: {self.source}")
            return False

        print(f"✅ Stream connected: {self.source}")
        return True

    def read(self):
        if self.cap is None:
            return False, None
        return self.cap.read()

    def release(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None
            print("✅ Stream released.")


if __name__ == "__main__":
    from config import CAMERA_URL

    stream = StreamManager(CAMERA_URL)

    if not stream.start():
        raise SystemExit(1)

    print("Press Q to quit.")

    while True:
        ret, frame = stream.read()

        if not ret:
            print("❌ Frame nahi mil raha!")
            break

        cv2.imshow("IBVAP - Stream Manager Test", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    stream.release()
    cv2.destroyAllWindows()
