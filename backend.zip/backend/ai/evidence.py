import cv2
from pathlib import Path
from datetime import datetime


class EvidenceManager:

    def __init__(self, evidence_dir="evidence"):
        project_root = Path(__file__).resolve().parent.parent
        self.evidence_dir = project_root / evidence_dir

        # Create folder automatically
        self.evidence_dir.mkdir(parents=True, exist_ok=True)

        print(f"Evidence folder: {self.evidence_dir}")

    def save_frame(self, frame, event_id):
        """
        Save the current camera frame as evidence.

        Returns:
            str: Relative path of saved evidence
        """

        if frame is None:
            print("❌ Cannot save evidence: frame is None")
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

        filename = f"{event_id}_{timestamp}.jpg"

        file_path = self.evidence_dir / filename

        success = cv2.imwrite(str(file_path), frame)

        if not success:
            print("❌ Failed to save evidence")
            return None

        print(f"📸 Evidence saved: {file_path}")

        return str(file_path)