from collections import defaultdict
import math


class TrajectoryTracker:

    def __init__(self):
        # Store previous positions for each Track ID
        self.history = defaultdict(list)

    def update(self, track_id, center):

        # Save current position
        self.history[track_id].append(center)

        # Keep only the last 30 positions
        if len(self.history[track_id]) > 30:
            self.history[track_id].pop(0)

        positions = self.history[track_id]

        # Need at least 2 points to calculate movement
        if len(positions) < 2:
            return {
                "track_id": track_id,
                "center": center,
                "direction": "STATIONARY",
                "distance": 0
            }

        old_x, old_y = positions[0]
        new_x, new_y = positions[-1]

        dx = new_x - old_x
        dy = new_y - old_y

        # Calculate total movement distance
        distance = math.sqrt(dx ** 2 + dy ** 2)

        # Determine direction
        if abs(dx) > abs(dy):

            if dx > 10:
                direction = "RIGHT"
            elif dx < -10:
                direction = "LEFT"
            else:
                direction = "STATIONARY"

        else:

            if dy > 10:
                direction = "DOWN"
            elif dy < -10:
                direction = "UP"
            else:
                direction = "STATIONARY"

        return {
            "track_id": track_id,
            "center": center,
            "direction": direction,
            "distance": round(distance, 2)
        }