from ultralytics import YOLO


class VehicleClassifier:
    """
    Vehicle Detection + Classification

    Detects and classifies:
    - car
    - motorcycle
    - bus
    - truck
    """

    VEHICLE_CLASSES = {
        "car",
        "motorcycle",
        "bus",
        "truck"
    }

    def __init__(
        self,
        model_path="yolo11n.pt",
        confidence=0.35,
        image_size=640
    ):
        self.confidence = confidence
        self.image_size = image_size

        print("Loading vehicle classification model...")

        self.model = YOLO(model_path)

        print("✅ Vehicle model loaded")

    def detect(self, frame):
        """
        Detect vehicles in a frame.

        Returns:
            list of vehicle detections
        """

        if frame is None:
            return []

        results = self.model.predict(
            source=frame,
            conf=self.confidence,
            imgsz=self.image_size,
            verbose=False
        )

        if not results:
            return []

        result = results[0]

        vehicles = []

        if result.boxes is None:
            return vehicles

        for box in result.boxes:

            class_id = int(box.cls[0])
            confidence = float(box.conf[0])

            class_name = self.model.names[class_id]

            # Only keep vehicle classes
            if class_name not in self.VEHICLE_CLASSES:
                continue

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )

            vehicles.append({
                "class_id": class_id,
                "vehicle_type": class_name,
                "confidence": confidence,
                "bbox": [x1, y1, x2, y2]
            })

        return vehicles

    def detect_and_draw(self, frame):
        """
        Detect vehicles and draw bounding boxes.
        """

        vehicles = self.detect(frame)

        output = frame.copy()

        for vehicle in vehicles:

            x1, y1, x2, y2 = vehicle["bbox"]

            vehicle_type = vehicle["vehicle_type"]
            confidence = vehicle["confidence"]

            label = (
                f"{vehicle_type.upper()} "
                f"{confidence:.2f}"
            )

            # Bounding box
            import cv2

            cv2.rectangle(
                output,
                (x1, y1),
                (x2, y2),
                (0, 255, 0),
                2
            )

            # Label background
            cv2.rectangle(
                output,
                (x1, max(0, y1 - 30)),
                (x1 + 180, y1),
                (0, 255, 0),
                -1
            )

            cv2.putText(
                output,
                label,
                (x1 + 5, y1 - 8),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (0, 0, 0),
                2
            )

        return output, vehicles