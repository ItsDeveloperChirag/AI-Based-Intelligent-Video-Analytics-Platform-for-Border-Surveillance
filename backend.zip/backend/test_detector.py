print("=" * 60)
print("IBVAP EXISTING DETECTOR TEST")
print("=" * 60)

try:
    from ai.detector import Detector
    print("✅ Detector imported successfully")

except Exception as e:
    print("❌ Detector import failed")
    print("ERROR:")
    print(e)