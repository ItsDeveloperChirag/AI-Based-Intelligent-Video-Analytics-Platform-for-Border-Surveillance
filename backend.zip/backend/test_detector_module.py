import cv2

from ai.camera import Camera
from ai.detector import Detector


print("=" * 60)
print("IBVAP - DETECTOR DEBUG")
print("=" * 60)

# Camera
camera = Camera()
camera.start()

print("✅ Camera started")

# Detector
detector = Detector()

print("✅ Detector loaded")
print("Stand in front of camera...")
print("Press Q to exit")


while True:

    frame = camera.read()

    if frame is None:
        continue

    # ONLY ONE YOLO CALL
    result = detector.detect(frame)

    if result is None:
        print("⚠️ No result")
        continue

    # Print raw YOLO information
    if result.boxes is not None:

        print(
            f"Boxes detected: {len(result.boxes)}"
        )

        for box in result.boxes:

            class_id = int(box.cls[0])
            confidence = float(box.conf[0])

            class_name = detector.model.names[class_id]

            print(
                f"➡️ {class_name} "
                f"| confidence={confidence:.2f}"
            )

    else:

        print("No boxes")

    # Draw result
    annotated = result.plot()

    cv2.imshow(
        "IBVAP - Detector Debug",
        annotated
    )

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


camera.stop()
cv2.destroyAllWindows()

print("Test finished.")